import { createClient, type Session } from '@supabase/supabase-js';
import type { ClassTeacherRegisterData } from './teacherRegisterData';
import type { StudentRecordData, StyleConfig } from './recordData';
import type { RosterStudent } from './schoolStudentsRoster';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL?.trim();
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY?.trim();

export const cloudConfigurationError =
  supabaseUrl && supabaseAnonKey
    ? null
    : 'Cloud sync is not configured. Add VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY to .env.local.';

export const supabase =
  supabaseUrl && supabaseAnonKey
    ? createClient(supabaseUrl, supabaseAnonKey, {
        auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true },
      })
    : null;

const MEDIA_BUCKET = 'school-media';
const signedMediaPaths = new Map<string, string>();
const uploadedMediaPaths = new Map<string, string>();

export interface SchoolAppSnapshot {
  roster: RosterStudent[];
  recordData: StudentRecordData;
  recordsByStudent: Record<string, StudentRecordData>;
  registerData: ClassTeacherRegisterData;
  registersByClass: Record<string, ClassTeacherRegisterData>;
  schoolLogoDataUrl: string | null;
  selectedStudentId: string;
  styleConfig: StyleConfig;
  batchClassLabel: string;
  batchStudentIds: string[];
  idCardStudentIds: string[];
}

export async function loadSchoolSnapshot(userId: string): Promise<SchoolAppSnapshot | null> {
  if (!supabase) throw new Error(cloudConfigurationError ?? 'Cloud storage is not configured.');

  const { data: isSchoolAdmin, error: authorizationError } = await supabase.rpc('is_school_admin');
  if (authorizationError) throw authorizationError;
  if (!isSchoolAdmin) {
    throw new Error('This email is not on the school-admin allowlist in Supabase.');
  }

  const { data, error } = await supabase
    .from('school_app_state')
    .select('state')
    .eq('owner_id', userId)
    .maybeSingle();

  if (error) throw error;
  if (!data) return null;
  if (!data.state || typeof data.state !== 'object') {
    throw new Error('The saved school data is invalid. It was not replaced.');
  }

  const hydrated = await hydrateMedia(data.state);
  if (typeof hydrated !== 'object' || hydrated === null) {
    throw new Error('The saved school data is invalid. It was not replaced.');
  }
  const candidate = hydrated as Partial<SchoolAppSnapshot>;
  if (
    !Array.isArray(candidate.roster) ||
    !candidate.recordData ||
    typeof candidate.recordData !== 'object' ||
    !candidate.registerData ||
    typeof candidate.registerData !== 'object' ||
    typeof candidate.selectedStudentId !== 'string' ||
    !candidate.styleConfig ||
    !Array.isArray(candidate.batchStudentIds) ||
    !Array.isArray(candidate.idCardStudentIds)
  ) {
    throw new Error('The saved school data is incomplete. It was not replaced.');
  }
  return {
    ...candidate,
    recordsByStudent: candidate.recordsByStudent ?? {},
    registersByClass: candidate.registersByClass ?? {},
  } as SchoolAppSnapshot;
}

export async function saveSchoolSnapshot(
  userId: string,
  snapshot: SchoolAppSnapshot,
): Promise<void> {
  if (!supabase) throw new Error(cloudConfigurationError ?? 'Cloud storage is not configured.');

  const state = await externalizeMedia(snapshot, userId);
  const { error } = await supabase.from('school_app_state').upsert(
    { owner_id: userId, state, updated_at: new Date().toISOString() },
    { onConflict: 'owner_id' },
  );

  if (error) throw error;
}

export async function restoreSession(): Promise<Session | null> {
  if (!supabase) return null;
  const { data, error } = await supabase.auth.getSession();
  if (error) throw error;
  return data.session;
}

function isCloudMedia(value: unknown): value is { __schoolMedia: string } {
  return (
    typeof value === 'object' &&
    value !== null &&
    '__schoolMedia' in value &&
    typeof value.__schoolMedia === 'string'
  );
}

async function externalizeMedia(value: unknown, userId: string): Promise<unknown> {
  if (typeof value === 'string') {
    const existingPath = signedMediaPaths.get(value);
    if (existingPath) return { __schoolMedia: existingPath };
    const uploadedPath = uploadedMediaPaths.get(value);
    if (uploadedPath) return { __schoolMedia: uploadedPath };

    const match = value.match(/^data:image\/(jpeg|png|webp|gif);base64,/i);
    if (!match) return value;

    const mime = `image/${match[1].toLowerCase()}`;
    const extension = match[1].toLowerCase() === 'jpeg' ? 'jpg' : match[1].toLowerCase();
    const blob = await (await fetch(value)).blob();
    const digest = await crypto.subtle.digest('SHA-256', await blob.arrayBuffer());
    const hash = Array.from(new Uint8Array(digest), (byte) => byte.toString(16).padStart(2, '0')).join('');
    const path = `${userId}/assets/${hash}.${extension}`;
    const { error } = await supabase!.storage.from(MEDIA_BUCKET).upload(path, blob, {
      contentType: mime,
      upsert: true,
    });

    if (error) throw error;
    uploadedMediaPaths.set(value, path);
    return { __schoolMedia: path };
  }

  if (Array.isArray(value)) {
    return Promise.all(value.map((item) => externalizeMedia(item, userId)));
  }

  if (typeof value === 'object' && value !== null) {
    const entries = await Promise.all(
      Object.entries(value).map(async ([key, item]) => [key, await externalizeMedia(item, userId)] as const),
    );
    return Object.fromEntries(entries);
  }

  return value;
}

async function hydrateMedia(value: unknown): Promise<unknown> {
  if (isCloudMedia(value)) {
    const { data, error } = await supabase!.storage
      .from(MEDIA_BUCKET)
      .createSignedUrl(value.__schoolMedia, 60 * 60 * 24 * 7);

    if (error) throw error;
    signedMediaPaths.set(data.signedUrl, value.__schoolMedia);
    return data.signedUrl;
  }

  if (Array.isArray(value)) {
    return Promise.all(value.map((item) => hydrateMedia(item)));
  }

  if (typeof value === 'object' && value !== null) {
    const entries = await Promise.all(
      Object.entries(value).map(async ([key, item]) => [key, await hydrateMedia(item)] as const),
    );
    return Object.fromEntries(entries);
  }

  return value;
}
