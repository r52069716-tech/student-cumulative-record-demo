import React, { useState } from 'react';
import { ArrowLeft, MessageCircle, Printer } from 'lucide-react';
import { RosterStudent, getEffectiveStudentPhoto } from '../schoolStudentsRoster';

interface StudentIdCardsSheetProps {
  students: RosterStudent[];
  logoDataUrl: string | null;
  useAutoPortraits: boolean;
  onBack: () => void;
}

interface ShareFallback {
  message: string;
  whatsappUrl: string;
}

const CARDS_PER_PAGE = 9;
const CARD_IMAGE_WIDTH = 1012;
const CARD_IMAGE_HEIGHT = 638;

function loadImage(source: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const image = new Image();
    image.onload = () => resolve(image);
    image.onerror = () => reject(new Error('Could not load an image used on the ID card.'));
    image.src = source;
  });
}

function fitTextSize(
  context: CanvasRenderingContext2D,
  text: string,
  maxWidth: number,
  initialSize: number,
  fontWeight = 700
) {
  let size = initialSize;
  while (size > 20) {
    context.font = `${fontWeight} ${size}px Arial, sans-serif`;
    if (context.measureText(text).width <= maxWidth) return size;
    size -= 2;
  }
  return size;
}

async function createStudentIdCardPng(
  student: RosterStudent,
  logoDataUrl: string | null,
  useAutoPortraits: boolean
): Promise<File> {
  const canvas = document.createElement('canvas');
  canvas.width = CARD_IMAGE_WIDTH;
  canvas.height = CARD_IMAGE_HEIGHT;
  const context = canvas.getContext('2d');
  if (!context) throw new Error('Your browser could not create the ID-card image.');

  context.fillStyle = '#ffffff';
  context.fillRect(0, 0, canvas.width, canvas.height);
  context.strokeStyle = '#1e3a8a';
  context.lineWidth = 12;
  context.strokeRect(6, 6, canvas.width - 12, canvas.height - 12);

  context.fillStyle = '#1e3a8a';
  context.fillRect(12, 12, canvas.width - 24, 132);

  if (logoDataUrl) {
    const logo = await loadImage(logoDataUrl);
    context.save();
    context.beginPath();
    context.arc(78, 78, 48, 0, Math.PI * 2);
    context.clip();
    context.fillStyle = '#ffffff';
    context.fill();
    context.drawImage(logo, 30, 30, 96, 96);
    context.restore();
  }

  context.textAlign = 'left';
  context.fillStyle = '#ffffff';
  const schoolName = 'SAMPLE SCHOOL';
  const schoolFontSize = fitTextSize(context, schoolName, 780, 42);
  context.font = `700 ${schoolFontSize}px Arial, sans-serif`;
  context.fillText(schoolName, logoDataUrl ? 155 : 42, 69);
  context.font = '600 26px Arial, sans-serif';
  context.fillText('STUDENT ID CARD', logoDataUrl ? 155 : 42, 111);

  const photoSource = getEffectiveStudentPhoto(student, useAutoPortraits);
  if (photoSource) {
    const photo = await loadImage(photoSource);
    context.drawImage(photo, 42, 174, 218, 340);
  } else {
    context.fillStyle = '#e7e5e4';
    context.fillRect(42, 174, 218, 340);
    context.fillStyle = '#57534e';
    context.textAlign = 'center';
    context.font = '600 25px Arial, sans-serif';
    context.fillText('STUDENT PHOTO', 151, 354);
  }
  context.strokeStyle = '#a8a29e';
  context.lineWidth = 3;
  context.strokeRect(42, 174, 218, 340);

  const textX = 300;
  const textWidth = 660;
  context.textAlign = 'left';
  context.fillStyle = '#1c1917';
  const name = student.name || 'Student';
  const nameSize = fitTextSize(context, name, textWidth, 40);
  context.font = `700 ${nameSize}px Arial, sans-serif`;
  context.fillText(name, textX, 218);

  const details: Array<[string, string]> = [
    ['CLASS', student.studentClass || '—'],
    ['ADMISSION NO.', student.admissionNo || '—'],
    ['DATE OF BIRTH', student.dob || '—'],
    ['BLOOD GROUP', student.bloodGroup || '—'],
    ['PARENT PHONE', student.phone || '—'],
  ];
  context.font = '600 17px Arial, sans-serif';
  details.forEach(([label, value], index) => {
    const y = 274 + index * 48;
    context.fillStyle = '#78716c';
    context.fillText(label, textX, y);
    context.fillStyle = '#1c1917';
    context.font = '700 23px Arial, sans-serif';
    context.fillText(value, textX + 205, y);
    context.font = '600 17px Arial, sans-serif';
  });

  context.fillStyle = '#f5f5f4';
  context.fillRect(12, 548, canvas.width - 24, 78);
  context.fillStyle = '#44403c';
  context.font = '600 18px Arial, sans-serif';
  context.textAlign = 'left';
  context.fillText(
    `Photo No: ${student.photoNo || '—'}   |   Sl. No: ${student.slNo || '—'}`,
    34,
    595
  );

  const blob = await new Promise<Blob | null>((resolve) =>
    canvas.toBlob(resolve, 'image/png')
  );
  if (!blob) throw new Error('Could not export the ID card as an image.');
  const safeName = (student.name || 'student').toLowerCase().replace(/[^a-z0-9]+/g, '-');
  return new File([blob], `${safeName}-id-card.png`, { type: 'image/png' });
}

export const StudentIdCardsSheet: React.FC<StudentIdCardsSheetProps> = ({
  students,
  logoDataUrl,
  useAutoPortraits,
  onBack,
}) => {
  const [sharingStudentId, setSharingStudentId] = useState<string | null>(null);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);
  const [shareFallback, setShareFallback] = useState<ShareFallback | null>(null);

  const handlePrint = async () => {
    const images = Array.from(document.querySelectorAll<HTMLImageElement>('.student-id-card img'));
    try {
      await Promise.all(images.map((image) => image.decode()));
      setStatusMessage(null);
      window.print();
    } catch {
      setStatusMessage('A card image could not be loaded. Check the photo and logo before printing.');
    }
  };

  const handleShare = async (student: RosterStudent) => {
    setSharingStudentId(student.id);
    setStatusMessage(null);
    setShareFallback(null);
    const message = `Student ID card for ${student.name} (${student.studentClass}).`;
    const whatsappUrl = `https://wa.me/?text=${encodeURIComponent(message)}`;

    try {
      const cardFile = await createStudentIdCardPng(student, logoDataUrl, useAutoPortraits);
      if (
        typeof navigator.share === 'function' &&
        typeof navigator.canShare === 'function' &&
        navigator.canShare({ files: [cardFile] })
      ) {
        await navigator.share({
          files: [cardFile],
          title: `${student.name} — Student ID Card`,
          text: message,
        });
        setStatusMessage('ID card shared. Choose WhatsApp or another app in the share menu.');
        return;
      }

      const url = URL.createObjectURL(cardFile);
      const link = document.createElement('a');
      link.href = url;
      link.download = cardFile.name;
      document.body.appendChild(link);
      link.click();
      link.remove();
      window.setTimeout(() => URL.revokeObjectURL(url), 1000);
      setShareFallback({
        message: `Downloaded ${cardFile.name}. Open WhatsApp and attach the downloaded card image.`,
        whatsappUrl,
      });
    } catch (error) {
      if (error instanceof DOMException && error.name === 'AbortError') {
        setStatusMessage('Sharing was cancelled.');
      } else {
        setStatusMessage(
          error instanceof Error ? error.message : 'Could not prepare this ID card for sharing.'
        );
      }
    } finally {
      setSharingStudentId(null);
    }
  };

  const pageGroups: RosterStudent[][] = [];
  for (let index = 0; index < students.length; index += CARDS_PER_PAGE) {
    pageGroups.push(students.slice(index, index + CARDS_PER_PAGE));
  }

  return (
    <section className="student-id-cards">
      <div className="no-print id-card-toolbar">
        <div>
          <p className="text-xs font-semibold uppercase tracking-wide text-[#1E3A8A]">
            Print-ready student IDs
          </p>
          <h2 className="mt-1 text-lg font-bold text-stone-900">
            {students.length} ID card{students.length === 1 ? '' : 's'}
          </h2>
          <p className="mt-1 text-xs text-stone-600">
            Standard-size cards · 9 cards per A4 landscape page
            {logoDataUrl ? ' · School logo included' : ' · Add a school logo from the roster'}
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <button type="button" onClick={onBack} className="id-card-action secondary">
            <ArrowLeft className="h-4 w-4" />
            Back to students
          </button>
          <button
            type="button"
            onClick={handlePrint}
            disabled={students.length === 0}
            className="id-card-action primary"
          >
            <Printer className="h-4 w-4" />
            Print / Save PDF
          </button>
        </div>
      </div>

      {statusMessage && (
        <div className="no-print id-card-notice" role="status">
          {statusMessage}
        </div>
      )}
      {shareFallback && (
        <div className="no-print id-card-notice" role="status">
          <span>{shareFallback.message}</span>
          <a href={shareFallback.whatsappUrl} target="_blank" rel="noreferrer">
            <MessageCircle className="h-4 w-4" />
            Open WhatsApp
          </a>
        </div>
      )}

      {students.length === 0 ? (
        <div className="no-print rounded-xl border border-stone-200 bg-white p-8 text-center text-sm text-stone-600">
          No students are selected for ID cards. Return to the roster and select a class or clear the search.
        </div>
      ) : (
        <div className="id-card-pages">
          {pageGroups.map((pageStudents, pageIndex) => (
            <div className="id-card-page" key={pageStudents[0].id}>
              {pageStudents.map((student) => {
                const photo = getEffectiveStudentPhoto(student, useAutoPortraits);
                return (
                  <article className="student-id-card" key={student.id}>
                    <div className="id-card-heading">
                      {logoDataUrl && <img className="id-card-logo" src={logoDataUrl} alt="School logo" />}
                      <div className="id-card-school">
                        <strong>SAMPLE SCHOOL</strong>
                        <span>STUDENT ID CARD</span>
                      </div>
                    </div>
                    <div className="id-card-content">
                      <div className="id-card-photo">
                        {photo ? (
                          <img src={photo} alt={`${student.name} student photo`} />
                        ) : (
                          <span>STUDENT PHOTO</span>
                        )}
                      </div>
                      <div className="id-card-details">
                        <strong className="id-card-name">{student.name || 'Student'}</strong>
                        <div><span>Class</span><b>{student.studentClass || '—'}</b></div>
                        <div><span>Admission No.</span><b>{student.admissionNo || '—'}</b></div>
                        <div><span>Date of birth</span><b>{student.dob || '—'}</b></div>
                        <div><span>Blood group</span><b>{student.bloodGroup || '—'}</b></div>
                        <div><span>Parent phone</span><b>{student.phone || '—'}</b></div>
                      </div>
                    </div>
                    <div className="id-card-footer">
                      <span>Photo No: {student.photoNo || '—'} · Sl. No: {student.slNo || '—'}</span>
                      <button
                        type="button"
                        className="no-print id-card-share"
                        disabled={sharingStudentId === student.id}
                        onClick={() => void handleShare(student)}
                      >
                        <MessageCircle className="h-3.5 w-3.5" />
                        {sharingStudentId === student.id ? 'Preparing…' : 'WhatsApp'}
                      </button>
                    </div>
                  </article>
                );
              })}
              <span className="no-print id-card-page-number">
                Page {pageIndex + 1} of {pageGroups.length}
              </span>
            </div>
          ))}
        </div>
      )}
    </section>
  );
};
