import React, { useRef, useState } from 'react';
import { Camera, X } from 'lucide-react';
import {
  ClassTeacherRegisterData,
  SubjectTermMarks,
  PhysEdTermMarks,
  computeGradeFromMarks,
  RegisterStudentEntry,
} from '../teacherRegisterData';
import { StyleConfig } from '../recordData';

interface ClassTeacherRegisterSheetProps {
  data: ClassTeacherRegisterData;
  onChange: (updated: ClassTeacherRegisterData) => void;
  config: StyleConfig;
  isEditable: boolean;
  visibleRegisterPage: 'both' | 'scholastic' | 'coscholastic';
}

export const ClassTeacherRegisterSheet: React.FC<ClassTeacherRegisterSheetProps> = ({
  data,
  onChange,
  config,
  isEditable,
  visibleRegisterPage,
}) => {
  const photoInputRef = useRef<HTMLInputElement | null>(null);
  const [activePhotoIndex, setActivePhotoIndex] = useState<number | null>(null);

  const paletteVars =
    config.themeId === 'tn-education-navy'
      ? {
          '--ctr-border': '#1e3a8a',
          '--ctr-header-bg': '#eff6ff',
          '--ctr-total-bg': '#e0e7ff',
          '--ctr-text': '#0f172a',
          '--ctr-page-bg': '#ffffff',
        }
      : config.themeId === 'warm-parchment'
      ? {
          '--ctr-border': '#292524',
          '--ctr-header-bg': '#f5f2eb',
          '--ctr-total-bg': '#ebe6df',
          '--ctr-text': '#1c1917',
          '--ctr-page-bg': '#fffdf9',
        }
      : {
          '--ctr-border': '#000000',
          '--ctr-header-bg': '#f8fafc',
          '--ctr-total-bg': '#f2f2f2',
          '--ctr-text': '#000000',
          '--ctr-page-bg': '#ffffff',
        };

  const handleTriggerPhotoUpload = (sIdx: number) => {
    if (!isEditable) return;
    setActivePhotoIndex(sIdx);
    photoInputRef.current?.click();
  };

  const handlePhotoFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || activePhotoIndex === null) return;
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        const nextStudents = data.students.map((stu, idx) =>
          idx === activePhotoIndex ? { ...stu, photoDataUrl: reader.result as string } : stu
        );
        onChange({ ...data, students: nextStudents });
      }
    };
    reader.readAsDataURL(file);
    e.target.value = '';
  };

  const handleClearStudentPhoto = (sIdx: number, e: React.MouseEvent) => {
    e.stopPropagation();
    const nextStudents = data.students.map((stu, idx) =>
      idx === sIdx ? { ...stu, photoDataUrl: null } : stu
    );
    onChange({ ...data, students: nextStudents });
  };

  const renderInput = (
    value: string,
    onValChange: (val: string) => void,
    alignLeft = false
  ) => {
    if (!isEditable) {
      return <span className={alignLeft ? 'block text-left' : 'block text-center'}>{value}</span>;
    }
    return (
      <input
        type="text"
        value={value}
        onChange={(e) => onValChange(e.target.value)}
        className={`ctr-input ${alignLeft ? 'text-left' : 'text-center'}`}
      />
    );
  };

  const renderVerticalHeader = (label: string) => (
    <th className="vertical-cell">
      <div className="vertical-text">{label}</div>
    </th>
  );

  const updateStudentMeta = (
    sIdx: number,
    field: 'studentName' | 'admNo' | 'photoNo',
    val: string
  ) => {
    const nextStudents = data.students.map((stu, idx) =>
      idx === sIdx ? { ...stu, [field]: val } : stu
    );
    onChange({ ...data, students: nextStudents });
  };

  const renderStudentNameWithPhotoCell = (stu: RegisterStudentEntry, sIdx: number) => (
    <div className="flex items-center gap-2 py-0.5">
      {/* Student Photo Slot */}
      <div
        onClick={() => handleTriggerPhotoUpload(sIdx)}
        className={`w-10 h-12 border border-stone-400 rounded-xs bg-stone-50 shrink-0 flex flex-col items-center justify-center overflow-hidden relative group ${
          isEditable ? 'cursor-pointer hover:border-[#1E3A8A]' : ''
        }`}
        title={isEditable ? 'Click to add / change student photo' : undefined}
      >
        {stu.photoDataUrl ? (
          <>
            <img
              src={stu.photoDataUrl}
              alt={stu.studentName || `Student ${stu.slNo}`}
              className="w-full h-full object-cover"
            />
            {isEditable && (
              <button
                type="button"
                onClick={(e) => handleClearStudentPhoto(sIdx, e)}
                className="no-print absolute top-0.5 right-0.5 bg-stone-900/80 text-white rounded-xs p-0.5 opacity-0 group-hover:opacity-100 transition-opacity"
                title="Remove photo"
              >
                <X className="w-2.5 h-2.5" />
              </button>
            )}
          </>
        ) : (
          <div className="no-print flex flex-col items-center justify-center text-stone-400 group-hover:text-[#1E3A8A]">
            <Camera className="w-3 h-3" />
            <span className="text-[6.5pt] leading-tight mt-0.5">Photo</span>
          </div>
        )}
      </div>

      {/* Student Name + Photo No / Adm No */}
      <div className="flex-1 min-w-0">
        {renderInput(
          stu.studentName,
          (v) => updateStudentMeta(sIdx, 'studentName', v),
          true
        )}
        {(stu.photoNo || stu.admNo) && (
          <div className="text-[7pt] text-stone-500 font-mono leading-tight mt-0.5 truncate">
            {stu.photoNo ? `Photo #${stu.photoNo}` : ''}
            {stu.photoNo && stu.admNo ? ' · ' : ''}
            {stu.admNo ? `Adm: ${stu.admNo}` : ''}
          </div>
        )}
      </div>
    </div>
  );

  const updateSubjectMark = (
    sIdx: number,
    tIdx: number,
    subjectKey: 'tamil' | 'english' | 'maths' | 'science' | 'social',
    field: keyof SubjectTermMarks,
    val: string
  ) => {
    const nextStudents = data.students.map((stu, idx) => {
      if (idx !== sIdx) return stu;
      const nextTerms = stu.scholasticTerms.map((termRow, termIndex) => {
        if (termIndex !== tIdx) return termRow;
        const updatedSub = { ...termRow[subjectKey], [field]: val };
        if (field === 'fa' || field === 'sa') {
          const faNum = parseFloat(updatedSub.fa);
          const saNum = parseFloat(updatedSub.sa);
          if (!isNaN(faNum) && !isNaN(saNum)) {
            const sum = Math.round(faNum + saNum);
            updatedSub.total = String(sum);
            updatedSub.grade = computeGradeFromMarks(sum);
          }
        }
        return { ...termRow, [subjectKey]: updatedSub };
      }) as typeof stu.scholasticTerms;

      return { ...stu, scholasticTerms: nextTerms };
    });
    onChange({ ...data, students: nextStudents });
  };

  const updatePhysEdMark = (
    sIdx: number,
    tIdx: number,
    field: keyof PhysEdTermMarks,
    val: string
  ) => {
    const nextStudents = data.students.map((stu, idx) => {
      if (idx !== sIdx) return stu;
      const nextTerms = stu.scholasticTerms.map((termRow, termIndex) =>
        termIndex === tIdx
          ? { ...termRow, physEd: { ...termRow.physEd, [field]: val } }
          : termRow
      ) as typeof stu.scholasticTerms;
      return { ...stu, scholasticTerms: nextTerms };
    });
    onChange({ ...data, students: nextStudents });
  };

  const updateCoScholasticCell = (
    sIdx: number,
    tIdx: number,
    domain: 'lifeSkills' | 'attitudes' | 'wellness' | 'coCurricular',
    colIdx: number,
    val: string
  ) => {
    const nextStudents = data.students.map((stu, idx) => {
      if (idx !== sIdx) return stu;
      const nextCoTerms = stu.coScholasticTerms.map((termRow, termIndex) => {
        if (termIndex !== tIdx) return termRow;
        const arr = [...termRow[domain]];
        arr[colIdx] = val;
        return { ...termRow, [domain]: arr };
      }) as typeof stu.coScholasticTerms;
      return { ...stu, coScholasticTerms: nextCoTerms };
    });
    onChange({ ...data, students: nextStudents });
  };

  const renderSubjectGroupCells = (
    sIdx: number,
    tIdx: number,
    subjectKey: 'tamil' | 'english' | 'maths' | 'science' | 'social',
    marks: SubjectTermMarks
  ) => (
    <>
      <td>{renderInput(marks.fa, (v) => updateSubjectMark(sIdx, tIdx, subjectKey, 'fa', v))}</td>
      <td>{renderInput(marks.sa, (v) => updateSubjectMark(sIdx, tIdx, subjectKey, 'sa', v))}</td>
      <td>
        {renderInput(marks.total, (v) => updateSubjectMark(sIdx, tIdx, subjectKey, 'total', v))}
      </td>
      <td>
        {renderInput(marks.grade, (v) => updateSubjectMark(sIdx, tIdx, subjectKey, 'grade', v))}
      </td>
    </>
  );

  return (
    <div className="ctr-document" style={paletteVars as React.CSSProperties}>
      <input
        ref={photoInputRef}
        type="file"
        accept="image/*"
        onChange={handlePhotoFileChange}
        className="hidden"
      />

      {/* =====================================================================
          PAGE 1: SCHOLASTIC AREAS (Tamil, English, Mathematics, Science, Social Science, Physical Education)
         ===================================================================== */}
      {(visibleRegisterPage === 'both' || visibleRegisterPage === 'scholastic') && (
        <div className="landscape-page" id="ctr-page-1">
          <div className="flex items-center justify-between gap-4 mb-1">
            <div className="school-title">
              <span>School Name :</span>
              <span className="underline underline-offset-4">
                {isEditable ? (
                  <input
                    type="text"
                    value={data.schoolName}
                    onChange={(e) => onChange({ ...data, schoolName: e.target.value })}
                    className="ctr-input w-64 text-left underline"
                  />
                ) : (
                  data.schoolName
                )}
              </span>
            </div>
            <div className="header-title">CLASS TEACHER ASSESSMENT RECORD</div>
          </div>

          <div className="flex items-center justify-between mb-2">
            <div className="text-[8.5pt] font-bold">
              {data.classAndSection ? `Class : ${data.classAndSection}` : ''}
            </div>
            <div className="year-title">
              <span>Year :</span>
              {isEditable ? (
                <input
                  type="text"
                  value={data.academicYear}
                  onChange={(e) => onChange({ ...data, academicYear: e.target.value })}
                  className="ctr-input w-40 text-left"
                />
              ) : (
                <span>{data.academicYear}</span>
              )}
            </div>
          </div>

          <table>
            <thead>
              <tr>
                <th rowSpan={2} style={{ width: '3%' }}>
                  Sl. No.
                </th>
                <th rowSpan={2} style={{ width: '16%' }}>
                  Name of the Student &amp; Photo
                </th>
                <th rowSpan={2} style={{ width: '4%' }}>
                  Term
                </th>
                <th colSpan={4}>Tamil</th>
                <th colSpan={4}>English</th>
                <th colSpan={4}>Mathematics</th>
                <th colSpan={4}>Science</th>
                <th colSpan={4}>Social Science</th>
                <th colSpan={6}>Physical Education</th>
              </tr>
              <tr>
                {/* Tamil */}
                {renderVerticalHeader('FA - 40')}
                {renderVerticalHeader('SA - 60')}
                {renderVerticalHeader('FA+SA - 100')}
                {renderVerticalHeader('Grade')}
                {/* English */}
                {renderVerticalHeader('FA - 40')}
                {renderVerticalHeader('SA - 60')}
                {renderVerticalHeader('FA+SA - 100')}
                {renderVerticalHeader('Grade')}
                {/* Mathematics */}
                {renderVerticalHeader('FA - 40')}
                {renderVerticalHeader('SA - 60')}
                {renderVerticalHeader('FA+SA - 100')}
                {renderVerticalHeader('Grade')}
                {/* Science */}
                {renderVerticalHeader('FA - 40')}
                {renderVerticalHeader('SA - 60')}
                {renderVerticalHeader('FA+SA - 100')}
                {renderVerticalHeader('Grade')}
                {/* Social Science */}
                {renderVerticalHeader('FA - 40')}
                {renderVerticalHeader('SA - 60')}
                {renderVerticalHeader('FA+SA - 100')}
                {renderVerticalHeader('Grade')}
                {/* Physical Education */}
                {renderVerticalHeader('Physical Fitness')}
                {renderVerticalHeader('Sportsmanship')}
                {renderVerticalHeader('Knowledge of Sport')}
                {renderVerticalHeader('Initiative & Interest')}
                {renderVerticalHeader('Regularity')}
                {renderVerticalHeader('Grade')}
              </tr>
            </thead>
            <tbody>
              {data.students.map((stu, sIdx) =>
                stu.scholasticTerms.map((termRow, tIdx) => {
                  const isTotal = termRow.termLabel === 'Total';
                  return (
                    <tr
                      key={`sch-${stu.slNo}-${termRow.termLabel}`}
                      className={isTotal ? 'row-total' : undefined}
                    >
                      {tIdx === 0 && (
                        <>
                          <td rowSpan={4} className="font-semibold">
                            {stu.slNo}
                          </td>
                          <td rowSpan={4} className="left-align font-medium">
                            {renderStudentNameWithPhotoCell(stu, sIdx)}
                          </td>
                        </>
                      )}
                      <td>{termRow.termLabel}</td>
                      {renderSubjectGroupCells(sIdx, tIdx, 'tamil', termRow.tamil)}
                      {renderSubjectGroupCells(sIdx, tIdx, 'english', termRow.english)}
                      {renderSubjectGroupCells(sIdx, tIdx, 'maths', termRow.maths)}
                      {renderSubjectGroupCells(sIdx, tIdx, 'science', termRow.science)}
                      {renderSubjectGroupCells(sIdx, tIdx, 'social', termRow.social)}
                      {/* Physical Education (6 columns) */}
                      <td>
                        {renderInput(termRow.physEd.fitness, (v) =>
                          updatePhysEdMark(sIdx, tIdx, 'fitness', v)
                        )}
                      </td>
                      <td>
                        {renderInput(termRow.physEd.sportsmanship, (v) =>
                          updatePhysEdMark(sIdx, tIdx, 'sportsmanship', v)
                        )}
                      </td>
                      <td>
                        {renderInput(termRow.physEd.knowledge, (v) =>
                          updatePhysEdMark(sIdx, tIdx, 'knowledge', v)
                        )}
                      </td>
                      <td>
                        {renderInput(termRow.physEd.initiative, (v) =>
                          updatePhysEdMark(sIdx, tIdx, 'initiative', v)
                        )}
                      </td>
                      <td>
                        {renderInput(termRow.physEd.regularity, (v) =>
                          updatePhysEdMark(sIdx, tIdx, 'regularity', v)
                        )}
                      </td>
                      <td>
                        {renderInput(termRow.physEd.grade, (v) =>
                          updatePhysEdMark(sIdx, tIdx, 'grade', v)
                        )}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      )}

      {/* =====================================================================
          PAGE 2: CO-SCHOLASTIC AREAS (Life Skills, Attitudes & Values, Wellness & Yoga, Co-Curricular Activities)
         ===================================================================== */}
      {(visibleRegisterPage === 'both' || visibleRegisterPage === 'coscholastic') && (
        <div className="landscape-page" id="ctr-page-2">
          <div className="flex items-center justify-between gap-4 mb-1">
            <div className="school-title">
              <span>School Name :</span>
              <span className="underline underline-offset-4">
                {isEditable ? (
                  <input
                    type="text"
                    value={data.schoolName}
                    onChange={(e) => onChange({ ...data, schoolName: e.target.value })}
                    className="ctr-input w-64 text-left underline"
                  />
                ) : (
                  data.schoolName
                )}
              </span>
            </div>
            <div className="header-title">Co-Scholastic Areas</div>
          </div>

          <div className="flex items-center justify-between mb-2">
            <div className="text-[8.5pt] font-bold">
              {data.classAndSection ? `Class : ${data.classAndSection}` : ''}
            </div>
            <div className="year-title">
              <span>Year :</span>
              {isEditable ? (
                <input
                  type="text"
                  value={data.academicYear}
                  onChange={(e) => onChange({ ...data, academicYear: e.target.value })}
                  className="ctr-input w-40 text-left"
                />
              ) : (
                <span>{data.academicYear}</span>
              )}
            </div>
          </div>

          <table>
            <thead>
              <tr>
                <th rowSpan={2} style={{ width: '3%' }}>
                  Sl. No.
                </th>
                <th rowSpan={2} style={{ width: '5%' }}>
                  Adm. No.
                </th>
                <th rowSpan={2} style={{ width: '16%' }}>
                  Name of the Student &amp; Photo
                </th>
                <th rowSpan={2} style={{ width: '4%' }}>
                  Term
                </th>
                <th colSpan={7}>Life Skills</th>
                <th colSpan={5}>Attitudes &amp; Values</th>
                <th colSpan={6}>Wellness &amp; Yoga / Holistic Exercise</th>
                <th colSpan={6}>Co-Curricular Activities</th>
              </tr>
              <tr>
                {/* Life Skills (7 cols) */}
                {renderVerticalHeader('Communication Skill')}
                {renderVerticalHeader('Assertiveness / Refusal Skill')}
                {renderVerticalHeader('Rational Thinking Skill')}
                {renderVerticalHeader('Self Awareness')}
                {renderVerticalHeader('Team Work')}
                {renderVerticalHeader('Grade')}
                {renderVerticalHeader('Grade')}
                {/* Attitudes & Values (5 cols) */}
                {renderVerticalHeader('Courteousness')}
                {renderVerticalHeader('Protecting School / Public Properties')}
                {renderVerticalHeader('Compassion for All Living Creatures')}
                {renderVerticalHeader('Compliance with Safety & Road Rules')}
                {renderVerticalHeader('Grade')}
                {/* Wellness & Yoga (6 cols) */}
                {renderVerticalHeader('Interest')}
                {renderVerticalHeader('Continuity')}
                {renderVerticalHeader('Regularity')}
                {renderVerticalHeader('Effort')}
                {renderVerticalHeader('Competency')}
                {renderVerticalHeader('Grade')}
                {/* Co-Curricular Activities (6 cols) */}
                {renderVerticalHeader('Effort')}
                {renderVerticalHeader('Initiative')}
                {renderVerticalHeader('Persistence')}
                {renderVerticalHeader('Involvement')}
                {renderVerticalHeader('Regularity')}
                {renderVerticalHeader('Grade')}
              </tr>
            </thead>
            <tbody>
              {data.students.map((stu, sIdx) =>
                stu.coScholasticTerms.map((termRow, tIdx) => {
                  const isTotal = termRow.termLabel === 'Total';
                  return (
                    <tr
                      key={`cosch-${stu.slNo}-${termRow.termLabel}`}
                      className={isTotal ? 'row-total' : undefined}
                    >
                      {tIdx === 0 && (
                        <>
                          <td rowSpan={4} className="font-semibold">
                            {stu.slNo}
                          </td>
                          <td rowSpan={4}>
                            {renderInput(stu.admNo, (v) => updateStudentMeta(sIdx, 'admNo', v))}
                          </td>
                          <td rowSpan={4} className="left-align font-medium">
                            {renderStudentNameWithPhotoCell(stu, sIdx)}
                          </td>
                        </>
                      )}
                      <td>{termRow.termLabel}</td>
                      {termRow.lifeSkills.map((val, cIdx) => (
                        <td key={`ls-${cIdx}`}>
                          {renderInput(val, (v) =>
                            updateCoScholasticCell(sIdx, tIdx, 'lifeSkills', cIdx, v)
                          )}
                        </td>
                      ))}
                      {termRow.attitudes.map((val, cIdx) => (
                        <td key={`att-${cIdx}`}>
                          {renderInput(val, (v) =>
                            updateCoScholasticCell(sIdx, tIdx, 'attitudes', cIdx, v)
                          )}
                        </td>
                      ))}
                      {termRow.wellness.map((val, cIdx) => (
                        <td key={`well-${cIdx}`}>
                          {renderInput(val, (v) =>
                            updateCoScholasticCell(sIdx, tIdx, 'wellness', cIdx, v)
                          )}
                        </td>
                      ))}
                      {termRow.coCurricular.map((val, cIdx) => (
                        <td key={`cc-${cIdx}`}>
                          {renderInput(val, (v) =>
                            updateCoScholasticCell(sIdx, tIdx, 'coCurricular', cIdx, v)
                          )}
                        </td>
                      ))}
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};
