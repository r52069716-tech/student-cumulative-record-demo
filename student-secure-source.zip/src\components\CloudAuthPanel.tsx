import { useState, type FormEvent } from 'react';
import { Cloud, LockKeyhole } from 'lucide-react';
import { supabase } from '../cloudStorage';

interface CloudAuthPanelProps {
  initialError?: string | null;
}

export function CloudAuthPanel({ initialError }: CloudAuthPanelProps) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [errorMessage, setErrorMessage] = useState<string | null>(initialError || null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!supabase) return;

    setErrorMessage(null);
    setIsSubmitting(true);

    try {
      const { error } = await supabase.auth.signInWithPassword({ email, password });
      if (error) throw error;
    } catch (error) {
      setErrorMessage(error instanceof Error ? error.message : 'Cloud sign-in failed.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <main className="min-h-screen bg-[#FBF9F5] px-4 py-12 text-stone-900">
      <section className="mx-auto max-w-md rounded-2xl border border-stone-200 bg-white p-7 shadow-sm">
        <div className="mb-6 flex items-center gap-3">
          <span className="rounded-xl bg-blue-50 p-3 text-blue-900">
            <Cloud className="h-6 w-6" />
          </span>
          <div>
            <h1 className="text-xl font-semibold">School cloud storage</h1>
            <p className="text-sm text-stone-500">Private student data and photo sync</p>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <label className="block text-sm font-medium">
            School admin email
            <input
              type="email"
              autoComplete="email"
              required
              value={email}
              onChange={(event) => setEmail(event.target.value)}
              className="mt-1.5 w-full rounded-lg border border-stone-300 px-3 py-2.5 outline-none focus:border-blue-700"
            />
          </label>
          <label className="block text-sm font-medium">
            Password
            <input
              type="password"
              autoComplete="current-password"
              required
              value={password}
              onChange={(event) => setPassword(event.target.value)}
              className="mt-1.5 w-full rounded-lg border border-stone-300 px-3 py-2.5 outline-none focus:border-blue-700"
            />
          </label>

          {errorMessage && (
            <p role="alert" className="rounded-lg bg-red-50 p-3 text-sm text-red-800">
              {errorMessage}
            </p>
          )}
          <button
            type="submit"
            disabled={isSubmitting}
            className="flex w-full items-center justify-center gap-2 rounded-lg bg-blue-900 px-4 py-3 text-sm font-semibold text-white hover:bg-blue-800 disabled:opacity-60"
          >
            <LockKeyhole className="h-4 w-4" />
            {isSubmitting ? 'Please wait…' : 'Sign in'}
          </button>
        </form>

        <p className="mt-5 text-xs leading-relaxed text-stone-500">
          Admin accounts are created privately by the site owner. Only an allowlisted school-admin
          account can access records. Use a unique password and never share it.
        </p>
      </section>
    </main>
  );
}
