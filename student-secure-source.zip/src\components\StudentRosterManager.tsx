import React, { useState, useRef, useMemo, useEffect } from 'react';
import {
  Search,
  UserPlus,
  Upload,
  Camera,
  Printer,
  FileText,
  Table2,
  CheckCircle2,
  X,
  Layers,
  Video,
  Sparkles,
  Trash2,
  BadgeCheck,
} from 'lucide-react';
import {
  RosterStudent,
  CLASS_ORDER,
  getEffectiveStudentPhoto,
} from '../schoolStudentsRoster';

interface StudentRosterManagerProps {
  roster: RosterStudent[];
  onUpdateRoster: (next: RosterStudent[]) => void;
  onSelectStudentForCumulative: (student: RosterStudent, autoPrint?: boolean) => void;
  onLoadClassIntoRegister: (classLabel: string, students: RosterStudent[]) => void;
  onBatchPrintProfiles: (classLabel: string, students: RosterStudent[]) => void;
  onCreateIdCards: (students: RosterStudent[]) => void;
  schoolLogoDataUrl: string | null;
  onSchoolLogoChange: (logoDataUrl: string | null) => void;
  selectedStudentId?: string;
  useAutoPortraits: boolean;
  onToggleAutoPortraits: (val: boolean) => void;
}

export const StudentRosterManager: React.FC<StudentRosterManagerProps> = ({
  roster,
  onUpdateRoster,
  onSelectStudentForCumulative,
  onLoadClassIntoRegister,
  onBatchPrintProfiles,
  onCreateIdCards,
  schoolLogoDataUrl,
  onSchoolLogoChange,
  selectedStudentId,
  useAutoPortraits,
  onToggleAutoPortraits,
}) => {
  const [classFilter, setClassFilter] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [showAddForm, setShowAddForm] = useState<boolean>(false);
  const [bulkStatusMsg, setBulkStatusMsg] = useState<string | null>(null);

  // Webcam modal state
  const [cameraTargetStudent, setCameraTargetStudent] = useState<RosterStudent | 'NEW' | null>(
    null
  );
  const [cameraError, setCameraError] = useState<string | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);

  const singlePhotoInputRef = useRef<HTMLInputElement | null>(null);
  const bulkPhotoInputRef = useRef<HTMLInputElement | null>(null);
  const schoolLogoInputRef = useRef<HTMLInputElement | null>(null);
  const rosterBackupInputRef = useRef<HTMLInputElement | null>(null);
  const newStudentPhotoRef = useRef<HTMLInputElement | null>(null);
  const [activePhotoTargetId, setActivePhotoTargetId] = useState<string | null>(null);

  // New student form state
  const [newStu, setNewStu] = useState({
    name: '',
    studentClass: 'UKG',
    photoNo: '',
    admissionNo: '',
    dob: '',
    gender: 'Male',
    fatherName: '',
    motherName: '',
    phone: '',
    bloodGroup: 'O+ve',
    address: '',
    pincode: '',
    photoDataUrl: null as string | null,
  });

  // Stop webcam stream on unmount or close
  const stopCameraStream = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
    }
  };

  useEffect(() => {
    return () => stopCameraStream();
  }, []);

  const openWebcamFor = async (target: RosterStudent | 'NEW') => {
    setCameraError(null);
    setCameraTargetStudent(target);
    try {
      const mediaStream = await navigator.mediaDevices.getUserMedia({
        video: { width: { ideal: 600 }, height: { ideal: 660 }, facingMode: 'user' },
      });
      streamRef.current = mediaStream;
      setTimeout(() => {
        if (videoRef.current) {
          videoRef.current.srcObject = mediaStream;
          videoRef.current.play().catch(() => {});
        }
      }, 80);
    } catch {
      setCameraError(
        'Camera access could not be started. Please allow camera permissions or use "Upload Photo" to pick an image file.'
      );
    }
  };

  const handleCaptureWebcamPhoto = () => {
    if (!videoRef.current || !cameraTargetStudent) return;
    const video = videoRef.current;
    const canvas = document.createElement('canvas');
    canvas.width = 300;
    canvas.height = 330;
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
      const dataUrl = canvas.toDataURL('image/jpeg', 0.9);
      if (cameraTargetStudent === 'NEW') {
        setNewStu((prev) => ({ ...prev, photoDataUrl: dataUrl }));
      } else {
        const nextRoster = roster.map((s) =>
          s.id === cameraTargetStudent.id ? { ...s, photoDataUrl: dataUrl } : s
        );
        onUpdateRoster(nextRoster);
        setBulkStatusMsg(`Captured and saved photo for ${cameraTargetStudent.name}.`);
        setTimeout(() => setBulkStatusMsg(null), 4000);
      }
    }
    stopCameraStream();
    setCameraTargetStudent(null);
  };

  const closeWebcamModal = () => {
    stopCameraStream();
    setCameraTargetStudent(null);
    setCameraError(null);
  };

  // Class counts
  const classCounts = useMemo(() => {
    const counts: Record<string, number> = { ALL: roster.length };
    CLASS_ORDER.slice(1).forEach((c) => {
      counts[c] = roster.filter((s) => s.studentClass.toUpperCase() === c).length;
    });
    return counts;
  }, [roster]);

  const filteredStudents = useMemo(() => {
    return roster.filter((stu) => {
      const matchesClass =
        classFilter === 'ALL' || stu.studentClass.toUpperCase() === classFilter;
      if (!matchesClass) return false;
      if (!searchQuery.trim()) return true;
      const q = searchQuery.toLowerCase();
      return (
        stu.name.toLowerCase().includes(q) ||
        stu.photoNo.toLowerCase().includes(q) ||
        stu.admissionNo.toLowerCase().includes(q) ||
        stu.phone.toLowerCase().includes(q) ||
        stu.fatherName.toLowerCase().includes(q)
      );
    });
  }, [roster, classFilter, searchQuery]);

  const handleTriggerSinglePhoto = (studentId: string) => {
    setActivePhotoTargetId(studentId);
    singlePhotoInputRef.current?.click();
  };

  const handleSinglePhotoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !activePhotoTargetId) return;
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        const dataUrl = reader.result;
        const targetStu = roster.find((s) => s.id === activePhotoTargetId);
        const nextRoster = roster.map((s) =>
          s.id === activePhotoTargetId ? { ...s, photoDataUrl: dataUrl } : s
        );
        onUpdateRoster(nextRoster);
        if (targetStu) {
          setBulkStatusMsg(
            `Photo uploaded for ${targetStu.name} (Photo #${targetStu.photoNo || 'N/A'}).`
          );
          setTimeout(() => setBulkStatusMsg(null), 5000);
        }
      }
    };
    reader.readAsDataURL(file);
    e.target.value = '';
  };

  const handleRemoveCustomPhoto = (studentId: string) => {
    const nextRoster = roster.map((s) =>
      s.id === studentId ? { ...s, photoDataUrl: null } : s
    );
    onUpdateRoster(nextRoster);
  };

  const handleBulkPhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    if (files.length === 0) return;

    const fileMap: Record<string, string> = {};
    const orderedUrls: string[] = [];

    await Promise.all(
      files.map(
        (file) =>
          new Promise<void>((resolve) => {
            const reader = new FileReader();
            reader.onload = () => {
              if (typeof reader.result === 'string') {
                orderedUrls.push(reader.result);
                const baseName = file.name.replace(/\.[^/.]+$/, '').trim().toLowerCase();
                const numMatch = baseName.match(/(\d+)$/);
                fileMap[baseName] = reader.result;
                if (numMatch) {
                  fileMap[numMatch[1]] = reader.result;
                }
              }
              resolve();
            };
            reader.readAsDataURL(file);
          })
      )
    );

    let matchedCount = 0;
    let nextRoster = roster.map((stu) => {
      const pNo = stu.photoNo.trim().toLowerCase();
      const adm = stu.admissionNo.trim().toLowerCase();
      const nm = stu.name.trim().toLowerCase();
      const sl = stu.slNo.trim().toLowerCase();

      const matchedUrl =
        (pNo && fileMap[pNo]) ||
        (adm && fileMap[adm]) ||
        (nm && fileMap[nm]) ||
        (sl && fileMap[sl]);

      if (matchedUrl) {
        matchedCount++;
        return { ...stu, photoDataUrl: matchedUrl };
      }
      return stu;
    });

    // If filenames didn't match Photo No / Name, assign sequentially to filtered students without custom photos
    if (matchedCount === 0 && orderedUrls.length > 0) {
      const filteredIds = new Set(filteredStudents.map((s) => s.id));
      let urlIdx = 0;
      nextRoster = roster.map((stu) => {
        if (filteredIds.has(stu.id) && urlIdx < orderedUrls.length) {
          const assigned = orderedUrls[urlIdx++];
          matchedCount++;
          return { ...stu, photoDataUrl: assigned };
        }
        return stu;
      });
    }

    onUpdateRoster(nextRoster);
    setBulkStatusMsg(
      `Uploaded ${files.length} photo(s) — Assigned ${matchedCount} student photo(s) automatically.`
    );
    setTimeout(() => setBulkStatusMsg(null), 6000);
    e.target.value = '';
  };

  const handleNewStudentPhoto = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        setNewStu((prev) => ({ ...prev, photoDataUrl: reader.result as string }));
      }
    };
    reader.readAsDataURL(file);
  };

  const handleSchoolLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!file.type.startsWith('image/')) {
      setBulkStatusMsg('Please choose an image file for the school logo.');
      e.target.value = '';
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result !== 'string') {
        setBulkStatusMsg('The school logo could not be read. Please try another image.');
        return;
      }
      try {
        onSchoolLogoChange(reader.result);
        setBulkStatusMsg('School logo saved and will appear on ID cards.');
      } catch (error) {
        setBulkStatusMsg(
          error instanceof Error ? error.message : 'Could not save the school logo.'
        );
      }
    };
    reader.onerror = () => setBulkStatusMsg('The school logo could not be read. Please try again.');
    reader.readAsDataURL(file);
    e.target.value = '';
  };

  const handleExportRoster = () => {
    const backup = JSON.stringify({ schemaVersion: 1, roster }, null, 2);
    const url = URL.createObjectURL(new Blob([backup], { type: 'application/json' }));
    const link = document.createElement('a');
    link.href = url;
    link.download = 'school-student-roster-backup.json';
    document.body.appendChild(link);
    link.click();
    link.remove();
    URL.revokeObjectURL(url);
    setBulkStatusMsg(
      'Roster backup downloaded. It contains private student data; keep the file secure.'
    );
  };

  const handleImportRoster = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      const backup: unknown = JSON.parse(await file.text());
      if (
        !backup ||
        typeof backup !== 'object' ||
        !('schemaVersion' in backup) ||
        backup.schemaVersion !== 1 ||
        !('roster' in backup) ||
        !Array.isArray(backup.roster) ||
        backup.roster.length === 0
      ) {
        throw new Error('This is not a supported, non-empty student roster backup.');
      }

      const requiredTextFields: Array<keyof RosterStudent> = [
        'id',
        'slNo',
        'name',
        'studentClass',
        'photoNo',
        'phone',
        'fatherName',
        'motherName',
        'dob',
        'gender',
        'address',
        'pincode',
        'bloodGroup',
        'admissionNo',
      ];
      const importedRoster = backup.roster as unknown[];
      const valid = importedRoster.every((entry) => {
        if (typeof entry !== 'object' || entry === null) return false;
        const student = entry as Record<string, unknown>;
        return (
          requiredTextFields.every((field) => typeof student[field] === 'string') &&
          (student.photoDataUrl === undefined ||
            student.photoDataUrl === null ||
            typeof student.photoDataUrl === 'string')
        );
      });
      if (!valid) throw new Error('The backup has invalid student fields.');
      if (!window.confirm(`Replace the current roster with ${importedRoster.length} students?`)) {
        return;
      }

      onUpdateRoster(importedRoster as RosterStudent[]);
      setBulkStatusMsg(
        `Imported ${importedRoster.length} student records. They will sync to cloud when signed in.`
      );
    } catch (error) {
      setBulkStatusMsg(
        error instanceof Error ? error.message : 'Could not read the student roster backup.'
      );
    } finally {
      e.target.value = '';
    }
  };

  const handleAddStudentSubmit = (e: React.FormEvent, autoPrintAfterSave = false) => {
    e.preventDefault();
    if (!newStu.name.trim()) return;

    const created: RosterStudent = {
      id: `stu-${Date.now()}`,
      slNo: String(roster.length + 1),
      name: newStu.name.trim().toUpperCase(),
      studentClass: newStu.studentClass.trim().toUpperCase(),
      photoNo: newStu.photoNo.trim(),
      admissionNo: newStu.admissionNo.trim(),
      dob: newStu.dob.trim(),
      gender: newStu.gender,
      fatherName: newStu.fatherName.trim().toUpperCase(),
      motherName: newStu.motherName.trim().toUpperCase(),
      phone: newStu.phone.trim(),
      bloodGroup: newStu.bloodGroup.trim(),
      address: newStu.address.trim(),
      pincode: newStu.pincode.trim(),
      photoDataUrl: newStu.photoDataUrl,
    };

    const nextRoster = [created, ...roster];
    onUpdateRoster(nextRoster);
    setShowAddForm(false);
    onSelectStudentForCumulative(created, autoPrintAfterSave);
    setNewStu({
      name: '',
      studentClass: 'UKG',
      photoNo: '',
      admissionNo: '',
      dob: '',
      gender: 'Male',
      fatherName: '',
      motherName: '',
      phone: '',
      bloodGroup: 'O+ve',
      address: '',
      pincode: '',
      photoDataUrl: null,
    });
  };

  const customPhotosCount = useMemo(
    () => roster.filter((s) => Boolean(s.photoDataUrl)).length,
    [roster]
  );

  return (
    <div className="bg-white border border-stone-200 rounded-xl overflow-hidden">
      <p className="mx-5 mt-5 rounded-lg border border-amber-300 bg-amber-50 p-3 text-sm text-amber-950">
        School administrator access only. Sign in with your authorized account and never share your
        password.
      </p>
      {/* Hidden File Inputs */}
      <input
        ref={singlePhotoInputRef}
        type="file"
        accept="image/*"
        onChange={handleSinglePhotoChange}
        className="hidden"
      />
      <input
        ref={bulkPhotoInputRef}
        type="file"
        accept="image/*"
        multiple
        onChange={handleBulkPhotoUpload}
        className="hidden"
      />
      <input
        ref={schoolLogoInputRef}
        type="file"
        accept="image/*"
        onChange={handleSchoolLogoUpload}
        className="hidden"
      />
      <input
        ref={rosterBackupInputRef}
        type="file"
        accept="application/json,.json"
        onChange={handleImportRoster}
        className="hidden"
      />

      {/* Webcam Capture Modal */}
      {cameraTargetStudent && (
        <div className="fixed inset-0 z-50 bg-stone-950/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white border border-stone-200 rounded-xl max-w-md w-full p-5 space-y-4 shadow-xl">
            <div className="flex items-center justify-between border-b border-stone-100 pb-3">
              <div>
                <h3 className="text-sm font-bold text-stone-900">
                  Capture Student Passport Photo
                </h3>
                <p className="text-xs text-stone-500 mt-0.5">
                  {cameraTargetStudent === 'NEW'
                    ? 'New Student Photo'
                    : `${cameraTargetStudent.name} (${cameraTargetStudent.studentClass} · Photo #${
                        cameraTargetStudent.photoNo || 'N/A'
                      })`}
                </p>
              </div>
              <button
                type="button"
                onClick={closeWebcamModal}
                className="p-1 text-stone-400 hover:text-stone-700"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {cameraError ? (
              <div className="p-4 bg-amber-50 border border-amber-200 rounded-lg text-xs text-amber-900 space-y-3">
                <p>{cameraError}</p>
                {cameraTargetStudent !== 'NEW' && (
                  <button
                    type="button"
                    onClick={() => {
                      const id = cameraTargetStudent.id;
                      closeWebcamModal();
                      handleTriggerSinglePhoto(id);
                    }}
                    className="px-3 py-1.5 bg-[#1E3A8A] text-white font-semibold rounded-md"
                  >
                    Choose Photo File Instead
                  </button>
                )}
              </div>
            ) : (
              <div className="aspect-[10/11] w-60 mx-auto bg-stone-900 rounded-lg overflow-hidden border-2 border-stone-300 relative">
                <video
                  ref={videoRef}
                  autoPlay
                  playsInline
                  muted
                  className="w-full h-full object-cover"
                />
              </div>
            )}

            <div className="flex justify-end gap-2 pt-2 border-t border-stone-100">
              <button
                type="button"
                onClick={closeWebcamModal}
                className="px-3.5 py-1.5 text-xs font-medium text-stone-600 hover:text-stone-900"
              >
                Cancel
              </button>
              {!cameraError && (
                <button
                  type="button"
                  onClick={handleCaptureWebcamPhoto}
                  className="px-4 py-1.5 text-xs font-semibold text-white bg-[#1E3A8A] hover:bg-[#172554] rounded-lg flex items-center gap-1.5"
                >
                  <Camera className="w-3.5 h-3.5" />
                  <span>Capture &amp; Save Photo</span>
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Top Action Header */}
      <div className="p-5 bg-stone-50 border-b border-stone-200 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <div className="flex flex-wrap items-center gap-2 text-xs text-stone-500">
              <span className="font-semibold text-stone-700">SAMPLE SCHOOL</span>
              <span aria-hidden="true">·</span>
              <span>{roster.length} Students</span>
              <span aria-hidden="true">·</span>
              <span className="text-emerald-700 font-semibold">
                {customPhotosCount} Custom Photos Uploaded
              </span>
              <span aria-hidden="true">·</span>
              <span>
                {useAutoPortraits
                  ? 'Official Passport Portraits Active'
                  : 'Blank Photo Frames when Empty'}
              </span>
            </div>
            <h2 className="text-lg font-semibold text-stone-900 mt-0.5">
              Student Roster, Photo Studio &amp; A4 PDF Generator
            </h2>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={handleExportRoster}
              disabled={roster.length === 0}
              className="px-3 py-2 text-xs font-semibold text-stone-800 bg-white border border-stone-300 rounded-lg hover:bg-stone-100 disabled:cursor-not-allowed disabled:opacity-50"
              title="Download a private JSON backup of the student roster and photos"
            >
              Export Roster Backup
            </button>
            <button
              type="button"
              onClick={() => rosterBackupInputRef.current?.click()}
              className="px-3 py-2 text-xs font-semibold text-stone-800 bg-white border border-stone-300 rounded-lg hover:bg-stone-100"
              title="Restore a JSON roster backup exported from this app"
            >
              Import Roster Backup
            </button>
            <button
              type="button"
              onClick={() => schoolLogoInputRef.current?.click()}
              className="px-3.5 py-2 text-xs font-semibold text-stone-800 bg-white border border-stone-300 rounded-lg hover:bg-stone-100 transition-colors whitespace-nowrap flex items-center gap-1.5"
              title="Upload a school logo to include on student ID cards"
            >
              <BadgeCheck className="w-3.5 h-3.5 text-[#1E3A8A]" />
              <span>{schoolLogoDataUrl ? 'Change School Logo' : 'Add School Logo'}</span>
            </button>
            {schoolLogoDataUrl && (
              <button
                type="button"
                onClick={() => {
                  try {
                    onSchoolLogoChange(null);
                    setBulkStatusMsg('School logo removed from ID cards.');
                  } catch (error) {
                    setBulkStatusMsg(
                      error instanceof Error ? error.message : 'Could not remove the school logo.'
                    );
                  }
                }}
                className="px-2.5 py-2 text-xs font-semibold text-rose-700 bg-rose-50 border border-rose-200 rounded-lg hover:bg-rose-100 transition-colors whitespace-nowrap"
              >
                Remove Logo
              </button>
            )}
            <button
              type="button"
              onClick={() => setShowAddForm((prev) => !prev)}
              className="px-3.5 py-2 text-xs font-semibold text-stone-900 bg-white border border-stone-300 rounded-lg hover:bg-stone-100 transition-colors whitespace-nowrap flex items-center gap-1.5"
            >
              <UserPlus className="w-3.5 h-3.5 text-[#1E3A8A]" />
              <span>{showAddForm ? 'Close Add Form' : '+ Add Student & Photo'}</span>
            </button>

            <button
              type="button"
              onClick={() => bulkPhotoInputRef.current?.click()}
              className="px-3.5 py-2 text-xs font-semibold text-white bg-emerald-700 hover:bg-emerald-800 rounded-lg transition-colors whitespace-nowrap flex items-center gap-1.5"
              title="Select one or more student photos (matched by Photo No 101..323, Admission No, Name, or assigned in order)"
            >
              <Upload className="w-3.5 h-3.5" />
              <span>Upload Student Photos (Single / Bulk)</span>
            </button>

            <button
              type="button"
              onClick={() => onToggleAutoPortraits(!useAutoPortraits)}
              className={`px-3 py-2 text-xs font-semibold rounded-lg border transition-colors whitespace-nowrap flex items-center gap-1.5 ${
                useAutoPortraits
                  ? 'bg-[#1E3A8A]/10 border-[#1E3A8A]/30 text-[#1E3A8A]'
                  : 'bg-white border-stone-300 text-stone-700 hover:bg-stone-100'
              }`}
              title="Automatically fill a clean passport ID portrait for any student without an uploaded image file"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>{useAutoPortraits ? 'Auto ID Photos: ON' : 'Auto ID Photos: OFF'}</span>
            </button>

            <button
              type="button"
              onClick={() =>
                onLoadClassIntoRegister(
                  classFilter === 'ALL' ? 'All Classes' : `${classFilter} Std`,
                  filteredStudents
                )
              }
              className="px-3.5 py-2 text-xs font-semibold text-stone-800 bg-stone-200/80 hover:bg-stone-300/80 rounded-lg transition-colors whitespace-nowrap flex items-center gap-1.5"
            >
              <Table2 className="w-3.5 h-3.5" />
              <span>Load {filteredStudents.length} into Register</span>
            </button>

            <button
              type="button"
              onClick={() =>
                onBatchPrintProfiles(
                  classFilter === 'ALL' ? 'All Classes' : `${classFilter} Std`,
                  filteredStudents
                )
              }
              className="px-4 py-2 text-xs font-semibold text-white bg-[#1E3A8A] hover:bg-[#172554] rounded-lg transition-colors whitespace-nowrap flex items-center gap-1.5"
            >
              <Layers className="w-3.5 h-3.5" />
              <span>Batch Generate PDF ({filteredStudents.length})</span>
            </button>
            <button
              type="button"
              disabled={filteredStudents.length === 0}
              onClick={() => onCreateIdCards(filteredStudents)}
              className="px-4 py-2 text-xs font-semibold text-white bg-emerald-700 hover:bg-emerald-800 disabled:opacity-50 disabled:cursor-not-allowed rounded-lg transition-colors whitespace-nowrap flex items-center gap-1.5"
            >
              <BadgeCheck className="w-3.5 h-3.5" />
              <span>Create ID Cards ({filteredStudents.length})</span>
            </button>
          </div>
        </div>

        {/* Status Notification Banner */}
        {bulkStatusMsg && (
          <div className="px-4 py-2.5 bg-emerald-50 border border-emerald-200 rounded-lg flex items-center justify-between text-xs text-emerald-900">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-700 shrink-0" />
              <span>{bulkStatusMsg}</span>
            </div>
            <button
              type="button"
              onClick={() => setBulkStatusMsg(null)}
              className="text-emerald-700 hover:text-emerald-950"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        )}

        {/* Add New Student Collapsible Form */}
        {showAddForm && (
          <form
            onSubmit={(e) => handleAddStudentSubmit(e, false)}
            className="p-4 bg-white border border-stone-200 rounded-xl space-y-4"
          >
            <div className="flex items-center justify-between border-b border-stone-100 pb-2.5">
              <h3 className="text-sm font-semibold text-stone-900">
                Add New Student &amp; Upload Passport Photo
              </h3>
              <span className="text-xs text-stone-500">
                Populates A4 Student Cumulative Record &amp; Class Teacher Register
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-start">
              {/* Photo Upload + Webcam Slot */}
              <div className="md:col-span-2 flex flex-col items-center gap-1.5">
                <input
                  ref={newStudentPhotoRef}
                  type="file"
                  accept="image/*"
                  onChange={handleNewStudentPhoto}
                  className="hidden"
                />
                <div
                  onClick={() => newStudentPhotoRef.current?.click()}
                  className="w-24 h-28 border-2 border-dashed border-stone-300 hover:border-[#1E3A8A] rounded-lg flex flex-col items-center justify-center cursor-pointer bg-stone-50 overflow-hidden relative"
                >
                  {newStu.photoDataUrl ? (
                    <img
                      src={newStu.photoDataUrl}
                      alt="New student preview"
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="text-center p-2">
                      <Camera className="w-5 h-5 mx-auto text-stone-400 mb-1" />
                      <span className="text-[11px] font-semibold text-[#1E3A8A] block">
                        + Add Photo
                      </span>
                    </div>
                  )}
                </div>
                <div className="flex items-center gap-1 w-full justify-center">
                  <button
                    type="button"
                    onClick={() => newStudentPhotoRef.current?.click()}
                    className="px-2 py-1 text-[10px] font-semibold bg-stone-100 hover:bg-stone-200 text-stone-800 rounded"
                  >
                    File
                  </button>
                  <button
                    type="button"
                    onClick={() => openWebcamFor('NEW')}
                    className="px-2 py-1 text-[10px] font-semibold bg-stone-100 hover:bg-stone-200 text-stone-800 rounded flex items-center gap-1"
                  >
                    <Video className="w-3 h-3" />
                    <span>Cam</span>
                  </button>
                </div>
              </div>

              {/* Fields Grid */}
              <div className="md:col-span-10 grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div>
                  <label className="text-[11px] font-semibold text-stone-700 block mb-1">
                    Student Name *
                  </label>
                  <input
                    type="text"
                    required
                    value={newStu.name}
                    onChange={(e) => setNewStu({ ...newStu, name: e.target.value })}
                    placeholder="e.g. ASHWIN S"
                    className="w-full px-2.5 py-1.5 text-xs border border-stone-300 rounded-md"
                  />
                </div>
                <div>
                  <label className="text-[11px] font-semibold text-stone-700 block mb-1">
                    Class *
                  </label>
                  <select
                    value={newStu.studentClass}
                    onChange={(e) => setNewStu({ ...newStu, studentClass: e.target.value })}
                    className="w-full px-2.5 py-1.5 text-xs border border-stone-300 rounded-md bg-white"
                  >
                    {['LKG', 'UKG', 'I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII'].map((c) => (
                      <option key={c} value={c}>
                        {c}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="text-[11px] font-semibold text-stone-700 block mb-1">
                    Photo No
                  </label>
                  <input
                    type="text"
                    value={newStu.photoNo}
                    onChange={(e) => setNewStu({ ...newStu, photoNo: e.target.value })}
                    placeholder="e.g. 324"
                    className="w-full px-2.5 py-1.5 text-xs border border-stone-300 rounded-md font-mono"
                  />
                </div>
                <div>
                  <label className="text-[11px] font-semibold text-stone-700 block mb-1">
                    Admission No
                  </label>
                  <input
                    type="text"
                    value={newStu.admissionNo}
                    onChange={(e) => setNewStu({ ...newStu, admissionNo: e.target.value })}
                    placeholder="e.g. 1427"
                    className="w-full px-2.5 py-1.5 text-xs border border-stone-300 rounded-md font-mono"
                  />
                </div>

                <div>
                  <label className="text-[11px] font-semibold text-stone-700 block mb-1">
                    Date of Birth
                  </label>
                  <input
                    type="text"
                    value={newStu.dob}
                    onChange={(e) => setNewStu({ ...newStu, dob: e.target.value })}
                    placeholder="DD-MM-YYYY"
                    className="w-full px-2.5 py-1.5 text-xs border border-stone-300 rounded-md font-mono"
                  />
                </div>
                <div>
                  <label className="text-[11px] font-semibold text-stone-700 block mb-1">
                    Gender
                  </label>
                  <select
                    value={newStu.gender}
                    onChange={(e) => setNewStu({ ...newStu, gender: e.target.value })}
                    className="w-full px-2.5 py-1.5 text-xs border border-stone-300 rounded-md bg-white"
                  >
                    <option value="Male">Male (ஆண்)</option>
                    <option value="Female">Female (பெண்)</option>
                  </select>
                </div>
                <div>
                  <label className="text-[11px] font-semibold text-stone-700 block mb-1">
                    Father Name
                  </label>
                  <input
                    type="text"
                    value={newStu.fatherName}
                    onChange={(e) => setNewStu({ ...newStu, fatherName: e.target.value })}
                    placeholder="Father Name"
                    className="w-full px-2.5 py-1.5 text-xs border border-stone-300 rounded-md"
                  />
                </div>
                <div>
                  <label className="text-[11px] font-semibold text-stone-700 block mb-1">
                    Mother Name
                  </label>
                  <input
                    type="text"
                    value={newStu.motherName}
                    onChange={(e) => setNewStu({ ...newStu, motherName: e.target.value })}
                    placeholder="Mother Name"
                    className="w-full px-2.5 py-1.5 text-xs border border-stone-300 rounded-md"
                  />
                </div>

                <div>
                  <label className="text-[11px] font-semibold text-stone-700 block mb-1">
                    Phone Number
                  </label>
                  <input
                    type="text"
                    value={newStu.phone}
                    onChange={(e) => setNewStu({ ...newStu, phone: e.target.value })}
                    placeholder="10-digit mobile"
                    className="w-full px-2.5 py-1.5 text-xs border border-stone-300 rounded-md font-mono"
                  />
                </div>
                <div>
                  <label className="text-[11px] font-semibold text-stone-700 block mb-1">
                    Blood Group
                  </label>
                  <input
                    type="text"
                    value={newStu.bloodGroup}
                    onChange={(e) => setNewStu({ ...newStu, bloodGroup: e.target.value })}
                    placeholder="O+ve, A+ve..."
                    className="w-full px-2.5 py-1.5 text-xs border border-stone-300 rounded-md"
                  />
                </div>
                <div className="sm:col-span-2">
                  <label className="text-[11px] font-semibold text-stone-700 block mb-1">
                    Address &amp; Pin Code
                  </label>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={newStu.address}
                      onChange={(e) => setNewStu({ ...newStu, address: e.target.value })}
                      placeholder="Street, Village, Taluk"
                      className="flex-1 px-2.5 py-1.5 text-xs border border-stone-300 rounded-md"
                    />
                    <input
                      type="text"
                      value={newStu.pincode}
                      onChange={(e) => setNewStu({ ...newStu, pincode: e.target.value })}
                      placeholder="Postal code"
                      className="w-24 px-2.5 py-1.5 text-xs border border-stone-300 rounded-md font-mono"
                    />
                  </div>
                </div>
              </div>
            </div>

            <div className="flex flex-wrap justify-end gap-2 pt-2 border-t border-stone-100">
              <button
                type="button"
                onClick={() => setShowAddForm(false)}
                className="px-3.5 py-1.5 text-xs font-medium text-stone-600 hover:text-stone-900"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-1.5 text-xs font-semibold text-stone-800 bg-stone-100 hover:bg-stone-200 rounded-lg"
              >
                Save Student &amp; View Form
              </button>
              <button
                type="button"
                onClick={(e) => handleAddStudentSubmit(e, true)}
                className="px-4 py-1.5 text-xs font-semibold text-white bg-[#1E3A8A] hover:bg-[#172554] rounded-lg flex items-center gap-1.5"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>Save &amp; Generate PDF</span>
              </button>
            </div>
          </form>
        )}

        {/* Filter Bar: Class Segmented Buttons + Search Input */}
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex flex-wrap items-center gap-1 p-1 bg-stone-200/75 rounded-lg">
            {CLASS_ORDER.map((cls) => (
              <button
                key={cls}
                type="button"
                onClick={() => setClassFilter(cls)}
                className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors whitespace-nowrap ${
                  classFilter === cls
                    ? 'bg-white text-stone-900 shadow-xs'
                    : 'text-stone-600 hover:text-stone-900'
                }`}
              >
                {cls === 'ALL' ? 'All Classes' : `Class ${cls}`} ({classCounts[cls] ?? 0})
              </button>
            ))}
          </div>

          <div className="relative flex-1 min-w-[240px] max-w-sm">
            <Search className="w-3.5 h-3.5 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search Name, Photo No (101..), Adm No, Phone..."
              className="w-full pl-8 pr-3 py-1.5 text-xs bg-white border border-stone-300 rounded-lg focus:outline-none focus:border-[#1E3A8A]"
            />
          </div>
        </div>
      </div>

      {/* Student Roster Table */}
      <div className="overflow-x-auto max-h-[680px]">
        <table className="w-full border-collapse text-left">
          <thead className="sticky top-0 z-10 bg-stone-100 border-b border-stone-200 text-[11px] font-semibold text-stone-700">
            <tr>
              <th className="py-2.5 px-3 w-10 text-center">#</th>
              <th className="py-2.5 px-3 w-36 text-center">Student Photo</th>
              <th className="py-2.5 px-3 w-20 text-center">Photo No</th>
              <th className="py-2.5 px-3">Student Name &amp; Address</th>
              <th className="py-2.5 px-3 w-16 text-center">Class</th>
              <th className="py-2.5 px-3 w-20 text-center">Adm. No</th>
              <th className="py-2.5 px-3 w-24 text-center">DOB</th>
              <th className="py-2.5 px-3">Father / Mother</th>
              <th className="py-2.5 px-3 w-28">Phone</th>
              <th className="py-2.5 px-3 w-16 text-center">Blood</th>
              <th className="py-2.5 px-3 w-52 text-right">Generate Record &amp; PDF</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-stone-200 text-xs">
            {filteredStudents.map((stu, idx) => {
              const isSelected = stu.id === selectedStudentId;
              const effectivePhoto = getEffectiveStudentPhoto(stu, useAutoPortraits);
              const hasCustomPhoto = Boolean(stu.photoDataUrl);

              return (
                <tr
                  key={stu.id}
                  className={`transition-colors ${
                    isSelected ? 'bg-[#1E3A8A]/5' : 'hover:bg-stone-50'
                  }`}
                >
                  <td className="py-2 px-3 text-center font-mono text-stone-500">
                    {stu.slNo || idx + 1}
                  </td>

                  {/* Photo Thumbnail + Explicit Add Photo & Camera Controls */}
                  <td className="py-2 px-3">
                    <div className="flex items-center justify-center gap-2">
                      <div
                        onClick={() => handleTriggerSinglePhoto(stu.id)}
                        className="w-12 h-14 border border-stone-300 rounded bg-stone-50 hover:border-[#1E3A8A] flex flex-col items-center justify-center overflow-hidden relative cursor-pointer shrink-0 group"
                        title="Click to upload student photo"
                      >
                        {effectivePhoto ? (
                          <img
                            src={effectivePhoto}
                            alt={stu.name}
                            className="w-full h-full object-cover"
                          />
                        ) : (
                          <>
                            <Camera className="w-4 h-4 text-stone-400 group-hover:text-[#1E3A8A]" />
                            <span className="text-[9px] text-stone-500 mt-0.5">Photo</span>
                          </>
                        )}
                      </div>

                      <div className="flex flex-col gap-1">
                        <button
                          type="button"
                          onClick={() => handleTriggerSinglePhoto(stu.id)}
                          className="px-2 py-1 text-[10px] font-semibold text-[#1E3A8A] bg-[#1E3A8A]/10 hover:bg-[#1E3A8A]/20 rounded transition-colors whitespace-nowrap flex items-center gap-1"
                        >
                          <Upload className="w-2.5 h-2.5" />
                          <span>{hasCustomPhoto ? 'Change' : 'Add Photo'}</span>
                        </button>
                        <div className="flex items-center gap-1">
                          <button
                            type="button"
                            onClick={() => openWebcamFor(stu)}
                            className="px-1.5 py-0.5 text-[10px] font-medium text-stone-700 bg-stone-100 hover:bg-stone-200 rounded flex items-center gap-0.5"
                            title="Capture from Camera"
                          >
                            <Video className="w-2.5 h-2.5" />
                            <span>Cam</span>
                          </button>
                          {hasCustomPhoto && (
                            <button
                              type="button"
                              onClick={() => handleRemoveCustomPhoto(stu.id)}
                              className="p-0.5 text-rose-600 hover:bg-rose-50 rounded"
                              title="Remove custom photo"
                            >
                              <Trash2 className="w-3 h-3" />
                            </button>
                          )}
                        </div>
                      </div>
                    </div>
                  </td>

                  <td className="py-2 px-3 text-center font-mono font-semibold text-stone-800">
                    {stu.photoNo ? (
                      <span className="px-1.5 py-0.5 bg-stone-100 border border-stone-200 rounded text-[11px]">
                        #{stu.photoNo}
                      </span>
                    ) : (
                      '—'
                    )}
                  </td>

                  <td className="py-2 px-3">
                    <div className="font-semibold text-stone-900">{stu.name}</div>
                    <div className="text-[11px] text-stone-500 truncate max-w-[230px]">
                      {stu.gender} · {stu.address} {stu.pincode}
                    </div>
                  </td>

                  <td className="py-2 px-3 text-center font-semibold text-stone-800">
                    {stu.studentClass}
                  </td>

                  <td className="py-2 px-3 text-center font-mono text-stone-700">
                    {stu.admissionNo || '—'}
                  </td>

                  <td className="py-2 px-3 text-center font-mono text-stone-700">
                    {stu.dob || '—'}
                  </td>

                  <td className="py-2 px-3">
                    <div className="text-stone-800 font-medium">{stu.fatherName || '—'}</div>
                    <div className="text-[11px] text-stone-500">{stu.motherName || '—'}</div>
                  </td>

                  <td className="py-2 px-3 font-mono text-stone-700">{stu.phone || '—'}</td>

                  <td className="py-2 px-3 text-center font-mono text-stone-700">
                    {stu.bloodGroup || '—'}
                  </td>

                  <td className="py-2 px-3 text-right">
                    <div className="inline-flex items-center gap-1.5">
                      <button
                        type="button"
                        onClick={() => onSelectStudentForCumulative(stu, false)}
                        className="px-2.5 py-1.5 text-[11px] font-semibold text-stone-800 bg-stone-100 hover:bg-stone-200 rounded-md transition-colors whitespace-nowrap flex items-center gap-1"
                      >
                        <FileText className="w-3 h-3" />
                        <span>Open Record</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => onSelectStudentForCumulative(stu, true)}
                        className="px-2.5 py-1.5 text-[11px] font-semibold text-white bg-[#1E3A8A] hover:bg-[#172554] rounded-md transition-colors whitespace-nowrap flex items-center gap-1"
                      >
                        <Printer className="w-3 h-3" />
                        <span>Generate PDF</span>
                      </button>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};
