export interface SubjectTermMarks {
  fa: string;
  sa: string;
  total: string;
  grade: string;
}

export interface PhysEdTermMarks {
  fitness: string;
  sportsmanship: string;
  knowledge: string;
  initiative: string;
  regularity: string;
  grade: string;
}

export interface ScholasticTermRow {
  termLabel: 'I' | 'II' | 'III' | 'Total';
  tamil: SubjectTermMarks;
  english: SubjectTermMarks;
  maths: SubjectTermMarks;
  science: SubjectTermMarks;
  social: SubjectTermMarks;
  physEd: PhysEdTermMarks;
}

export interface CoScholasticTermRow {
  termLabel: 'I' | 'II' | 'III' | 'Total';
  // Life Skills (7 cols: 5 skills + 2 grade cols as in template)
  lifeSkills: [string, string, string, string, string, string, string];
  // Attitudes & Values (5 cols: 4 skills + 1 grade col)
  attitudes: [string, string, string, string, string];
  // Wellness & Yoga (6 cols: 5 skills + 1 grade col)
  wellness: [string, string, string, string, string, string];
  // Co-Curricular Activities (6 cols: 5 skills + 1 grade col)
  coCurricular: [string, string, string, string, string, string];
}

export interface RegisterStudentEntry {
  slNo: number;
  admNo: string;
  studentName: string;
  photoNo?: string;
  photoDataUrl?: string | null;
  scholasticTerms: [ScholasticTermRow, ScholasticTermRow, ScholasticTermRow, ScholasticTermRow];
  coScholasticTerms: [
    CoScholasticTermRow,
    CoScholasticTermRow,
    CoScholasticTermRow,
    CoScholasticTermRow,
  ];
}

export interface ClassTeacherRegisterData {
  schoolName: string;
  academicYear: string;
  classAndSection: string;
  students: RegisterStudentEntry[];
}

function createEmptyScholasticRow(termLabel: 'I' | 'II' | 'III' | 'Total'): ScholasticTermRow {
  const emptySub = (): SubjectTermMarks => ({ fa: '', sa: '', total: '', grade: '' });
  return {
    termLabel,
    tamil: emptySub(),
    english: emptySub(),
    maths: emptySub(),
    science: emptySub(),
    social: emptySub(),
    physEd: {
      fitness: '',
      sportsmanship: '',
      knowledge: '',
      initiative: '',
      regularity: '',
      grade: '',
    },
  };
}

function createEmptyCoScholasticRow(termLabel: 'I' | 'II' | 'III' | 'Total'): CoScholasticTermRow {
  return {
    termLabel,
    lifeSkills: ['', '', '', '', '', '', ''],
    attitudes: ['', '', '', '', ''],
    wellness: ['', '', '', '', '', ''],
    coCurricular: ['', '', '', '', '', ''],
  };
}

export function createBlankStudentEntry(slNo: number): RegisterStudentEntry {
  return {
    slNo,
    admNo: '',
    studentName: '',
    scholasticTerms: [
      createEmptyScholasticRow('I'),
      createEmptyScholasticRow('II'),
      createEmptyScholasticRow('III'),
      createEmptyScholasticRow('Total'),
    ],
    coScholasticTerms: [
      createEmptyCoScholasticRow('I'),
      createEmptyCoScholasticRow('II'),
      createEmptyCoScholasticRow('III'),
      createEmptyCoScholasticRow('Total'),
    ],
  };
}

export const BLANK_TEACHER_REGISTER: ClassTeacherRegisterData = {
  schoolName: 'SAMPLE SCHOOL',
  academicYear: '................................',
  classAndSection: '',
  students: [
    createBlankStudentEntry(1),
    createBlankStudentEntry(2),
    createBlankStudentEntry(3),
    createBlankStudentEntry(4),
  ],
};

export const SAMPLE_TEACHER_REGISTER: ClassTeacherRegisterData = {
  schoolName: 'SAMPLE SCHOOL',
  academicYear: '2025 - 2026',
  classAndSection: 'VIII - A',
  students: [
    {
      slNo: 1,
      admNo: 'DEMO-001',
      studentName: 'SAMPLE STUDENT A',
      scholasticTerms: [
        {
          termLabel: 'I',
          tamil: { fa: '38', sa: '56', total: '94', grade: 'A1' },
          english: { fa: '36', sa: '52', total: '88', grade: 'A2' },
          maths: { fa: '39', sa: '58', total: '97', grade: 'A1' },
          science: { fa: '38', sa: '55', total: '93', grade: 'A1' },
          social: { fa: '37', sa: '54', total: '91', grade: 'A1' },
          physEd: {
            fitness: 'A',
            sportsmanship: 'A',
            knowledge: 'A',
            initiative: 'A',
            regularity: 'A',
            grade: 'A1',
          },
        },
        {
          termLabel: 'II',
          tamil: { fa: '39', sa: '57', total: '96', grade: 'A1' },
          english: { fa: '37', sa: '54', total: '91', grade: 'A1' },
          maths: { fa: '40', sa: '58', total: '98', grade: 'A1' },
          science: { fa: '39', sa: '56', total: '95', grade: 'A1' },
          social: { fa: '38', sa: '55', total: '93', grade: 'A1' },
          physEd: {
            fitness: 'A',
            sportsmanship: 'A',
            knowledge: 'A',
            initiative: 'A',
            regularity: 'A',
            grade: 'A1',
          },
        },
        {
          termLabel: 'III',
          tamil: { fa: '39', sa: '58', total: '97', grade: 'A1' },
          english: { fa: '38', sa: '55', total: '93', grade: 'A1' },
          maths: { fa: '40', sa: '59', total: '99', grade: 'A1' },
          science: { fa: '39', sa: '57', total: '96', grade: 'A1' },
          social: { fa: '38', sa: '56', total: '94', grade: 'A1' },
          physEd: {
            fitness: 'A',
            sportsmanship: 'A',
            knowledge: 'A',
            initiative: 'A',
            regularity: 'A',
            grade: 'A1',
          },
        },
        {
          termLabel: 'Total',
          tamil: { fa: '39', sa: '57', total: '96', grade: 'A1' },
          english: { fa: '37', sa: '54', total: '91', grade: 'A1' },
          maths: { fa: '40', sa: '58', total: '98', grade: 'A1' },
          science: { fa: '39', sa: '56', total: '95', grade: 'A1' },
          social: { fa: '38', sa: '55', total: '93', grade: 'A1' },
          physEd: {
            fitness: 'A',
            sportsmanship: 'A',
            knowledge: 'A',
            initiative: 'A',
            regularity: 'A',
            grade: 'A1',
          },
        },
      ],
      coScholasticTerms: [
        {
          termLabel: 'I',
          lifeSkills: ['A', 'A', 'A', 'A', 'A', 'A', 'A'],
          attitudes: ['A', 'A', 'A', 'A', 'A'],
          wellness: ['A', 'A', 'A', 'A', 'A', 'A'],
          coCurricular: ['A', 'B+', 'A', 'A', 'A', 'A'],
        },
        {
          termLabel: 'II',
          lifeSkills: ['A', 'A', 'A', 'A', 'A', 'A', 'A'],
          attitudes: ['A', 'A', 'A', 'A', 'A'],
          wellness: ['A', 'A', 'A', 'A', 'A', 'A'],
          coCurricular: ['A', 'A', 'A', 'A', 'A', 'A'],
        },
        {
          termLabel: 'III',
          lifeSkills: ['A', 'A', 'A', 'A', 'A', 'A', 'A'],
          attitudes: ['A', 'A', 'A', 'A', 'A'],
          wellness: ['A', 'A', 'A', 'A', 'A', 'A'],
          coCurricular: ['A', 'A', 'A', 'A', 'A', 'A'],
        },
        {
          termLabel: 'Total',
          lifeSkills: ['A', 'A', 'A', 'A', 'A', 'A', 'A'],
          attitudes: ['A', 'A', 'A', 'A', 'A'],
          wellness: ['A', 'A', 'A', 'A', 'A', 'A'],
          coCurricular: ['A', 'A', 'A', 'A', 'A', 'A'],
        },
      ],
    },
    {
      slNo: 2,
      admNo: 'DEMO-002',
      studentName: 'SAMPLE STUDENT B',
      scholasticTerms: [
        {
          termLabel: 'I',
          tamil: { fa: '39', sa: '57', total: '96', grade: 'A1' },
          english: { fa: '38', sa: '56', total: '94', grade: 'A1' },
          maths: { fa: '37', sa: '54', total: '91', grade: 'A1' },
          science: { fa: '38', sa: '55', total: '93', grade: 'A1' },
          social: { fa: '39', sa: '56', total: '95', grade: 'A1' },
          physEd: {
            fitness: 'A',
            sportsmanship: 'A',
            knowledge: 'A',
            initiative: 'A',
            regularity: 'A',
            grade: 'A1',
          },
        },
        {
          termLabel: 'II',
          tamil: { fa: '39', sa: '58', total: '97', grade: 'A1' },
          english: { fa: '39', sa: '56', total: '95', grade: 'A1' },
          maths: { fa: '38', sa: '55', total: '93', grade: 'A1' },
          science: { fa: '39', sa: '56', total: '95', grade: 'A1' },
          social: { fa: '39', sa: '57', total: '96', grade: 'A1' },
          physEd: {
            fitness: 'A',
            sportsmanship: 'A',
            knowledge: 'A',
            initiative: 'A',
            regularity: 'A',
            grade: 'A1',
          },
        },
        {
          termLabel: 'III',
          tamil: { fa: '40', sa: '58', total: '98', grade: 'A1' },
          english: { fa: '39', sa: '57', total: '96', grade: 'A1' },
          maths: { fa: '39', sa: '56', total: '95', grade: 'A1' },
          science: { fa: '39', sa: '57', total: '96', grade: 'A1' },
          social: { fa: '40', sa: '58', total: '98', grade: 'A1' },
          physEd: {
            fitness: 'A',
            sportsmanship: 'A',
            knowledge: 'A',
            initiative: 'A',
            regularity: 'A',
            grade: 'A1',
          },
        },
        {
          termLabel: 'Total',
          tamil: { fa: '39', sa: '58', total: '97', grade: 'A1' },
          english: { fa: '39', sa: '56', total: '95', grade: 'A1' },
          maths: { fa: '38', sa: '55', total: '93', grade: 'A1' },
          science: { fa: '39', sa: '56', total: '95', grade: 'A1' },
          social: { fa: '39', sa: '57', total: '96', grade: 'A1' },
          physEd: {
            fitness: 'A',
            sportsmanship: 'A',
            knowledge: 'A',
            initiative: 'A',
            regularity: 'A',
            grade: 'A1',
          },
        },
      ],
      coScholasticTerms: [
        {
          termLabel: 'I',
          lifeSkills: ['A', 'A', 'A', 'A', 'A', 'A', 'A'],
          attitudes: ['A', 'A', 'A', 'A', 'A'],
          wellness: ['A', 'A', 'A', 'A', 'A', 'A'],
          coCurricular: ['A', 'A', 'A', 'A', 'A', 'A'],
        },
        {
          termLabel: 'II',
          lifeSkills: ['A', 'A', 'A', 'A', 'A', 'A', 'A'],
          attitudes: ['A', 'A', 'A', 'A', 'A'],
          wellness: ['A', 'A', 'A', 'A', 'A', 'A'],
          coCurricular: ['A', 'A', 'A', 'A', 'A', 'A'],
        },
        {
          termLabel: 'III',
          lifeSkills: ['A', 'A', 'A', 'A', 'A', 'A', 'A'],
          attitudes: ['A', 'A', 'A', 'A', 'A'],
          wellness: ['A', 'A', 'A', 'A', 'A', 'A'],
          coCurricular: ['A', 'A', 'A', 'A', 'A', 'A'],
        },
        {
          termLabel: 'Total',
          lifeSkills: ['A', 'A', 'A', 'A', 'A', 'A', 'A'],
          attitudes: ['A', 'A', 'A', 'A', 'A'],
          wellness: ['A', 'A', 'A', 'A', 'A', 'A'],
          coCurricular: ['A', 'A', 'A', 'A', 'A', 'A'],
        },
      ],
    },
    createBlankStudentEntry(3),
    createBlankStudentEntry(4),
  ],
};

export function computeGradeFromMarks(score100: number): string {
  if (score100 >= 91) return 'A1';
  if (score100 >= 81) return 'A2';
  if (score100 >= 71) return 'B1';
  if (score100 >= 61) return 'B2';
  if (score100 >= 51) return 'C1';
  if (score100 >= 41) return 'C2';
  if (score100 >= 33) return 'D';
  return 'E';
}

export function generateTeacherRegisterCss(): string {
  return `/* ==========================================================================
   Class Teacher Assessment Record & Co-Scholastic Areas Register
   Print-Ready A4 Landscape Stylesheet (ISO 216: 297mm × 210mm)
   ========================================================================== */

@page {
    size: A4 landscape;
    margin: 5mm;
}

* {
    box-sizing: border-box;
    -webkit-print-color-adjust: exact;
    print-color-adjust: exact;
}

body {
    font-family: 'Plus Jakarta Sans', Arial, sans-serif;
    font-size: 8.5pt;
    margin: 0;
    padding: 0;
    background: #fff;
    color: #000;
    font-variant-numeric: tabular-nums;
}

.page {
    width: 287mm;
    min-height: 198mm;
    margin: 0 auto 20px auto;
    padding: 6px;
    background: #ffffff;
    page-break-after: always;
    break-after: page;
}

.page:last-of-type {
    page-break-after: auto;
    break-after: auto;
}

.header-title {
    text-align: right;
    font-weight: 700;
    font-size: 11pt;
    margin-bottom: 5px;
    text-transform: uppercase;
    letter-spacing: 0.02em;
}

.school-title {
    font-size: 11pt;
    font-weight: 700;
    margin-bottom: 5px;
}

.school-title span {
    text-decoration: underline;
    text-underline-offset: 3px;
}

.year-title {
    float: right;
    font-weight: 700;
    font-size: 9.5pt;
}

.clearfix::after {
    content: "";
    clear: both;
    display: table;
}

table {
    width: 100%;
    border-collapse: collapse;
    margin-bottom: 10px;
    table-layout: fixed;
}

th, td {
    border: 1px solid #000;
    text-align: center;
    vertical-align: middle;
    padding: 3px 2px;
    font-size: 8pt;
}

thead th {
    background-color: #f8fafc;
    font-weight: 700;
}

th.vertical-cell {
    height: 158px;
    padding: 6px 2px;
    vertical-align: bottom;
    text-align: center;
    overflow: hidden;
}

.vertical-text {
    writing-mode: vertical-rl;
    transform: rotate(180deg);
    display: inline-block;
    max-height: 146px;
    white-space: normal;
    word-break: break-word;
    line-height: 1.12;
    font-size: 7.2pt;
    text-align: left;
    margin: 0 auto;
}

.left-align {
    text-align: left;
    padding-left: 5px;
}

.row-total {
    background-color: #f2f2f2;
    font-weight: 700;
}

@media print {
    body {
        background: #ffffff;
    }
    .page {
        width: 100%;
        min-height: auto;
        margin: 0;
        padding: 2px;
        box-shadow: none;
    }
}`;
}

export function generateTeacherRegisterHtml(data: ClassTeacherRegisterData): string {
  const css = generateTeacherRegisterCss();

  const renderSubjectCells = (m: SubjectTermMarks) =>
    `<td>${m.fa}</td><td>${m.sa}</td><td>${m.total}</td><td>${m.grade}</td>`;

  const renderPhysEdCells = (p: PhysEdTermMarks) =>
    `<td>${p.fitness}</td><td>${p.sportsmanship}</td><td>${p.knowledge}</td><td>${p.initiative}</td><td>${p.regularity}</td><td>${p.grade}</td>`;

  const renderStudentNameHtml = (stu: RegisterStudentEntry) => {
    const imgHtml = stu.photoDataUrl
      ? `<img src="${stu.photoDataUrl}" alt="${stu.studentName}" style="width: 34px; height: 40px; object-fit: cover; border: 1px solid #000; float: left; margin-right: 5px;" />`
      : '';
    const metaHtml = stu.photoNo
      ? `<div style="font-size: 7pt; color: #333;">Photo #${stu.photoNo}${stu.admNo ? ' | Adm: ' + stu.admNo : ''}</div>`
      : '';
    return `${imgHtml}<div style="font-weight: bold;">${stu.studentName}</div>${metaHtml}`;
  };

  const scholasticBodyHtml = data.students
    .map((stu) => {
      return stu.scholasticTerms
        .map((row, tIdx) => {
          const isTotal = row.termLabel === 'Total';
          const trClass = isTotal ? ' class="row-total"' : '';
          const firstCols =
            tIdx === 0
              ? `\n                    <td rowspan="4">${stu.slNo}</td>\n                    <td rowspan="4" class="left-align">${renderStudentNameHtml(stu)}</td>`
              : '';
          return `                <tr${trClass}>${firstCols}
                    <td>${row.termLabel}</td>
                    ${renderSubjectCells(row.tamil)}
                    ${renderSubjectCells(row.english)}
                    ${renderSubjectCells(row.maths)}
                    ${renderSubjectCells(row.science)}
                    ${renderSubjectCells(row.social)}
                    ${renderPhysEdCells(row.physEd)}
                </tr>`;
        })
        .join('\n');
    })
    .join('\n\n');

  const coScholasticBodyHtml = data.students
    .map((stu) => {
      return stu.coScholasticTerms
        .map((row, tIdx) => {
          const isTotal = row.termLabel === 'Total';
          const trClass = isTotal ? ' class="row-total"' : '';
          const firstCols =
            tIdx === 0
              ? `\n                    <td rowspan="4">${stu.slNo}</td>\n                    <td rowspan="4">${stu.admNo}</td>\n                    <td rowspan="4" class="left-align">${renderStudentNameHtml(stu)}</td>`
              : '';
          const lifeCells = row.lifeSkills.map((c) => `<td>${c}</td>`).join('');
          const attCells = row.attitudes.map((c) => `<td>${c}</td>`).join('');
          const wellCells = row.wellness.map((c) => `<td>${c}</td>`).join('');
          const coCurrCells = row.coCurricular.map((c) => `<td>${c}</td>`).join('');

          return `                <tr${trClass}>${firstCols}
                    <td>${row.termLabel}</td>
                    ${lifeCells}
                    ${attCells}
                    ${wellCells}
                    ${coCurrCells}
                </tr>`;
        })
        .join('\n');
    })
    .join('\n\n');

  return `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Class Teacher Assessment Record</title>
    <style>
${css}
    </style>
</head>
<body>

    <!-- PAGE 1: SCHOLASTIC AREAS (Tamil, English, Mathematics, Science, Social Science, Physical Education) -->
    <div class="page">
        <div class="clearfix">
            <div class="school-title" style="float: left;">School Name : <span>${data.schoolName}</span></div>
            <div class="header-title" style="float: right;">CLASS TEACHER ASSESSMENT RECORD</div>
        </div>
        <div class="clearfix" style="margin-bottom: 5px;">
            <div class="year-title">Year : ${data.academicYear}</div>
        </div>

        <table>
            <thead>
                <tr>
                    <th rowspan="2" style="width: 3%;">Sl. No.</th>
                    <th rowspan="2" style="width: 15%;">Name of the Student</th>
                    <th rowspan="2" style="width: 4%;">Term</th>
                    <th colspan="4">Tamil</th>
                    <th colspan="4">English</th>
                    <th colspan="4">Mathematics</th>
                    <th colspan="4">Science</th>
                    <th colspan="4">Social Science</th>
                    <th colspan="6">Physical Education</th>
                </tr>
                <tr>
                    <!-- Tamil -->
                    <th class="vertical-cell"><div class="vertical-text">FA - 40</div></th>
                    <th class="vertical-cell"><div class="vertical-text">SA - 60</div></th>
                    <th class="vertical-cell"><div class="vertical-text">FA+SA - 100</div></th>
                    <th class="vertical-cell"><div class="vertical-text">Grade</div></th>
                    <!-- English -->
                    <th class="vertical-cell"><div class="vertical-text">FA - 40</div></th>
                    <th class="vertical-cell"><div class="vertical-text">SA - 60</div></th>
                    <th class="vertical-cell"><div class="vertical-text">FA+SA - 100</div></th>
                    <th class="vertical-cell"><div class="vertical-text">Grade</div></th>
                    <!-- Mathematics -->
                    <th class="vertical-cell"><div class="vertical-text">FA - 40</div></th>
                    <th class="vertical-cell"><div class="vertical-text">SA - 60</div></th>
                    <th class="vertical-cell"><div class="vertical-text">FA+SA - 100</div></th>
                    <th class="vertical-cell"><div class="vertical-text">Grade</div></th>
                    <!-- Science -->
                    <th class="vertical-cell"><div class="vertical-text">FA - 40</div></th>
                    <th class="vertical-cell"><div class="vertical-text">SA - 60</div></th>
                    <th class="vertical-cell"><div class="vertical-text">FA+SA - 100</div></th>
                    <th class="vertical-cell"><div class="vertical-text">Grade</div></th>
                    <!-- Social Science -->
                    <th class="vertical-cell"><div class="vertical-text">FA - 40</div></th>
                    <th class="vertical-cell"><div class="vertical-text">SA - 60</div></th>
                    <th class="vertical-cell"><div class="vertical-text">FA+SA - 100</div></th>
                    <th class="vertical-cell"><div class="vertical-text">Grade</div></th>
                    <!-- Physical Education -->
                    <th class="vertical-cell"><div class="vertical-text">Physical Fitness</div></th>
                    <th class="vertical-cell"><div class="vertical-text">Sportsmanship</div></th>
                    <th class="vertical-cell"><div class="vertical-text">Knowledge of Sport</div></th>
                    <th class="vertical-cell"><div class="vertical-text">Initiative &amp; Interest</div></th>
                    <th class="vertical-cell"><div class="vertical-text">Regularity</div></th>
                    <th class="vertical-cell"><div class="vertical-text">Grade</div></th>
                </tr>
            </thead>
            <tbody>
${scholasticBodyHtml}
            </tbody>
        </table>
    </div>

    <!-- PAGE 2: CO-SCHOLASTIC AREAS (Life Skills, Attitudes & Values, Wellness & Yoga, Co-Curricular Activities) -->
    <div class="page">
        <div class="clearfix">
            <div class="school-title" style="float: left;">School Name : <span>${data.schoolName}</span></div>
            <div class="header-title" style="float: right;">Co-Scholastic Areas</div>
        </div>
        <div class="clearfix" style="margin-bottom: 5px;">
            <div class="year-title">Year : ${data.academicYear}</div>
        </div>

        <table>
            <thead>
                <tr>
                    <th rowspan="2" style="width: 3%;">Sl. No.</th>
                    <th rowspan="2" style="width: 5%;">Adm. No.</th>
                    <th rowspan="2" style="width: 15%;">Name of the Student</th>
                    <th rowspan="2" style="width: 4%;">Term</th>
                    <th colspan="7">Life Skills</th>
                    <th colspan="5">Attitudes &amp; Values</th>
                    <th colspan="6">Wellness &amp; Yoga / Holistic Exercise</th>
                    <th colspan="6">Co-Curricular Activities</th>
                </tr>
                <tr>
                    <!-- Life Skills -->
                    <th class="vertical-cell"><div class="vertical-text">Communication Skill</div></th>
                    <th class="vertical-cell"><div class="vertical-text">Assertiveness / Refusal Skill</div></th>
                    <th class="vertical-cell"><div class="vertical-text">Rational Thinking Skill</div></th>
                    <th class="vertical-cell"><div class="vertical-text">Self Awareness</div></th>
                    <th class="vertical-cell"><div class="vertical-text">Team Work</div></th>
                    <th class="vertical-cell"><div class="vertical-text">Grade</div></th>
                    <th class="vertical-cell"><div class="vertical-text">Grade</div></th>
                    <!-- Attitudes & Values -->
                    <th class="vertical-cell"><div class="vertical-text">Courteousness</div></th>
                    <th class="vertical-cell"><div class="vertical-text">Protecting School / Public Properties</div></th>
                    <th class="vertical-cell"><div class="vertical-text">Compassion for All Living Creatures</div></th>
                    <th class="vertical-cell"><div class="vertical-text">Compliance with Safety &amp; Road Rules</div></th>
                    <th class="vertical-cell"><div class="vertical-text">Grade</div></th>
                    <!-- Wellness & Yoga -->
                    <th class="vertical-cell"><div class="vertical-text">Interest</div></th>
                    <th class="vertical-cell"><div class="vertical-text">Continuity</div></th>
                    <th class="vertical-cell"><div class="vertical-text">Regularity</div></th>
                    <th class="vertical-cell"><div class="vertical-text">Effort</div></th>
                    <th class="vertical-cell"><div class="vertical-text">Competency</div></th>
                    <th class="vertical-cell"><div class="vertical-text">Grade</div></th>
                    <!-- Co-Curricular Activities -->
                    <th class="vertical-cell"><div class="vertical-text">Effort</div></th>
                    <th class="vertical-cell"><div class="vertical-text">Initiative</div></th>
                    <th class="vertical-cell"><div class="vertical-text">Persistence</div></th>
                    <th class="vertical-cell"><div class="vertical-text">Involvement</div></th>
                    <th class="vertical-cell"><div class="vertical-text">Regularity</div></th>
                    <th class="vertical-cell"><div class="vertical-text">Grade</div></th>
                </tr>
            </thead>
            <tbody>
${coScholasticBodyHtml}
            </tbody>
        </table>
    </div>

</body>
</html>`;
}
