import React, { useRef } from 'react';
import { Camera, X } from 'lucide-react';
import { StudentRecordData, StyleConfig } from '../recordData';

interface CumulativeRecordSheetProps {
  data: StudentRecordData;
  onChange: (updated: StudentRecordData) => void;
  config: StyleConfig;
  isEditable: boolean;
  visiblePages: 'all' | 'page1' | 'page2' | 'page3';
}

export const CumulativeRecordSheet: React.FC<CumulativeRecordSheetProps> = ({
  data,
  onChange,
  config,
  isEditable,
  visiblePages,
}) => {
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const aadhaarRefs = useRef<Array<HTMLInputElement | null>>([]);

  // Compute CSS custom variables based on StyleConfig
  const paletteVars =
    config.themeId === 'tn-education-navy'
      ? {
          '--scr-border-color': '#1e3a8a',
          '--scr-inner-border-color': '#1e40af',
          '--scr-table-border-color': '#334155',
          '--scr-header-bg': '#eff6ff',
          '--scr-sub-bg': '#f8fafc',
          '--scr-text': '#0f172a',
          '--scr-page-bg': '#ffffff',
        }
      : config.themeId === 'warm-parchment'
      ? {
          '--scr-border-color': '#292524',
          '--scr-inner-border-color': '#44403c',
          '--scr-table-border-color': '#57534e',
          '--scr-header-bg': '#f5f2eb',
          '--scr-sub-bg': '#faf8f5',
          '--scr-text': '#1c1917',
          '--scr-page-bg': '#fffdf9',
        }
      : {
          '--scr-border-color': '#000000',
          '--scr-inner-border-color': '#111827',
          '--scr-table-border-color': '#1f2937',
          '--scr-header-bg': '#f3f4f6',
          '--scr-sub-bg': '#f9fafb',
          '--scr-text': '#000000',
          '--scr-page-bg': '#ffffff',
        };

  const fontVar =
    config.fontFamily === 'serif'
      ? "'Noto Serif Tamil', 'Latha', 'FreeSerif', serif"
      : "'Noto Sans Tamil', 'Latha', 'Arial Unicode MS', sans-serif";

  const densityVars =
    config.cellDensity === 'compact'
      ? { '--scr-cell-py': '2.8px', '--scr-cell-px': '5px' }
      : config.cellDensity === 'spacious'
      ? { '--scr-cell-py': '5px', '--scr-cell-px': '7.5px' }
      : { '--scr-cell-py': '3.8px', '--scr-cell-px': '6px' };

  const customVars = {
    ...paletteVars,
    ...densityVars,
    '--scr-font': fontVar,
    '--scr-outer-border-width': `${config.outerBorderPx}px`,
  } as React.CSSProperties;

  const updateField = <K extends keyof StudentRecordData>(key: K, value: StudentRecordData[K]) => {
    onChange({ ...data, [key]: value });
  };

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        updateField('photoDataUrl', reader.result);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleAadhaarChange = (index: number, rawVal: string) => {
    const digit = rawVal.replace(/\D/g, '').slice(-1);
    const nextDigits = [...data.aadhaarDigits];
    nextDigits[index] = digit;
    updateField('aadhaarDigits', nextDigits);
    if (digit && index < 11) {
      aadhaarRefs.current[index + 1]?.focus();
    }
  };

  const handleAadhaarKeyDown = (index: number, e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Backspace' && !data.aadhaarDigits[index] && index > 0) {
      aadhaarRefs.current[index - 1]?.focus();
    }
  };

  const renderCellInput = (
    value: string,
    onValueChange: (val: string) => void,
    placeholder = '',
    alignCenter = false,
    isBold = false
  ) => {
    if (!isEditable) {
      return (
        <span className={`${alignCenter ? 'block text-center' : ''} ${isBold ? 'font-bold' : ''}`}>
          {value}
        </span>
      );
    }
    return (
      <input
        type="text"
        value={value}
        onChange={(e) => onValueChange(e.target.value)}
        placeholder={placeholder}
        className={`editable-input ${alignCenter ? 'text-center' : ''} ${isBold ? 'font-bold' : ''}`}
      />
    );
  };

  const labelCellClass = config.shadeLabelCells ? 'label-cell' : 'font-medium';

  return (
    <div className="scr-document" style={customVars}>
      {/* =====================================================================
          PAGE 1: STUDENT PROFILE (மாணவர் குறிப்பு)
         ===================================================================== */}
      {(visiblePages === 'all' || visiblePages === 'page1') && (
        <div className="page" id="scr-page-1">
          <div className="page-frame">
            <div className="inner-border">
              <div>
                {/* Top Metadata + Photograph Row */}
                <div className="top-row-grid">
                  <table className="top-meta-table">
                    <tbody>
                      <tr>
                        <td style={{ width: '52%' }} className={labelCellClass}>
                          வரிசை எண்
                        </td>
                        <td>
                          {renderCellInput(data.serialNo, (v) => updateField('serialNo', v))}
                        </td>
                      </tr>
                      <tr>
                        <td className={labelCellClass}>வகுப்பும் பிரிவும்</td>
                        <td>
                          {renderCellInput(
                            data.classAndSection,
                            (v) => updateField('classAndSection', v)
                          )}
                        </td>
                      </tr>
                      <tr>
                        <td className={labelCellClass}>தேர்வு எண்</td>
                        <td>{renderCellInput(data.examNo, (v) => updateField('examNo', v))}</td>
                      </tr>
                      <tr>
                        <td className={labelCellClass}>ஆண்டு</td>
                        <td>
                          <div className="flex items-center gap-0.5">
                            <span className="font-semibold">20</span>
                            {renderCellInput(
                              data.yearSuffix,
                              (v) => updateField('yearSuffix', v),
                              '25 - 2026'
                            )}
                          </div>
                        </td>
                      </tr>
                    </tbody>
                  </table>

                  {/* Student Photo Box */}
                  <div
                    className="photo-box group cursor-pointer"
                    onClick={() => isEditable && fileInputRef.current?.click()}
                    title={isEditable ? 'புகைப்படம் பதிவேற்ற கிளிக் செய்க (Click to upload photo)' : undefined}
                  >
                    <input
                      ref={fileInputRef}
                      type="file"
                      accept="image/*"
                      onChange={handlePhotoUpload}
                      className="hidden"
                    />
                    {data.photoDataUrl ? (
                      <>
                        <img
                          src={data.photoDataUrl}
                          alt="மாணவர் புகைப்படம்"
                          className="w-full h-full object-cover"
                        />
                        {isEditable && (
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              updateField('photoDataUrl', null);
                            }}
                            className="no-print absolute top-1 right-1 bg-stone-900/80 text-white rounded p-0.5 opacity-0 group-hover:opacity-100 transition-opacity"
                            aria-label="Remove photo"
                          >
                            <X className="w-3 h-3" />
                          </button>
                        )}
                      </>
                    ) : (
                      <div className="flex flex-col items-center justify-center p-2">
                        {isEditable && (
                          <Camera className="no-print w-4 h-4 mb-1 opacity-40 group-hover:opacity-80 transition-opacity" />
                        )}
                        <span className="font-medium">புகைப்படம்</span>
                        {data.photoNo ? (
                          <span className="text-[8pt] font-mono font-bold mt-1 text-stone-800">
                            Photo #{data.photoNo}
                          </span>
                        ) : (
                          <span className="text-[7.5pt] opacity-70 mt-0.5">3.5 × 4.5 cm</span>
                        )}
                      </div>
                    )}
                  </div>
                </div>

                {/* Main Heading */}
                <div className="header-box">மாணவர் குறிப்பு</div>

                {/* Student Name Table */}
                <table>
                  <tbody>
                    <tr>
                      <td rowSpan={2} style={{ width: '25%' }} className={`bold ${labelCellClass}`}>
                        மாணவர் பெயர்
                      </td>
                      <th className="center" style={{ width: '37.5%' }}>
                        தமிழில்
                      </th>
                      <th className="center" style={{ width: '37.5%' }}>
                        ஆங்கிலத்தில்
                      </th>
                    </tr>
                    <tr>
                      <td style={{ height: '26px' }} className="center">
                        {renderCellInput(
                          data.nameTamil,
                          (v) => updateField('nameTamil', v),
                          '',
                          true,
                          true
                        )}
                      </td>
                      <td className="center">
                        {renderCellInput(
                          data.nameEnglish,
                          (v) => updateField('nameEnglish', v),
                          '',
                          true,
                          true
                        )}
                      </td>
                    </tr>
                  </tbody>
                </table>

                {/* Bio & Personal Details Table */}
                <table>
                  <tbody>
                    <tr>
                      <td style={{ width: '25%' }} className={labelCellClass}>
                        பாலினம்
                      </td>
                      <td style={{ width: '25%' }}>
                        {renderCellInput(data.gender, (v) => updateField('gender', v))}
                      </td>
                      <td style={{ width: '25%' }} className={labelCellClass}>
                        சேர்க்கை எண்
                      </td>
                      <td style={{ width: '25%' }}>
                        {renderCellInput(data.admissionNo, (v) => updateField('admissionNo', v))}
                      </td>
                    </tr>
                    <tr>
                      <td className={labelCellClass}>மதம்</td>
                      <td>{renderCellInput(data.religion, (v) => updateField('religion', v))}</td>
                      <td className={labelCellClass}>சேர்ந்த தேதியும் வகுப்பும்</td>
                      <td>
                        {renderCellInput(
                          data.admissionDateAndClass,
                          (v) => updateField('admissionDateAndClass', v)
                        )}
                      </td>
                    </tr>
                    <tr>
                      <td className={labelCellClass}>சாதி</td>
                      <td>{renderCellInput(data.caste, (v) => updateField('caste', v))}</td>
                      <td className={labelCellClass}>உட்பிரிவு</td>
                      <td>{renderCellInput(data.subCaste, (v) => updateField('subCaste', v))}</td>
                    </tr>
                    <tr>
                      <td className={labelCellClass}>பிறந்த தேதி</td>
                      <td colSpan={3}>
                        {renderCellInput(data.dob, (v) => updateField('dob', v))}
                      </td>
                    </tr>
                    <tr>
                      <td className={labelCellClass}>தந்தையின் பெயர்</td>
                      <td colSpan={3}>
                        {renderCellInput(data.fatherName, (v) => updateField('fatherName', v))}
                      </td>
                    </tr>
                    <tr>
                      <td className={labelCellClass}>தாயின் பெயர்</td>
                      <td colSpan={3}>
                        {renderCellInput(data.motherName, (v) => updateField('motherName', v))}
                      </td>
                    </tr>
                    <tr>
                      <td className={labelCellClass}>பாதுகாவலர் பெயர்</td>
                      <td colSpan={3}>
                        {renderCellInput(data.guardianName, (v) => updateField('guardianName', v))}
                      </td>
                    </tr>
                    <tr>
                      <td className={labelCellClass}>தொழில்</td>
                      <td>
                        {renderCellInput(data.occupation, (v) => updateField('occupation', v))}
                      </td>
                      <td className={labelCellClass}>ஆண்டு வருமானம்</td>
                      <td>
                        {renderCellInput(data.annualIncome, (v) => updateField('annualIncome', v))}
                      </td>
                    </tr>
                    <tr>
                      <td className={labelCellClass}>முகவரி</td>
                      <td colSpan={3} style={{ height: '38px', verticalAlign: 'top' }}>
                        {isEditable ? (
                          <textarea
                            rows={2}
                            value={data.address}
                            onChange={(e) => updateField('address', e.target.value)}
                            className="editable-input resize-none"
                          />
                        ) : (
                          <span>{data.address}</span>
                        )}
                      </td>
                    </tr>
                    <tr>
                      <td className={labelCellClass}>தொலைபேசி எண்</td>
                      <td colSpan={3}>
                        {renderCellInput(data.phone, (v) => updateField('phone', v))}
                      </td>
                    </tr>
                    <tr>
                      <td className={labelCellClass}>ஆதார் எண்</td>
                      <td colSpan={3}>
                        <div className="aadhaar-group py-0.5">
                          {[0, 1, 2].map((quadIndex) => (
                            <div key={quadIndex} className="aadhaar-quad">
                              {[0, 1, 2, 3].map((offset) => {
                                const idx = quadIndex * 4 + offset;
                                return (
                                  <span key={idx} className="digit-box">
                                    {isEditable ? (
                                      <input
                                        ref={(el) => {
                                          aadhaarRefs.current[idx] = el;
                                        }}
                                        type="text"
                                        inputMode="numeric"
                                        maxLength={1}
                                        value={data.aadhaarDigits[idx] || ''}
                                        onChange={(e) => handleAadhaarChange(idx, e.target.value)}
                                        onKeyDown={(e) => handleAadhaarKeyDown(idx, e)}
                                        className="editable-input text-center font-mono font-semibold"
                                      />
                                    ) : (
                                      data.aadhaarDigits[idx] || ''
                                    )}
                                  </span>
                                );
                              })}
                            </div>
                          ))}
                        </div>
                      </td>
                    </tr>
                    <tr>
                      <td className={labelCellClass}>EMIS எண்</td>
                      <td colSpan={3}>
                        {renderCellInput(data.emisNo, (v) => updateField('emisNo', v))}
                      </td>
                    </tr>
                    <tr>
                      <td className={labelCellClass}>சேமிப்பு எண்</td>
                      <td colSpan={3}>
                        {renderCellInput(data.savingsNo, (v) => updateField('savingsNo', v))}
                      </td>
                    </tr>
                    <tr>
                      <td className={labelCellClass}>குருதி வகை</td>
                      <td colSpan={3}>
                        {renderCellInput(data.bloodGroup, (v) => updateField('bloodGroup', v))}
                      </td>
                    </tr>
                    <tr>
                      <td className={labelCellClass}>உடல் நல நிலை</td>
                      <td>
                        {renderCellInput(data.healthStatus, (v) => updateField('healthStatus', v))}
                      </td>
                      <td colSpan={2}>
                        <div className="grid grid-cols-2 gap-2 items-center">
                          <div className="flex items-center gap-1.5">
                            <span className="font-medium shrink-0">உயரம்:</span>
                            {renderCellInput(data.heightCm, (v) => updateField('heightCm', v))}
                          </div>
                          <div className="flex items-center gap-1.5">
                            <span className="font-medium shrink-0">எடை:</span>
                            {renderCellInput(data.weightKg, (v) => updateField('weightKg', v))}
                          </div>
                        </div>
                      </td>
                    </tr>
                    <tr>
                      <td className={labelCellClass}>மாற்றுத்திறனாளியா?</td>
                      <td>
                        {renderCellInput(
                          data.isDifferentlyAbled,
                          (v) => updateField('isDifferentlyAbled', v)
                        )}
                      </td>
                      <td className={labelCellClass}>அதன் தன்மை</td>
                      <td>
                        {renderCellInput(
                          data.disabilityNature,
                          (v) => updateField('disabilityNature', v)
                        )}
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>

              {/* Signatures Footer */}
              <table className="signature-table">
                <tbody>
                  <tr>
                    <td className="center" style={{ width: '50%' }}>
                      பெற்றோர் கையொப்பம்
                    </td>
                    <td className="center" style={{ width: '50%' }}>
                      வகுப்பாசிரியர் கையொப்பம்
                    </td>
                  </tr>
                  <tr style={{ height: '24px' }}>
                    <td colSpan={2} style={{ paddingTop: 0 }} />
                  </tr>
                  <tr>
                    <td className="center">பள்ளி முத்திரை</td>
                    <td className="center">தலைமை ஆசிரியர் கையொப்பம்</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* =====================================================================
          PAGE 2: CUMULATIVE RECORD (மாணவர் திரள் பதிவேடு)
         ===================================================================== */}
      {(visiblePages === 'all' || visiblePages === 'page2') && (
        <div className="page" id="scr-page-2">
          <div className="page-frame">
            <div className="inner-border">
              <div>
                <div className="header-box" style={{ fontSize: '13pt', marginBottom: '6px' }}>
                  மாணவர் திரள் பதிவேடு
                </div>

                {/* Part 1: Scholastic Assessment */}
                <div className="header-box sub-section">
                  பகுதி - 1 கற்றல் வெளிப்பாடு - கல்விச்சார் பகுதிகள்
                </div>

                <table>
                  <thead>
                    <tr>
                      <th rowSpan={2} className="center" style={{ width: '28%' }}>
                        பாடம்
                      </th>
                      <th colSpan={3} className="center">
                        பருவம் - 1 தரநிலை
                      </th>
                      <th colSpan={3} className="center">
                        பருவம் - 2 தரநிலை
                      </th>
                      <th colSpan={3} className="center">
                        பருவம் - 3 தரநிலை
                      </th>
                    </tr>
                    <tr>
                      <th className="center" style={{ width: '8%' }}>
                        FA
                      </th>
                      <th className="center" style={{ width: '8%' }}>
                        SA
                      </th>
                      <th className="center" style={{ width: '8%' }}>
                        Total
                      </th>
                      <th className="center" style={{ width: '8%' }}>
                        FA
                      </th>
                      <th className="center" style={{ width: '8%' }}>
                        SA
                      </th>
                      <th className="center" style={{ width: '8%' }}>
                        Total
                      </th>
                      <th className="center" style={{ width: '8%' }}>
                        FA
                      </th>
                      <th className="center" style={{ width: '8%' }}>
                        SA
                      </th>
                      <th className="center" style={{ width: '8%' }}>
                        Total
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    {data.academicRows.map((row, rIdx) => {
                      const updateAcademicCell = (
                        termKey: 'term1' | 'term2' | 'term3',
                        subKey: 'fa' | 'sa' | 'total',
                        val: string
                      ) => {
                        const next = data.academicRows.map((item, idx) =>
                          idx === rIdx
                            ? { ...item, [termKey]: { ...item[termKey], [subKey]: val } }
                            : item
                        );
                        updateField('academicRows', next);
                      };

                      return (
                        <tr key={row.subject}>
                          <td className={labelCellClass}>{row.subject}</td>
                          <td className="center">
                            {row.isStarred ? (
                              <span>★★</span>
                            ) : (
                              renderCellInput(
                                row.term1.fa,
                                (v) => updateAcademicCell('term1', 'fa', v),
                                '',
                                true
                              )
                            )}
                          </td>
                          <td className="center">
                            {row.isStarred ? (
                              <span>★★</span>
                            ) : (
                              renderCellInput(
                                row.term1.sa,
                                (v) => updateAcademicCell('term1', 'sa', v),
                                '',
                                true
                              )
                            )}
                          </td>
                          <td className="center bold">
                            {renderCellInput(
                              row.term1.total,
                              (v) => updateAcademicCell('term1', 'total', v),
                              '',
                              true,
                              true
                            )}
                          </td>

                          <td className="center">
                            {row.isStarred ? (
                              <span>★★</span>
                            ) : (
                              renderCellInput(
                                row.term2.fa,
                                (v) => updateAcademicCell('term2', 'fa', v),
                                '',
                                true
                              )
                            )}
                          </td>
                          <td className="center">
                            {row.isStarred ? (
                              <span>★★</span>
                            ) : (
                              renderCellInput(
                                row.term2.sa,
                                (v) => updateAcademicCell('term2', 'sa', v),
                                '',
                                true
                              )
                            )}
                          </td>
                          <td className="center bold">
                            {renderCellInput(
                              row.term2.total,
                              (v) => updateAcademicCell('term2', 'total', v),
                              '',
                              true,
                              true
                            )}
                          </td>

                          <td className="center">
                            {row.isStarred ? (
                              <span>★★</span>
                            ) : (
                              renderCellInput(
                                row.term3.fa,
                                (v) => updateAcademicCell('term3', 'fa', v),
                                '',
                                true
                              )
                            )}
                          </td>
                          <td className="center">
                            {row.isStarred ? (
                              <span>★★</span>
                            ) : (
                              renderCellInput(
                                row.term3.sa,
                                (v) => updateAcademicCell('term3', 'sa', v),
                                '',
                                true
                              )
                            )}
                          </td>
                          <td className="center bold">
                            {renderCellInput(
                              row.term3.total,
                              (v) => updateAcademicCell('term3', 'total', v),
                              '',
                              true,
                              true
                            )}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>

                {/* Part 2: Co-Curricular Activities Summary */}
                <div className="header-box sub-section">
                  பகுதி - 2 கல்வி இணைச் செயல்பாடுகள் (சுருக்கம்)
                </div>

                <table>
                  <thead>
                    <tr>
                      <th className="center" style={{ width: '46%' }}>
                        செயல்பாடுகள் (Co-Scholastic Domains)
                      </th>
                      <th className="center" style={{ width: '18%' }}>
                        பருவம் - 1
                      </th>
                      <th className="center" style={{ width: '18%' }}>
                        பருவம் - 2
                      </th>
                      <th className="center" style={{ width: '18%' }}>
                        பருவம் - 3
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    {data.coCurricularRows.map((row, rIdx) => {
                      const updateCoCell = (
                        termKey: 'term1' | 'term2' | 'term3',
                        val: string
                      ) => {
                        const next = data.coCurricularRows.map((item, idx) =>
                          idx === rIdx ? { ...item, [termKey]: val } : item
                        );
                        updateField('coCurricularRows', next);
                      };
                      return (
                        <tr key={row.activity}>
                          <td className={labelCellClass}>{row.activity}</td>
                          <td className="center">
                            {renderCellInput(
                              row.term1,
                              (v) => updateCoCell('term1', v),
                              '',
                              true
                            )}
                          </td>
                          <td className="center">
                            {renderCellInput(
                              row.term2,
                              (v) => updateCoCell('term2', v),
                              '',
                              true
                            )}
                          </td>
                          <td className="center">
                            {renderCellInput(
                              row.term3,
                              (v) => updateCoCell('term3', v),
                              '',
                              true
                            )}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>

                {/* Special Talent / Achievement Box */}
                <table>
                  <thead>
                    <tr>
                      <th className="center">
                        மாணவர் வெளிப்படுத்திய செயல்திறன் / ஆற்றல் / தனித்திறன் ஏதேனும் ஒன்று
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td style={{ height: '36px', verticalAlign: 'middle' }}>
                        {renderCellInput(
                          data.specialTalent,
                          (v) => updateField('specialTalent', v)
                        )}
                      </td>
                    </tr>
                  </tbody>
                </table>

                {/* Year-End Overall Grade & Attendance Split */}
                <div className="header-box sub-section">ஆண்டு இறுதி தரநிலை</div>

                <div className="split-tables">
                  {/* Left Table: Final Overall Grades */}
                  <table style={{ marginBottom: 0 }}>
                    <thead>
                      <tr>
                        <th className="center" style={{ width: '62%' }}>
                          பாடம்
                        </th>
                        <th className="center" style={{ width: '38%' }}>
                          ஒட்டு மொத்த தரநிலை
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      {data.finalAcademicGrades.map((row, idx) => (
                        <tr key={row.subject}>
                          <td className={labelCellClass}>{row.subject}</td>
                          <td className="center bold">
                            {renderCellInput(
                              row.grade,
                              (v) => {
                                const next = data.finalAcademicGrades.map((item, i) =>
                                  i === idx ? { ...item, grade: v } : item
                                );
                                updateField('finalAcademicGrades', next);
                              },
                              '',
                              true,
                              true
                            )}
                          </td>
                        </tr>
                      ))}
                      <tr>
                        <th colSpan={2} className="center">
                          கல்வி இணைச் செயல்பாடுகள்
                        </th>
                      </tr>
                      {data.finalCoCurricularGrades.map((row, idx) => (
                        <tr key={row.subject}>
                          <td className={labelCellClass}>{row.subject}</td>
                          <td className="center bold">
                            {renderCellInput(
                              row.grade,
                              (v) => {
                                const next = data.finalCoCurricularGrades.map((item, i) =>
                                  i === idx ? { ...item, grade: v } : item
                                );
                                updateField('finalCoCurricularGrades', next);
                              },
                              '',
                              true,
                              true
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>

                  {/* Right Table: Attendance & Term Signatures */}
                  <table style={{ marginBottom: 0 }}>
                    <thead>
                      <tr>
                        <th style={{ width: '46%' }}>வருகை விவரம்</th>
                        <th className="center" style={{ width: '18%' }}>
                          பருவம்-1
                        </th>
                        <th className="center" style={{ width: '18%' }}>
                          பருவம்-2
                        </th>
                        <th className="center" style={{ width: '18%' }}>
                          பருவம்-3
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td className={labelCellClass}>வேலை நாட்களின் எண்ணிக்கை</td>
                        {[0, 1, 2].map((tIdx) => (
                          <td key={tIdx} className="center">
                            {renderCellInput(
                              data.workingDays[tIdx],
                              (v) => {
                                const next: [string, string, string] = [...data.workingDays] as [
                                  string,
                                  string,
                                  string,
                                ];
                                next[tIdx] = v;
                                updateField('workingDays', next);
                              },
                              '',
                              true
                            )}
                          </td>
                        ))}
                      </tr>
                      <tr>
                        <td className={labelCellClass}>மாணவர் வருகை நாட்கள்</td>
                        {[0, 1, 2].map((tIdx) => (
                          <td key={tIdx} className="center">
                            {renderCellInput(
                              data.presentDays[tIdx],
                              (v) => {
                                const next: [string, string, string] = [...data.presentDays] as [
                                  string,
                                  string,
                                  string,
                                ];
                                next[tIdx] = v;
                                updateField('presentDays', next);
                              },
                              '',
                              true
                            )}
                          </td>
                        ))}
                      </tr>
                      <tr>
                        <td className={labelCellClass}>வருகை சதவீதம்</td>
                        {[0, 1, 2].map((tIdx) => (
                          <td key={tIdx} className="center">
                            {renderCellInput(
                              data.attendancePercent[tIdx],
                              (v) => {
                                const next: [string, string, string] = [
                                  ...data.attendancePercent,
                                ] as [string, string, string];
                                next[tIdx] = v;
                                updateField('attendancePercent', next);
                              },
                              '',
                              true
                            )}
                          </td>
                        ))}
                      </tr>
                      <tr style={{ height: '34px' }}>
                        <td className={labelCellClass}>வகுப்பாசிரியர் கையொப்பம்</td>
                        <td />
                        <td />
                        <td />
                      </tr>
                      <tr style={{ height: '34px' }}>
                        <td className={labelCellClass}>தலைமையாசிரியர் கையொப்பம்</td>
                        <td />
                        <td />
                        <td />
                      </tr>
                      <tr style={{ height: '34px' }}>
                        <td className={labelCellClass}>பெற்றோர் கையொப்பம்</td>
                        <td />
                        <td />
                        <td />
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Final Exam Result Row */}
              <table style={{ marginTop: '6px', marginBottom: 0 }}>
                <tbody>
                  <tr>
                    <th className="center" style={{ width: '30%' }}>
                      தேர்வு முடிவு
                    </th>
                    <td style={{ height: '24px' }} className="bold">
                      {renderCellInput(
                        data.finalResult,
                        (v) => updateField('finalResult', v),
                        '',
                        false,
                        true
                      )}
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* =====================================================================
          PAGE 3: DETAILED CO-SCHOLASTIC AREAS & CLASS TEACHER ASSESSMENT RECORD
                  (இணைக் கல்விசார் பகுதிகள் & வகுப்பாசிரியர் மதிப்பீட்டுப் பதிவேடு)
         ===================================================================== */}
      {(visiblePages === 'all' || visiblePages === 'page3') && (
        <div className="page" id="scr-page-3">
          <div className="page-frame">
            <div className="inner-border">
              <div>
                {/* Page 3 Header */}
                <div className="header-box" style={{ fontSize: '12.5pt', marginBottom: '6px' }}>
                  இணைக் கல்விசார் பகுதிகள் &amp; வகுப்பாசிரியர் மதிப்பீட்டுப் பதிவேடு
                  <span className="sub-en" style={{ fontSize: '8pt', marginTop: '1px' }}>
                    CO-SCHOLASTIC AREAS &amp; CLASS TEACHER ASSESSMENT RECORD
                  </span>
                </div>

                {/* Co-Scholastic Grading Legend Strip */}
                <div className="grade-scale-strip">
                  <span>
                    <strong>தர அளவுகோல் (Grading Scale):</strong>
                  </span>
                  <span>
                    <strong>A</strong> : மிகச் சிறப்பு (Outstanding)
                  </span>
                  <span>
                    <strong>B+ / B</strong> : நன்று (Very Good / Good)
                  </span>
                  <span>
                    <strong>C</strong> : முன்னேற்றம் தேவை (Needs Improvement)
                  </span>
                </div>

                {/* Section 2 (Expanded): Co-Scholastic Areas Detailed Record */}
                <div className="header-box sub-section">
                  பகுதி - 2 (விரிவான பதிவேடு): இணைக் கல்விசார் பகுதிகள் (Co-Scholastic Areas Record)
                </div>

                <table>
                  <thead>
                    <tr>
                      <th className="center" style={{ width: '6%' }}>
                        பிரிவு
                      </th>
                      <th className="center" style={{ width: '32%' }}>
                        இணைக் கல்விசார் திறன் பகுதி
                        <span className="sub-en">Co-Scholastic Area &amp; Sub-Skill</span>
                      </th>
                      <th className="center" style={{ width: '34%' }}>
                        விவரிப்புக் குறியீடுகள்
                        <span className="sub-en">Descriptive Indicators / Evidence</span>
                      </th>
                      <th className="center" style={{ width: '7%' }}>
                        ப-1
                      </th>
                      <th className="center" style={{ width: '7%' }}>
                        ப-2
                      </th>
                      <th className="center" style={{ width: '7%' }}>
                        ப-3
                      </th>
                      <th className="center" style={{ width: '7%' }}>
                        மொத்தம்
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    {data.detailedCoScholastic.map((item, idx) => {
                      const updateCoItem = (
                        key: 'descriptiveIndicator' | 'term1' | 'term2' | 'term3' | 'overall',
                        val: string
                      ) => {
                        const next = data.detailedCoScholastic.map((row, i) =>
                          i === idx ? { ...row, [key]: val } : row
                        );
                        updateField('detailedCoScholastic', next);
                      };

                      return (
                        <tr key={`${item.domainCode}-${idx}`}>
                          <td className="center bold">{item.domainCode}</td>
                          <td className={labelCellClass}>
                            <div>{item.subSkillTamil}</div>
                            <span className="sub-en">{item.subSkillEnglish}</span>
                          </td>
                          <td>
                            {renderCellInput(item.descriptiveIndicator, (v) =>
                              updateCoItem('descriptiveIndicator', v)
                            )}
                          </td>
                          <td className="center">
                            {renderCellInput(
                              item.term1,
                              (v) => updateCoItem('term1', v),
                              '',
                              true
                            )}
                          </td>
                          <td className="center">
                            {renderCellInput(
                              item.term2,
                              (v) => updateCoItem('term2', v),
                              '',
                              true
                            )}
                          </td>
                          <td className="center">
                            {renderCellInput(
                              item.term3,
                              (v) => updateCoItem('term3', v),
                              '',
                              true
                            )}
                          </td>
                          <td className="center bold">
                            {renderCellInput(
                              item.overall,
                              (v) => updateCoItem('overall', v),
                              '',
                              true,
                              true
                            )}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>

                {/* Section 3: Class Teacher Assessment Record */}
                <div className="header-box sub-section">
                  பகுதி - 3: வகுப்பாசிரியர் மதிப்பீட்டுப் பதிவேடு (Class Teacher Assessment Record)
                </div>

                <table>
                  <thead>
                    <tr>
                      <th className="center" style={{ width: '36%' }}>
                        மதிப்பீட்டுக் கூறுகள் (Assessment Parameters)
                      </th>
                      <th className="center" style={{ width: '8%' }}>
                        பருவம்-1
                      </th>
                      <th className="center" style={{ width: '8%' }}>
                        பருவம்-2
                      </th>
                      <th className="center" style={{ width: '8%' }}>
                        பருவம்-3
                      </th>
                      <th className="center" style={{ width: '40%' }}>
                        வகுப்பாசிரியர் சிறப்புக் குறிப்புகள் (Teacher Remarks)
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    {data.classTeacherEvaluations.map((row, idx) => {
                      const updateEval = (
                        key: 'term1' | 'term2' | 'term3' | 'remarks',
                        val: string
                      ) => {
                        const next = data.classTeacherEvaluations.map((item, i) =>
                          i === idx ? { ...item, [key]: val } : item
                        );
                        updateField('classTeacherEvaluations', next);
                      };

                      return (
                        <tr key={row.parameterTamil}>
                          <td className={labelCellClass}>
                            <div>{row.parameterTamil}</div>
                            <span className="sub-en">{row.parameterEnglish}</span>
                          </td>
                          <td className="center bold">
                            {renderCellInput(
                              row.term1,
                              (v) => updateEval('term1', v),
                              '',
                              true,
                              true
                            )}
                          </td>
                          <td className="center bold">
                            {renderCellInput(
                              row.term2,
                              (v) => updateEval('term2', v),
                              '',
                              true,
                              true
                            )}
                          </td>
                          <td className="center bold">
                            {renderCellInput(
                              row.term3,
                              (v) => updateEval('term3', v),
                              '',
                              true,
                              true
                            )}
                          </td>
                          <td>
                            {renderCellInput(row.remarks, (v) => updateEval('remarks', v))}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>

                {/* Term-Wise Class Teacher Qualitative Observations */}
                <div className="header-box sub-section">
                  பருவ வாரியான வகுப்பாசிரியர் உற்றுநோக்கல் &amp; தொடர் நடவடிக்கை (Term-wise Observations)
                </div>

                <table>
                  <thead>
                    <tr>
                      <th className="center" style={{ width: '14%' }}>
                        பருவம்
                      </th>
                      <th className="center" style={{ width: '24%' }}>
                        மாணவரின் பலம்
                        <span className="sub-en">Key Strengths</span>
                      </th>
                      <th className="center" style={{ width: '22%' }}>
                        மேம்படுத்த வேண்டியவை
                        <span className="sub-en">Areas for Improvement</span>
                      </th>
                      <th className="center" style={{ width: '22%' }}>
                        ஆசிரியர் வழிகாட்டல்
                        <span className="sub-en">Teacher Action Plan</span>
                      </th>
                      <th className="center" style={{ width: '18%' }}>
                        பெற்றோர் கருத்து
                        <span className="sub-en">Parent Note</span>
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    {data.classTeacherObservations.map((obs, idx) => {
                      const updateObs = (
                        key:
                          | 'strengths'
                          | 'improvementAreas'
                          | 'teacherActionPlan'
                          | 'parentFeedback',
                        val: string
                      ) => {
                        const next = data.classTeacherObservations.map((item, i) =>
                          i === idx ? { ...item, [key]: val } : item
                        );
                        updateField('classTeacherObservations', next);
                      };

                      return (
                        <tr key={obs.termLabel}>
                          <td className={`bold ${labelCellClass}`}>{obs.termLabel}</td>
                          <td>
                            {renderCellInput(obs.strengths, (v) => updateObs('strengths', v))}
                          </td>
                          <td>
                            {renderCellInput(obs.improvementAreas, (v) =>
                              updateObs('improvementAreas', v)
                            )}
                          </td>
                          <td>
                            {renderCellInput(obs.teacherActionPlan, (v) =>
                              updateObs('teacherActionPlan', v)
                            )}
                          </td>
                          <td>
                            {renderCellInput(obs.parentFeedback, (v) =>
                              updateObs('parentFeedback', v)
                            )}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>

                {/* Overall Year-End Class Teacher Recommendation */}
                <table style={{ marginBottom: 0 }}>
                  <tbody>
                    <tr>
                      <th className="center" style={{ width: '28%' }}>
                        வகுப்பாசிரியர் ஆண்டு இறுதிப் பரிந்துரை
                        <span className="sub-en">Overall Recommendation</span>
                      </th>
                      <td style={{ height: '30px' }}>
                        {renderCellInput(
                          data.classTeacherOverallRecommendation,
                          (v) => updateField('classTeacherOverallRecommendation', v)
                        )}
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>

              {/* Page 3 Signatures Block */}
              <table className="signature-table" style={{ marginTop: '6px' }}>
                <tbody>
                  <tr>
                    <td className="center" style={{ width: '33%' }}>
                      வகுப்பாசிரியர் கையொப்பம்
                      <span className="sub-en">(Class Teacher Signature)</span>
                    </td>
                    <td className="center" style={{ width: '34%' }}>
                      பெற்றோர் / பாதுகாவலர் கையொப்பம்
                      <span className="sub-en">(Parent / Guardian Signature)</span>
                    </td>
                    <td className="center" style={{ width: '33%' }}>
                      தலைமை ஆசிரியர் கையொப்பம்
                      <span className="sub-en">(Headmaster Signature &amp; Seal)</span>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
