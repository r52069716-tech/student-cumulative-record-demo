import React from 'react';
import { RosterStudent, getEffectiveStudentPhoto } from '../schoolStudentsRoster';
import { StyleConfig } from '../recordData';

interface BatchStudentProfilesSheetProps {
  classLabel: string;
  students: RosterStudent[];
  config: StyleConfig;
  useAutoPortraits: boolean;
  onSelectSingleStudent: (student: RosterStudent) => void;
  onTriggerPrint: () => void;
}

export const BatchStudentProfilesSheet: React.FC<BatchStudentProfilesSheetProps> = ({
  classLabel,
  students,
  config,
  useAutoPortraits,
  onSelectSingleStudent,
  onTriggerPrint,
}) => {
  const labelCellClass = config.shadeLabelCells ? 'label-cell' : 'font-medium';

  return (
    <div className="space-y-6">
      {/* Top Batch Action Bar (Hidden in Print) */}
      <div className="no-print bg-white border border-stone-200 rounded-xl p-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <span className="text-xs font-semibold text-[#1E3A8A] uppercase tracking-wider">
            Batch A4 PDF Ready · {classLabel}
          </span>
          <h2 className="text-base font-bold text-stone-900 mt-0.5">
            {students.length} Student Cumulative Record Sheets (மாணவர் குறிப்பு) with Photos
          </h2>
          <p className="text-xs text-stone-500">
            Each student below is formatted on a dedicated A4 portrait page with their passport photo
            for one-click PDF saving.
          </p>
        </div>

        <button
          type="button"
          onClick={onTriggerPrint}
          className="px-4 py-2.5 text-xs font-semibold text-white bg-[#1E3A8A] hover:bg-[#172554] rounded-lg transition-colors whitespace-nowrap"
        >
          Print / Save All {students.length} Pages as PDF
        </button>
      </div>

      {/* Render A4 Page for Each Student */}
      <div className="scr-document">
        {students.map((stu, idx) => {
          const photoUrl = getEffectiveStudentPhoto(stu, useAutoPortraits);
          const fullAddress = [stu.address, stu.pincode].filter(Boolean).join(' - ');

          return (
            <div key={stu.id} className="page">
              <div className="page-frame">
                <div className="inner-border">
                  {/* Quick Jump Link (Hidden in Print) */}
                  <div className="no-print flex items-center justify-between mb-2 pb-1.5 border-b border-dashed border-stone-300 text-xs">
                    <span className="font-mono font-semibold text-stone-600">
                      Page {idx + 1} of {students.length} · {stu.name} ({stu.studentClass})
                    </span>
                    <button
                      type="button"
                      onClick={() => onSelectSingleStudent(stu)}
                      className="text-[#1E3A8A] font-semibold hover:underline"
                    >
                      Edit Full 3-Page Record →
                    </button>
                  </div>

                  {/* Top Metadata + Photograph Row */}
                  <div className="top-row-grid">
                    <table className="top-meta-table">
                      <tbody>
                        <tr>
                          <td style={{ width: '52%' }} className={labelCellClass}>
                            வரிசை எண் (Sl. No.)
                          </td>
                          <td className="font-semibold">{stu.slNo || idx + 1}</td>
                        </tr>
                        <tr>
                          <td className={labelCellClass}>வகுப்பும் பிரிவும் (Class)</td>
                          <td className="font-semibold">{stu.studentClass}</td>
                        </tr>
                        <tr>
                          <td className={labelCellClass}>புகைப்பட எண் (Photo No.)</td>
                          <td className="font-mono font-semibold">{stu.photoNo || '—'}</td>
                        </tr>
                        <tr>
                          <td className={labelCellClass}>ஆண்டு (Academic Year)</td>
                          <td className="font-semibold">2025 - 2026</td>
                        </tr>
                      </tbody>
                    </table>

                    {/* Student Photo Box */}
                    <div className="photo-box">
                      {photoUrl ? (
                        <img
                          src={photoUrl}
                          alt={stu.name}
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <div className="flex flex-col items-center justify-center p-2 text-center">
                          <span>மாணவர்</span>
                          <span>புகைப்படம்</span>
                          <span className="text-[7.5pt] mt-1 font-mono">
                            {stu.photoNo ? `#${stu.photoNo}` : ''}
                          </span>
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="header-box">மாணவர் குறிப்பு — STUDENT CUMULATIVE PROFILE</div>

                  {/* School & Student Core Details */}
                  <table>
                    <tbody>
                      <tr>
                        <td style={{ width: '38%' }} className={labelCellClass}>
                          பள்ளியின் பெயர் (School Name)
                        </td>
                        <td colSpan={3} className="font-bold">
                          SAMPLE SCHOOL
                        </td>
                      </tr>
                      <tr>
                        <td className={labelCellClass}>மாணவர் பெயர் (Student Name)</td>
                        <td colSpan={3} className="font-bold text-[10.5pt]">
                          {stu.name}
                        </td>
                      </tr>
                      <tr>
                        <td className={labelCellClass}>பாலினம் (Gender)</td>
                        <td style={{ width: '22%' }}>
                          {stu.gender === 'Female' ? 'பெண் (Female)' : 'ஆண் (Male)'}
                        </td>
                        <td style={{ width: '18%' }} className={labelCellClass}>
                          பிறந்த தேதி (DOB)
                        </td>
                        <td style={{ width: '22%' }} className="font-mono font-semibold">
                          {stu.dob || '—'}
                        </td>
                      </tr>
                    </tbody>
                  </table>

                  {/* Parents, Address & Phone */}
                  <table>
                    <tbody>
                      <tr>
                        <td rowSpan={2} style={{ width: '18%' }} className={labelCellClass}>
                          பெற்றோர் (Parents)
                        </td>
                        <td style={{ width: '20%' }} className={labelCellClass}>
                          தந்தை பெயர் (Father)
                        </td>
                        <td style={{ width: '62%' }} className="font-semibold">
                          {stu.fatherName || '—'}
                        </td>
                      </tr>
                      <tr>
                        <td className={labelCellClass}>தாய் பெயர் (Mother)</td>
                        <td className="font-semibold">{stu.motherName || '—'}</td>
                      </tr>
                      <tr>
                        <td colSpan={2} className={labelCellClass}>
                          முகவரி &amp; அஞ்சல் குறியீடு (Address &amp; Pin Code)
                        </td>
                        <td>{fullAddress || '—'}</td>
                      </tr>
                      <tr>
                        <td colSpan={2} className={labelCellClass}>
                          தொலைபேசி எண் (Phone Number)
                        </td>
                        <td className="font-mono font-semibold">{stu.phone || '—'}</td>
                      </tr>
                    </tbody>
                  </table>

                  {/* Admission, Blood Group & Identification */}
                  <table>
                    <tbody>
                      <tr>
                        <td style={{ width: '38%' }} className={labelCellClass}>
                          சேர்க்கை எண் (Admission Number)
                        </td>
                        <td style={{ width: '22%' }} className="font-mono font-bold">
                          {stu.admissionNo || '—'}
                        </td>
                        <td style={{ width: '20%' }} className={labelCellClass}>
                          இரத்த வகை (Blood Group)
                        </td>
                        <td style={{ width: '20%' }} className="font-mono font-bold">
                          {stu.bloodGroup || '—'}
                        </td>
                      </tr>
                      <tr>
                        <td className={labelCellClass}>புகைப்பட அடையாள எண் (Photo ID No.)</td>
                        <td className="font-mono font-semibold">{stu.photoNo || '—'}</td>
                        <td className={labelCellClass}>தாய்மொழி (Mother Tongue)</td>
                        <td>தமிழ் (Tamil)</td>
                      </tr>
                      <tr>
                        <td className={labelCellClass}>தேசிய இனம் (Nationality)</td>
                        <td>இந்தியன் (Indian)</td>
                        <td className={labelCellClass}>பயிலும் வகுப்பு (Class)</td>
                        <td className="font-bold">{stu.studentClass}</td>
                      </tr>
                    </tbody>
                  </table>

                  {/* Signatures Footer */}
                  <table className="signature-table" style={{ marginTop: '18px' }}>
                    <tbody>
                      <tr>
                        <td style={{ width: '33%' }} className="center bold">
                          பெற்றோர் கையொப்பம்
                          <div className="text-[7.5pt] font-normal mt-0.5">(Parent Signature)</div>
                        </td>
                        <td style={{ width: '34%' }} className="center bold">
                          வகுப்பாசிரியர் கையொப்பம்
                          <div className="text-[7.5pt] font-normal mt-0.5">
                            (Class Teacher Signature)
                          </div>
                        </td>
                        <td style={{ width: '33%' }} className="center bold">
                          தலைமையாசிரியர் கையொப்பம்
                          <div className="text-[7.5pt] font-normal mt-0.5">
                            (Headmaster Signature)
                          </div>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
