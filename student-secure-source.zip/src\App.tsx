/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo, useRef, useEffect } from 'react';
import {
  Printer,
  Copy,
  Check,
  Download,
  FileCode2,
  FileText,
  RotateCcw,
  Sparkles,
  Edit3,
  Eye,
  Calculator,
  Award,
  UserPlus,
  UserMinus,
  FileDown,
  Camera,
  Upload,
  Users,
  LogOut,
} from 'lucide-react';
import type { Session } from '@supabase/supabase-js';
import {
  BLANK_RECORD_DATA,
  StudentRecordData,
  StyleConfig,
  generateCleanStylesheet,
  generateFullHtmlDocument,
} from './recordData';
import {
  BLANK_TEACHER_REGISTER,
  ClassTeacherRegisterData,
  createBlankStudentEntry,
  computeGradeFromMarks,
  generateTeacherRegisterCss,
  generateTeacherRegisterHtml,
  SubjectTermMarks,
} from './teacherRegisterData';
import {
  INITIAL_SCHOOL_ROSTER,
  RosterStudent,
  mapRosterStudentToCumulativeRecord,
  mapRosterStudentsToTeacherRegister,
  getEffectiveStudentPhoto,
} from './schoolStudentsRoster';
import { CumulativeRecordSheet } from './components/CumulativeRecordSheet';
import { ClassTeacherRegisterSheet } from './components/ClassTeacherRegisterSheet';
import { StudentRosterManager } from './components/StudentRosterManager';
import { BatchStudentProfilesSheet } from './components/BatchStudentProfilesSheet';
import { StudentIdCardsSheet } from './components/StudentIdCardsSheet';
import { CloudAuthPanel } from './components/CloudAuthPanel';
import {
  cloudConfigurationError,
  loadSchoolSnapshot,
  restoreSession,
  saveSchoolSnapshot,
  supabase,
} from './cloudStorage';

type MainView =
  | 'student-roster'
  | 'cumulative-all'
  | 'teacher-register'
  | 'batch-pdf'
  | 'id-cards'
  | 'css-code';

const ROSTER_STORAGE_KEY = 'student_demo_roster_v1';
const SCHOOL_LOGO_STORAGE_KEY = 'student_demo_school_logo_v1';
const requiresCloudAuth = import.meta.env.VITE_REQUIRE_AUTH === 'true';

export default function App() {
  // Load the empty demo roster, preserving entries added by the current browser.
  const [roster, setRoster] = useState<RosterStudent[]>(() => {
    if (supabase) return INITIAL_SCHOOL_ROSTER;
    try {
      const saved = localStorage.getItem(ROSTER_STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed;
        }
      }
    } catch {
      // ignore storage error
    }
    return INITIAL_SCHOOL_ROSTER;
  });

  const [useAutoPortraits, setUseAutoPortraits] = useState<boolean>(true);
  const [selectedStudentId, setSelectedStudentId] = useState<string>(
    () => INITIAL_SCHOOL_ROSTER[0]?.id || 'stu-1'
  );

  // Open the roster so visitors can try adding a demo student.
  const [activeView, setActiveView] = useState<MainView>('student-roster');
  const [cumulativePageFilter, setCumulativePageFilter] = useState<
    'all' | 'page1' | 'page2' | 'page3'
  >('all');
  const [registerSubPage, setRegisterSubPage] = useState<'both' | 'scholastic' | 'coscholastic'>(
    'both'
  );

  // Batch PDF state
  const [batchClassLabel, setBatchClassLabel] = useState<string>('UKG Std');
  const [batchStudentIds, setBatchStudentIds] = useState<string[]>(() =>
    INITIAL_SCHOOL_ROSTER.filter((s) => s.studentClass === 'UKG').map((s) => s.id)
  );
  const [idCardStudentIds, setIdCardStudentIds] = useState<string[]>([]);
  const [schoolLogoDataUrl, setSchoolLogoDataUrl] = useState<string | null>(() => {
    if (supabase) return null;
    try {
      return localStorage.getItem(SCHOOL_LOGO_STORAGE_KEY);
    } catch {
      return null;
    }
  });

  const selectedStudent = useMemo(
    () => roster.find((s) => s.id === selectedStudentId) || roster[0],
    [roster, selectedStudentId]
  );

  const [recordData, setRecordData] = useState<StudentRecordData>(() =>
    mapRosterStudentToCumulativeRecord(
      INITIAL_SCHOOL_ROSTER[0] || { id: 'stu-1', slNo: '1', name: '', studentClass: 'UKG', photoNo: '', phone: '', fatherName: '', motherName: '', dob: '', gender: 'Male', address: '', pincode: '', bloodGroup: '', admissionNo: '' },
      undefined,
      true
    )
  );
  const [recordsByStudent, setRecordsByStudent] = useState<
    Record<string, StudentRecordData>
  >({});

  const [registerData, setRegisterData] = useState<ClassTeacherRegisterData>(() =>
    mapRosterStudentsToTeacherRegister(
      'UKG Std',
      INITIAL_SCHOOL_ROSTER.filter((s) => s.studentClass === 'UKG'),
      true
    )
  );
  const [registersByClass, setRegistersByClass] = useState<
    Record<string, ClassTeacherRegisterData>
  >({});

  const [dataMode, setDataMode] = useState<'sample' | 'blank'>('sample');
  const [isEditable, setIsEditable] = useState<boolean>(true);
  const [codeDocTarget, setCodeDocTarget] = useState<'register' | 'cumulative'>('cumulative');
  const [codeFormat, setCodeFormat] = useState<'css' | 'html'>('html');
  const [copiedCss, setCopiedCss] = useState<boolean>(false);
  const [copiedCodeBlock, setCopiedCodeBlock] = useState<boolean>(false);

  const sidebarPhotoInputRef = useRef<HTMLInputElement | null>(null);

  const [styleConfig, setStyleConfig] = useState<StyleConfig>({
    themeId: 'archival-mono',
    fontFamily: 'sans',
    cellDensity: 'standard',
    outerBorderPx: 2,
    shadeLabelCells: true,
  });
  const [session, setSession] = useState<Session | null>(null);
  const [isAuthChecking, setIsAuthChecking] = useState(Boolean(supabase));
  const [isCloudHydrated, setIsCloudHydrated] = useState(!supabase);
  const [cloudMessage, setCloudMessage] = useState<string | null>(null);
  const [cloudLoadAttempt, setCloudLoadAttempt] = useState(0);
  const [cloudSaveAttempt, setCloudSaveAttempt] = useState(0);
  const cloudSaveQueue = useRef<Promise<void>>(Promise.resolve());

  useEffect(() => {
    if (!supabase) {
      setIsAuthChecking(false);
      return;
    }

    let active = true;
    restoreSession()
      .then((restoredSession) => {
        if (active) setSession(restoredSession);
      })
      .catch((error: unknown) => {
        if (active) {
          setCloudMessage(
            `Could not restore cloud sign-in: ${
              error instanceof Error ? error.message : 'Unknown error'
            }`,
          );
        }
      })
      .finally(() => {
        if (active) setIsAuthChecking(false);
      });

    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((_event, nextSession) => {
      setSession(nextSession);
      if (!nextSession) setIsCloudHydrated(false);
    });

    return () => {
      active = false;
      subscription.unsubscribe();
    };
  }, []);

  useEffect(() => {
    if (!supabase || !session) return;

    let active = true;
    setIsCloudHydrated(false);
    setCloudMessage('Loading your school data from the cloud…');
    loadSchoolSnapshot(session.user.id)
      .then((snapshot) => {
        if (!active) return;
        if (snapshot) {
          setRoster(snapshot.roster);
          setRecordData(snapshot.recordData);
          setRecordsByStudent(snapshot.recordsByStudent);
          setRegisterData(snapshot.registerData);
          setRegistersByClass(snapshot.registersByClass);
          setSchoolLogoDataUrl(snapshot.schoolLogoDataUrl);
          setSelectedStudentId(snapshot.selectedStudentId);
          setStyleConfig(snapshot.styleConfig);
          setBatchClassLabel(snapshot.batchClassLabel);
          setBatchStudentIds(snapshot.batchStudentIds);
          setIdCardStudentIds(snapshot.idCardStudentIds);
          setCloudMessage('Cloud data loaded.');
        } else {
          setCloudMessage('No cloud copy yet. Your current school data will be uploaded.');
        }
        setIsCloudHydrated(true);
      })
      .catch((error: unknown) => {
        if (!active) return;
        setCloudMessage(
          `Cloud data could not be loaded: ${
            error instanceof Error ? error.message : 'Unknown error'
          }`,
        );
      });

    return () => {
      active = false;
    };
  }, [session?.user.id, cloudLoadAttempt]);

  useEffect(() => {
    if (!supabase || !session || !isCloudHydrated) return;

    const snapshot = {
      roster,
      recordData,
      recordsByStudent,
      registerData,
      registersByClass,
      schoolLogoDataUrl,
      selectedStudentId,
      styleConfig,
      batchClassLabel,
      batchStudentIds,
      idCardStudentIds,
    };
    const timeout = window.setTimeout(() => {
      setCloudMessage('Saving changes to the cloud…');
      const save = cloudSaveQueue.current.then(() =>
        saveSchoolSnapshot(session.user.id, snapshot),
      );
      cloudSaveQueue.current = save.catch(() => undefined);
      save
        .then(() => setCloudMessage('All changes saved to the cloud.'))
        .catch((error: unknown) =>
          setCloudMessage(
            `Cloud save failed: ${error instanceof Error ? error.message : 'Unknown error'}`,
          ),
        );
    }, 800);

    return () => window.clearTimeout(timeout);
  }, [
    roster,
    recordData,
    recordsByStudent,
    registerData,
    registersByClass,
    schoolLogoDataUrl,
    selectedStudentId,
    styleConfig,
    batchClassLabel,
    batchStudentIds,
    idCardStudentIds,
    session?.user.id,
    isCloudHydrated,
    cloudSaveAttempt,
  ]);

  useEffect(() => {
    if (!selectedStudentId) return;
    setRecordsByStudent((previous) =>
      previous[selectedStudentId] === recordData
        ? previous
        : { ...previous, [selectedStudentId]: recordData },
    );
  }, [recordData, selectedStudentId]);

  useEffect(() => {
    const classKey = registerData.classAndSection.trim();
    if (!classKey) return;
    setRegistersByClass((previous) =>
      previous[classKey] === registerData
        ? previous
        : { ...previous, [classKey]: registerData },
    );
  }, [registerData]);

  // Save roster updates to localStorage safely
  const handleUpdateRoster = (nextRoster: RosterStudent[]) => {
    setRoster(nextRoster);
    if (!supabase) {
      try {
        localStorage.setItem(ROSTER_STORAGE_KEY, JSON.stringify(nextRoster));
      } catch {
        // Quota exceeded when many high-res photos uploaded; keep in memory
      }
    }

    // Also keep active Cumulative Record photo in sync if the active student was updated
    const updatedActive = nextRoster.find((s) => s.id === selectedStudentId);
    if (updatedActive) {
      setRecordData((prev) => ({
        ...prev,
        photoDataUrl: getEffectiveStudentPhoto(updatedActive, useAutoPortraits),
      }));
    }
  };

  // Sync when toggling Auto Portraits
  useEffect(() => {
    if (selectedStudent) {
      setRecordData((prev) => ({
        ...prev,
        photoDataUrl: getEffectiveStudentPhoto(selectedStudent, useAutoPortraits),
      }));
    }
  }, [useAutoPortraits, selectedStudent]);

  // When user uploads/clears photo inside CumulativeRecordSheet, sync it back to the student roster
  const handleRecordDataChange = (updated: StudentRecordData) => {
    setRecordData(updated);
    if (updated.photoDataUrl !== recordData.photoDataUrl && selectedStudentId) {
      const nextRoster = roster.map((s) =>
        s.id === selectedStudentId ? { ...s, photoDataUrl: updated.photoDataUrl } : s
      );
      setRoster(nextRoster);
      if (!supabase) {
        try {
          localStorage.setItem(ROSTER_STORAGE_KEY, JSON.stringify(nextRoster));
        } catch {
          // ignore
        }
      }
    }
  };

  // Upload photo for currently selected student from right-hand Quick Photo card
  const handleSidebarPhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !selectedStudent) return;
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        const dataUrl = reader.result;
        const nextRoster = roster.map((s) =>
          s.id === selectedStudent.id ? { ...s, photoDataUrl: dataUrl } : s
        );
        handleUpdateRoster(nextRoster);
        setRecordData((prev) => ({ ...prev, photoDataUrl: dataUrl }));
      }
    };
    reader.readAsDataURL(file);
    e.target.value = '';
  };

  const handleSelectStudentForCumulative = (student: RosterStudent, autoPrint = false) => {
    setSelectedStudentId(student.id);
    const mapped =
      recordsByStudent[student.id] ||
      mapRosterStudentToCumulativeRecord(student, undefined, useAutoPortraits);
    setRecordData(mapped);
    setActiveView('cumulative-all');
    if (autoPrint) {
      setTimeout(() => window.print(), 180);
    }
  };

  const handleLoadClassIntoRegister = (classLabel: string, students: RosterStudent[]) => {
    const mappedReg =
      registersByClass[classLabel] ||
      mapRosterStudentsToTeacherRegister(classLabel, students, useAutoPortraits);
    setRegisterData(mappedReg);
    setRegistersByClass((previous) => ({ ...previous, [classLabel]: mappedReg }));
    setActiveView('teacher-register');
  };

  const handleBatchPrintProfiles = (classLabel: string, students: RosterStudent[]) => {
    setBatchClassLabel(classLabel);
    setBatchStudentIds(students.map((s) => s.id));
    setActiveView('batch-pdf');
    setTimeout(() => window.print(), 220);
  };

  const batchStudentsList = useMemo(() => {
    const idSet = new Set(batchStudentIds);
    const matches = roster.filter((s) => idSet.has(s.id));
    return matches.length > 0 ? matches : roster.slice(0, 15);
  }, [roster, batchStudentIds]);

  const idCardStudentsList = useMemo(() => {
    const idSet = new Set(idCardStudentIds);
    return roster.filter((student) => idSet.has(student.id));
  }, [roster, idCardStudentIds]);

  const handleOpenIdCards = (students: RosterStudent[]) => {
    setIdCardStudentIds(students.map((student) => student.id));
    setActiveView('id-cards');
  };

  const handleSchoolLogoChange = (logoDataUrl: string | null) => {
    if (!supabase) {
      try {
        if (logoDataUrl) {
          localStorage.setItem(SCHOOL_LOGO_STORAGE_KEY, logoDataUrl);
        } else {
          localStorage.removeItem(SCHOOL_LOGO_STORAGE_KEY);
        }
      } catch {
        throw new Error('Could not save the school logo. Try a smaller image file.');
      }
    }
    setSchoolLogoDataUrl(logoDataUrl);
  };

  const isLandscapeRegisterActive =
    activeView === 'teacher-register' ||
    activeView === 'id-cards' ||
    (activeView === 'css-code' && codeDocTarget === 'register');

  const cumulativeCss = useMemo(() => generateCleanStylesheet(styleConfig), [styleConfig]);
  const cumulativeHtml = useMemo(
    () => generateFullHtmlDocument(recordData, styleConfig),
    [recordData, styleConfig]
  );

  const registerCss = useMemo(() => generateTeacherRegisterCss(), []);
  const registerHtml = useMemo(() => generateTeacherRegisterHtml(registerData), [registerData]);

  const activeCss = isLandscapeRegisterActive ? registerCss : cumulativeCss;
  const activeHtml = isLandscapeRegisterActive ? registerHtml : cumulativeHtml;

  const handleLoadPreset = (mode: 'sample' | 'blank') => {
    setDataMode(mode);
    if (mode === 'sample') {
      if (selectedStudent) {
        setRecordData(
          mapRosterStudentToCumulativeRecord(selectedStudent, undefined, useAutoPortraits)
        );
      }
      setRegisterData(
        mapRosterStudentsToTeacherRegister(
          'UKG Std',
          roster.filter((s) => s.studentClass === 'UKG').slice(0, 12),
          useAutoPortraits
        )
      );
    } else {
      setRecordData(JSON.parse(JSON.stringify(BLANK_RECORD_DATA)));
      setRegisterData(JSON.parse(JSON.stringify(BLANK_TEACHER_REGISTER)));
    }
  };

  const handleAddStudentToRegister = () => {
    setRegisterData((prev) => {
      const nextSl = prev.students.length + 1;
      return {
        ...prev,
        students: [...prev.students, createBlankStudentEntry(nextSl)],
      };
    });
  };

  const handleRemoveLastStudentFromRegister = () => {
    setRegisterData((prev) => {
      if (prev.students.length <= 1) return prev;
      return {
        ...prev,
        students: prev.students.slice(0, -1),
      };
    });
  };

  const handleComputeRegisterTotals = () => {
    setRegisterData((prev) => {
      const subjects: Array<'tamil' | 'english' | 'maths' | 'science' | 'social'> = [
        'tamil',
        'english',
        'maths',
        'science',
        'social',
      ];
      const nextStudents = prev.students.map((stu) => {
        const nextScholastic = [...stu.scholasticTerms] as typeof stu.scholasticTerms;
        const totalRow = { ...nextScholastic[3] };

        subjects.forEach((subKey) => {
          const faVals: number[] = [];
          const saVals: number[] = [];
          for (let i = 0; i < 3; i++) {
            const f = parseFloat(nextScholastic[i][subKey].fa);
            const s = parseFloat(nextScholastic[i][subKey].sa);
            if (!isNaN(f)) faVals.push(f);
            if (!isNaN(s)) saVals.push(s);
          }
          if (faVals.length > 0 && saVals.length > 0) {
            const avgFa = Math.round(faVals.reduce((a, b) => a + b, 0) / faVals.length);
            const avgSa = Math.round(saVals.reduce((a, b) => a + b, 0) / saVals.length);
            const sum = avgFa + avgSa;
            const computed: SubjectTermMarks = {
              fa: String(avgFa),
              sa: String(avgSa),
              total: String(sum),
              grade: computeGradeFromMarks(sum),
            };
            totalRow[subKey] = computed;
          }
        });

        nextScholastic[3] = totalRow;
        return {
          ...stu,
          scholasticTerms: nextScholastic,
        };
      });

      return { ...prev, students: nextStudents };
    });
  };

  const handleApplyCoScholasticGrade = (grade: string) => {
    if (activeView === 'teacher-register') {
      setRegisterData((prev) => ({
        ...prev,
        students: prev.students.map((stu) => ({
          ...stu,
          coScholasticTerms: stu.coScholasticTerms.map((row) => ({
            ...row,
            lifeSkills: Array(7).fill(grade) as typeof row.lifeSkills,
            attitudes: Array(5).fill(grade) as typeof row.attitudes,
            wellness: Array(6).fill(grade) as typeof row.wellness,
            coCurricular: Array(6).fill(grade) as typeof row.coCurricular,
          })) as typeof stu.coScholasticTerms,
        })),
      }));
    } else {
      setRecordData((prev) => ({
        ...prev,
        coCurricularRows: prev.coCurricularRows.map((r) => ({
          ...r,
          term1: grade,
          term2: grade,
          term3: grade,
        })),
        finalCoCurricularGrades: prev.finalCoCurricularGrades.map((r) => ({
          ...r,
          grade,
        })),
        detailedCoScholastic: prev.detailedCoScholastic.map((item) => ({
          ...item,
          term1: grade,
          term2: grade,
          term3: grade,
          overall: grade,
        })),
      }));
    }
  };

  const handleRecalculateAttendance = () => {
    setRecordData((prev) => {
      const nextPercent: [string, string, string] = ['0%', '0%', '0%'];
      for (let i = 0; i < 3; i++) {
        const w = parseFloat(prev.workingDays[i]);
        const p = parseFloat(prev.presentDays[i]);
        if (!isNaN(w) && !isNaN(p) && w > 0) {
          nextPercent[i] = `${((p / w) * 100).toFixed(1)}%`;
        } else {
          nextPercent[i] = prev.attendancePercent[i];
        }
      }
      return {
        ...prev,
        attendancePercent: nextPercent,
      };
    });
  };

  const handleCopyStylesheet = async () => {
    try {
      await navigator.clipboard.writeText(activeCss);
      setCopiedCss(true);
      setTimeout(() => setCopiedCss(false), 2000);
    } catch {
      // Fallback copy
    }
  };

  const handleCopyActiveCode = async () => {
    try {
      const content =
        codeDocTarget === 'register'
          ? codeFormat === 'css'
            ? registerCss
            : registerHtml
          : codeFormat === 'css'
          ? cumulativeCss
          : cumulativeHtml;
      await navigator.clipboard.writeText(content);
      setCopiedCodeBlock(true);
      setTimeout(() => setCopiedCodeBlock(false), 2000);
    } catch {
      // Fallback copy
    }
  };

  const handleDownloadFile = (
    type: 'css' | 'html',
    targetDoc: 'register' | 'cumulative' = isLandscapeRegisterActive ? 'register' : 'cumulative'
  ) => {
    const content =
      targetDoc === 'register'
        ? type === 'css'
          ? registerCss
          : registerHtml
        : type === 'css'
        ? cumulativeCss
        : cumulativeHtml;
    const mime = type === 'css' ? 'text/css;charset=utf-8' : 'text/html;charset=utf-8';
    const prefix =
      targetDoc === 'register'
        ? 'class-teacher-assessment-record'
        : `student-cumulative-record-${recordData.nameEnglish
            .toLowerCase()
            .replace(/[^a-z0-9]+/g, '-')}`;
    const filename = `${prefix}.${type}`;
    const blob = new Blob([content], { type: mime });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handlePrintOrPdf = () => {
    if (activeView === 'css-code') {
      setActiveView(codeDocTarget === 'register' ? 'teacher-register' : 'cumulative-all');
      setTimeout(() => window.print(), 140);
    } else if (activeView === 'student-roster') {
      // If on the directory view, switch to the currently selected student's Cumulative Record and print
      setActiveView('cumulative-all');
      setTimeout(() => window.print(), 140);
    } else {
      window.print();
    }
  };

  const handleCloudSignOut = async () => {
    if (!supabase || !session) return;
    try {
      if (isCloudHydrated) {
        await cloudSaveQueue.current;
        await saveSchoolSnapshot(session.user.id, {
          roster,
          recordData,
          recordsByStudent,
          registerData,
          registersByClass,
          schoolLogoDataUrl,
          selectedStudentId,
          styleConfig,
          batchClassLabel,
          batchStudentIds,
          idCardStudentIds,
        });
      }
      const { error } = await supabase.auth.signOut();
      if (error) throw error;
    } catch (error) {
      setCloudMessage(
        `Could not safely sign out: ${error instanceof Error ? error.message : 'Unknown error'}`,
      );
    }
  };

  if (supabase && isAuthChecking) {
    return (
      <main className="flex min-h-screen items-center justify-center bg-[#FBF9F5] text-stone-700">
        Checking secure cloud sign-in…
      </main>
    );
  }

  if (supabase && !session) return <CloudAuthPanel initialError={cloudMessage} />;

  if (requiresCloudAuth && !supabase) {
    return (
      <main className="flex min-h-screen items-center justify-center bg-[#FBF9F5] px-4 text-stone-800">
        <section className="max-w-xl rounded-xl border border-red-200 bg-white p-6 shadow-sm">
          <h1 className="text-lg font-semibold">Secure sign-in is unavailable</h1>
          <p role="alert" className="mt-2 text-sm text-red-800">
            This site is configured to require school-admin sign-in, but its Supabase public
            configuration is missing. No student data is available until the site is configured.
          </p>
        </section>
      </main>
    );
  }

  if (supabase && session && !isCloudHydrated) {
    return (
      <main className="flex min-h-screen items-center justify-center bg-[#FBF9F5] px-4 text-stone-800">
        <section className="max-w-xl rounded-xl border border-stone-200 bg-white p-6 shadow-sm">
          <h1 className="text-lg font-semibold">Cloud data needs attention</h1>
          <p role="alert" className="mt-2 text-sm text-red-800">
            {cloudMessage || 'Waiting for cloud data.'}
          </p>
          <button
            type="button"
            onClick={() => setCloudLoadAttempt((attempt) => attempt + 1)}
            className="mt-4 rounded-lg bg-blue-900 px-4 py-2 text-sm font-semibold text-white"
          >
            Retry loading
          </button>
          <button
            type="button"
            onClick={handleCloudSignOut}
            className="ml-2 rounded-lg border border-stone-300 px-4 py-2 text-sm font-semibold"
          >
            Sign out
          </button>
        </section>
      </main>
    );
  }

  return (
    <div className="min-h-screen bg-[#FBF9F5] text-[#1C1917] flex flex-col">
      {/* Hidden input for quick photo upload in right sidebar */}
      <input
        ref={sidebarPhotoInputRef}
        type="file"
        accept="image/*"
        onChange={handleSidebarPhotoUpload}
        className="hidden"
      />

      {/* Dynamic @page orientation rule so Print / Save as PDF automatically matches Portrait or Landscape */}
      <style>
        {isLandscapeRegisterActive
          ? `@page { size: A4 landscape; margin: 5mm; }`
          : `@page { size: A4 portrait; margin: 8mm; }`}
      </style>

      {/* =====================================================================
          TOP BAR CONTRACT: 1 Row, 3 Zones (Hidden during print)
         ===================================================================== */}
      <header className="no-print sticky top-0 z-30 bg-[#FBF9F5]/95 backdrop-blur border-b border-stone-200 px-5 py-3 flex items-center justify-between gap-4">
        {/* Zone 1: Single text element wordmark */}
        <a
          href="#top"
          onClick={(e) => {
            e.preventDefault();
            setActiveView('student-roster');
          }}
          className="text-base font-bold tracking-tight text-stone-900 whitespace-nowrap shrink-0"
        >
          மாணவர் திரள் பதிவேடு
        </a>

        {/* Zone 2: 5 clean text navigation links */}
        <nav className="hidden md:flex items-center gap-5 text-xs font-medium text-stone-600">
          <button
            type="button"
            onClick={() => setActiveView('student-roster')}
            className={`py-1 transition-colors whitespace-nowrap border-b-2 ${
              activeView === 'student-roster'
                ? 'border-stone-900 text-stone-900 font-semibold'
                : 'border-transparent hover:text-stone-900'
            }`}
          >
            Students &amp; Photos ({roster.length})
          </button>
          <button
            type="button"
            onClick={() => setActiveView('cumulative-all')}
            className={`py-1 transition-colors whitespace-nowrap border-b-2 ${
              activeView === 'cumulative-all'
                ? 'border-stone-900 text-stone-900 font-semibold'
                : 'border-transparent hover:text-stone-900'
            }`}
          >
            Cumulative Record
          </button>
          <button
            type="button"
            onClick={() => setActiveView('teacher-register')}
            className={`py-1 transition-colors whitespace-nowrap border-b-2 ${
              activeView === 'teacher-register'
                ? 'border-stone-900 text-stone-900 font-semibold'
                : 'border-transparent hover:text-stone-900'
            }`}
          >
            Teacher Register
          </button>
          <button
            type="button"
            onClick={() => setActiveView('batch-pdf')}
            className={`py-1 transition-colors whitespace-nowrap border-b-2 ${
              activeView === 'batch-pdf'
                ? 'border-stone-900 text-stone-900 font-semibold'
                : 'border-transparent hover:text-stone-900'
            }`}
          >
            Batch Class PDF
          </button>
          <button
            type="button"
            onClick={() => handleOpenIdCards(roster)}
            className={`py-1 transition-colors whitespace-nowrap border-b-2 ${
              activeView === 'id-cards'
                ? 'border-stone-900 text-stone-900 font-semibold'
                : 'border-transparent hover:text-stone-900'
            }`}
          >
            Student ID Cards
          </button>
          <button
            type="button"
            onClick={() => {
              setCodeDocTarget(isLandscapeRegisterActive ? 'register' : 'cumulative');
              setActiveView('css-code');
            }}
            className={`py-1 transition-colors whitespace-nowrap border-b-2 ${
              activeView === 'css-code'
                ? 'border-stone-900 text-stone-900 font-semibold'
                : 'border-transparent hover:text-stone-900'
            }`}
          >
            HTML &amp; CSS
          </button>
        </nav>

        {/* Zone 3: 2 primary actions (Upload Photo & Print / Save as PDF) */}
        <div className="flex items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={() => sidebarPhotoInputRef.current?.click()}
            className="px-3 py-1.5 text-xs font-semibold text-stone-800 bg-white border border-stone-300 rounded-lg hover:bg-stone-100 transition-colors whitespace-nowrap flex items-center gap-1.5"
          >
            <Camera className="w-3.5 h-3.5 text-[#1E3A8A]" />
            <span>Add / Upload Photo</span>
          </button>
          <button
            type="button"
            onClick={handlePrintOrPdf}
            className="px-3.5 py-1.5 text-xs font-semibold text-white bg-[#1E3A8A] rounded-lg hover:bg-[#172554] transition-colors whitespace-nowrap flex items-center gap-1.5"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Print / Save PDF</span>
          </button>
          {supabase && session && (
            <button
              type="button"
              onClick={handleCloudSignOut}
              className="inline-flex items-center gap-1 rounded-lg border border-stone-300 bg-white px-2.5 py-1.5 text-xs font-semibold text-stone-700 hover:bg-stone-100"
              title={`Signed in as ${session.user.email || 'school administrator'}`}
            >
              <LogOut className="h-3.5 w-3.5" />
              Sign out
            </button>
          )}
        </div>
      </header>
      <div className="no-print mx-auto w-full max-w-[1440px] px-4 pt-3 sm:px-6">
        {cloudConfigurationError ? (
          <p role="status" className="rounded-lg border border-amber-300 bg-amber-50 px-4 py-2 text-xs text-amber-900">
            <strong>Local storage only.</strong> {cloudConfigurationError} Data may be lost if
            browser storage is cleared or reaches its limit, and it will not sync to other devices.
          </p>
        ) : (
          <div
            role="status"
            className={`flex items-center justify-between gap-3 rounded-lg border px-4 py-2 text-xs ${
              cloudMessage?.startsWith('Cloud save failed')
                ? 'border-red-300 bg-red-50 text-red-900'
                : 'border-emerald-200 bg-emerald-50 text-emerald-900'
            }`}
          >
            <span>{cloudMessage || 'Private cloud storage is connected.'}</span>
            {cloudMessage?.startsWith('Cloud save failed') && (
              <button
                type="button"
                onClick={() => setCloudSaveAttempt((attempt) => attempt + 1)}
                className="shrink-0 font-semibold underline"
              >
                Retry save
              </button>
            )}
          </div>
        )}
      </div>

      {/* =====================================================================
          MAIN WORKSPACE: Two-Zone Split Layout (Stage + Control Deck)
         ===================================================================== */}
      <main className={`flex-1 max-w-[1440px] w-full mx-auto px-4 sm:px-6 py-6 grid grid-cols-1 xl:grid-cols-12 gap-7 items-start ${activeView === 'id-cards' ? 'id-card-print-active' : ''}`}>
        {/* LEFT / MAIN STAGE (8 Columns on XL Desktop, Full Width on Print) */}
        <div className="xl:col-span-8 w-full overflow-x-auto">
          {/* Quiet Editorial Kicker Bar (No Pills, Hidden in Print) */}
          <div className="no-print mb-5 flex flex-wrap items-center justify-between gap-4 pb-3 border-b border-stone-200">
            <div>
              <div className="flex items-center gap-2 text-xs text-stone-500">
                <span>
                  {activeView === 'student-roster'
                    ? 'Sample School · Student Directory & Photo Studio Demo'
                    : activeView === 'teacher-register'
                    ? 'Class Teacher Assessment Record · Scholastic & Co-Scholastic Register'
                    : activeView === 'batch-pdf'
                    ? `Batch Multi-Page A4 PDF Generator · ${batchClassLabel}`
                    : activeView === 'id-cards'
                    ? 'Student ID Cards · Bulk A4 Print & WhatsApp Share'
                    : 'Tamil Nadu School Education · Student Cumulative Record'}
                </span>
                <span aria-hidden="true">·</span>
                <span>
                  {isLandscapeRegisterActive
                    ? 'ISO A4 Landscape (297mm × 210mm)'
                    : 'ISO A4 Portrait (210mm × 297mm)'}
                </span>
              </div>
              <h1 className="text-xl font-semibold text-stone-900 mt-1">
                {activeView === 'student-roster'
                  ? 'School Student Directory — Add Student, Upload Photo & Generate PDF'
                  : activeView === 'teacher-register'
                  ? 'Class Teacher Assessment Record & Co-Scholastic Areas'
                  : activeView === 'batch-pdf'
                  ? `Batch Student Cumulative Profiles (${batchStudentsList.length} Students)`
                  : activeView === 'id-cards'
                  ? `Student ID Cards (${idCardStudentsList.length})`
                  : `மாணவர் திரள் பதிவேடு — ${recordData.nameEnglish}`}
              </h1>
            </div>

            {/* Sub-page filter when in Cumulative Record */}
            {activeView === 'cumulative-all' && (
              <div className="flex items-center gap-1 p-1 bg-stone-200/75 rounded-lg">
                {(
                  [
                    { id: 'all', label: 'All 3 Pages' },
                    { id: 'page1', label: 'Page 1 · Profile & Photo' },
                    { id: 'page2', label: 'Page 2 · Marks' },
                    { id: 'page3', label: 'Page 3 · Co-Scholastic' },
                  ] as const
                ).map((tab) => (
                  <button
                    key={tab.id}
                    type="button"
                    onClick={() => setCumulativePageFilter(tab.id)}
                    className={`px-2.5 py-1.5 text-xs font-semibold rounded-md transition-colors whitespace-nowrap ${
                      cumulativePageFilter === tab.id
                        ? 'bg-white text-stone-900 shadow-xs'
                        : 'text-stone-600 hover:text-stone-900'
                    }`}
                  >
                    {tab.label}
                  </button>
                ))}
              </div>
            )}

            {/* Sub-page filter when in Class Teacher Register */}
            {activeView === 'teacher-register' && (
              <div className="flex items-center gap-1 p-1 bg-stone-200/75 rounded-lg">
                <button
                  type="button"
                  onClick={() => setRegisterSubPage('both')}
                  className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors whitespace-nowrap ${
                    registerSubPage === 'both'
                      ? 'bg-white text-stone-900 shadow-xs'
                      : 'text-stone-600 hover:text-stone-900'
                  }`}
                >
                  Both Register Pages
                </button>
                <button
                  type="button"
                  onClick={() => setRegisterSubPage('scholastic')}
                  className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors whitespace-nowrap ${
                    registerSubPage === 'scholastic'
                      ? 'bg-white text-stone-900 shadow-xs'
                      : 'text-stone-600 hover:text-stone-900'
                  }`}
                >
                  Page 1 · Scholastic
                </button>
                <button
                  type="button"
                  onClick={() => setRegisterSubPage('coscholastic')}
                  className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors whitespace-nowrap ${
                    registerSubPage === 'coscholastic'
                      ? 'bg-white text-stone-900 shadow-xs'
                      : 'text-stone-600 hover:text-stone-900'
                  }`}
                >
                  Page 2 · Co-Scholastic
                </button>
              </div>
            )}
          </div>

          {activeView === 'student-roster' ? (
            <StudentRosterManager
              roster={roster}
              onUpdateRoster={handleUpdateRoster}
              onSelectStudentForCumulative={handleSelectStudentForCumulative}
              onLoadClassIntoRegister={handleLoadClassIntoRegister}
              onBatchPrintProfiles={handleBatchPrintProfiles}
              onCreateIdCards={handleOpenIdCards}
              schoolLogoDataUrl={schoolLogoDataUrl}
              onSchoolLogoChange={handleSchoolLogoChange}
              selectedStudentId={selectedStudentId}
              useAutoPortraits={useAutoPortraits}
              onToggleAutoPortraits={setUseAutoPortraits}
            />
          ) : activeView === 'id-cards' ? (
            <StudentIdCardsSheet
              students={idCardStudentsList}
              logoDataUrl={schoolLogoDataUrl}
              useAutoPortraits={useAutoPortraits}
              onBack={() => setActiveView('student-roster')}
            />
          ) : activeView === 'batch-pdf' ? (
            <BatchStudentProfilesSheet
              classLabel={batchClassLabel}
              students={batchStudentsList}
              config={styleConfig}
              useAutoPortraits={useAutoPortraits}
              onSelectSingleStudent={(stu) => handleSelectStudentForCumulative(stu, false)}
              onTriggerPrint={() => window.print()}
            />
          ) : activeView === 'css-code' ? (
            /* Full-Width Stylesheet & HTML Source Inspector */
            <div className="no-print bg-white border border-stone-200 rounded-xl overflow-hidden">
              <div className="px-5 py-3.5 bg-stone-100/80 border-b border-stone-200 flex flex-wrap items-center justify-between gap-3">
                <div className="flex flex-wrap items-center gap-2">
                  {/* Target Document Switcher */}
                  <div className="flex items-center gap-1 p-1 bg-stone-200/75 rounded-lg">
                    <button
                      type="button"
                      onClick={() => setCodeDocTarget('register')}
                      className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors whitespace-nowrap ${
                        codeDocTarget === 'register'
                          ? 'bg-white text-stone-900 shadow-xs'
                          : 'text-stone-600 hover:text-stone-900'
                      }`}
                    >
                      Teacher Register (A4 Landscape)
                    </button>
                    <button
                      type="button"
                      onClick={() => setCodeDocTarget('cumulative')}
                      className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors whitespace-nowrap ${
                        codeDocTarget === 'cumulative'
                          ? 'bg-white text-stone-900 shadow-xs'
                          : 'text-stone-600 hover:text-stone-900'
                      }`}
                    >
                      Cumulative Record (A4 Portrait)
                    </button>
                  </div>

                  {/* Format Switcher */}
                  <div className="flex items-center gap-1 p-1 bg-stone-200/75 rounded-lg">
                    <button
                      type="button"
                      onClick={() => setCodeFormat('html')}
                      className={`px-2.5 py-1.5 text-xs font-semibold rounded-md transition-colors whitespace-nowrap flex items-center gap-1 ${
                        codeFormat === 'html'
                          ? 'bg-white text-stone-900 shadow-xs'
                          : 'text-stone-600 hover:text-stone-900'
                      }`}
                    >
                      <FileText className="w-3.5 h-3.5" />
                      <span>Complete HTML</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setCodeFormat('css')}
                      className={`px-2.5 py-1.5 text-xs font-semibold rounded-md transition-colors whitespace-nowrap flex items-center gap-1 ${
                        codeFormat === 'css'
                          ? 'bg-white text-stone-900 shadow-xs'
                          : 'text-stone-600 hover:text-stone-900'
                      }`}
                    >
                      <FileCode2 className="w-3.5 h-3.5" />
                      <span>CSS Only</span>
                    </button>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={handleCopyActiveCode}
                    className="px-3 py-1.5 text-xs font-semibold text-stone-800 bg-white border border-stone-300 rounded-lg hover:bg-stone-50 transition-colors whitespace-nowrap flex items-center gap-1.5"
                  >
                    {copiedCodeBlock ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-700" />
                        <span>Copied</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" />
                        <span>Copy {codeFormat.toUpperCase()}</span>
                      </>
                    )}
                  </button>
                  <button
                    type="button"
                    onClick={() => handleDownloadFile(codeFormat, codeDocTarget)}
                    className="px-3 py-1.5 text-xs font-semibold text-white bg-stone-900 rounded-lg hover:bg-stone-800 transition-colors whitespace-nowrap flex items-center gap-1.5"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Download .{codeFormat}</span>
                  </button>
                </div>
              </div>

              <div className="p-5 bg-[#0F172A] text-slate-100 overflow-x-auto max-h-[760px]">
                <pre className="text-xs font-mono leading-relaxed select-all">
                  <code>
                    {codeDocTarget === 'register'
                      ? codeFormat === 'css'
                        ? registerCss
                        : registerHtml
                      : codeFormat === 'css'
                      ? cumulativeCss
                      : cumulativeHtml}
                  </code>
                </pre>
              </div>
            </div>
          ) : activeView === 'teacher-register' ? (
            /* Live A4 Landscape Class Teacher Assessment Record */
            <ClassTeacherRegisterSheet
              data={registerData}
              onChange={setRegisterData}
              config={styleConfig}
              isEditable={isEditable}
              visibleRegisterPage={registerSubPage}
            />
          ) : (
            /* Live A4 Portrait Student Cumulative Record */
            <CumulativeRecordSheet
              data={recordData}
              onChange={handleRecordDataChange}
              config={styleConfig}
              isEditable={isEditable}
              visiblePages={cumulativePageFilter}
            />
          )}
        </div>

        {/* RIGHT / CONTROL & PHOTO / PDF EXPORT DECK (4 Columns on XL Desktop, Hidden in Print) */}
        <aside className="no-print xl:col-span-4 space-y-5 xl:sticky xl:top-20">
          {/* Panel 1: Active Student Photo & Quick PDF Card */}
          <section className="bg-white border border-stone-200 rounded-xl p-5 space-y-4">
            <div className="flex items-center justify-between border-b border-stone-100 pb-3">
              <div>
                <h2 className="text-sm font-semibold text-stone-900">
                  01. Active Student Photo &amp; PDF Studio
                </h2>
                <p className="text-xs text-stone-500 mt-0.5">
                  Select student, upload photo, and print/save A4 PDF
                </p>
              </div>
              <button
                type="button"
                onClick={() => setActiveView('student-roster')}
                className="text-xs font-semibold text-[#1E3A8A] hover:underline flex items-center gap-1"
              >
                <Users className="w-3.5 h-3.5" />
                <span>All {roster.length}</span>
              </button>
            </div>

            {/* Quick Student Selector Dropdown */}
            <div>
              <label className="text-[11px] font-semibold text-stone-700 block mb-1">
                Quick Select Student ({roster.length} Students)
              </label>
              <select
                value={selectedStudentId}
                onChange={(e) => {
                  const found = roster.find((s) => s.id === e.target.value);
                  if (found) {
                    handleSelectStudentForCumulative(found, false);
                  }
                }}
                className="w-full px-2.5 py-2 text-xs font-medium bg-stone-50 border border-stone-300 rounded-lg focus:outline-none focus:border-[#1E3A8A]"
              >
                {roster.map((s, idx) => (
                  <option key={s.id} value={s.id}>
                    {s.slNo || idx + 1}. {s.name} — {s.studentClass} (Photo #{s.photoNo || '—'} |
                    Adm: {s.admissionNo || '—'})
                  </option>
                ))}
              </select>
            </div>

            {/* Active Student Photo Preview + Direct Upload Button */}
            {selectedStudent && (
              <div className="p-3 bg-stone-50 border border-stone-200 rounded-xl flex items-center gap-3.5">
                <div
                  onClick={() => sidebarPhotoInputRef.current?.click()}
                  className="w-20 h-24 border-2 border-stone-300 hover:border-[#1E3A8A] rounded-lg bg-white overflow-hidden shrink-0 cursor-pointer flex flex-col items-center justify-center relative group"
                  title="Click to upload or replace student photo"
                >
                  {recordData.photoDataUrl ? (
                    <img
                      src={recordData.photoDataUrl}
                      alt={selectedStudent.name}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="text-center p-1">
                      <Camera className="w-5 h-5 mx-auto text-stone-400" />
                      <span className="text-[10px] text-stone-500 block mt-0.5">Add Photo</span>
                    </div>
                  )}
                </div>

                <div className="flex-1 min-w-0 space-y-1.5">
                  <div>
                    <div className="text-xs font-bold text-stone-900 truncate">
                      {selectedStudent.name}
                    </div>
                    <div className="text-[11px] text-stone-500 font-mono">
                      Class: {selectedStudent.studentClass} · Photo #
                      {selectedStudent.photoNo || '—'} · Adm: {selectedStudent.admissionNo || '—'}
                    </div>
                  </div>

                  <div className="flex flex-wrap gap-1.5">
                    <button
                      type="button"
                      onClick={() => sidebarPhotoInputRef.current?.click()}
                      className="px-2.5 py-1.5 text-xs font-semibold text-white bg-emerald-700 hover:bg-emerald-800 rounded-md transition-colors flex items-center gap-1"
                    >
                      <Upload className="w-3 h-3" />
                      <span>
                        {selectedStudent.photoDataUrl ? 'Change Photo' : 'Upload Photo'}
                      </span>
                    </button>
                    <button
                      type="button"
                      onClick={() => handleSelectStudentForCumulative(selectedStudent, false)}
                      className="px-2.5 py-1.5 text-xs font-semibold text-stone-800 bg-white border border-stone-300 hover:bg-stone-100 rounded-md transition-colors"
                    >
                      View Record
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* Primary Print / Save as PDF Button */}
            <button
              type="button"
              onClick={handlePrintOrPdf}
              className="w-full py-2.5 px-4 text-xs font-semibold text-white bg-[#1E3A8A] hover:bg-[#172554] rounded-lg transition-colors flex items-center justify-center gap-2 whitespace-nowrap"
            >
              <Printer className="w-4 h-4" />
              <span>
                Print / Save as PDF (
                {isLandscapeRegisterActive ? 'A4 Landscape' : 'A4 Portrait'})
              </span>
            </button>

            {/* Download Standalone HTML for Both Documents */}
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => handleDownloadFile('html', 'cumulative')}
                className="px-3 py-2 text-xs font-semibold text-stone-800 bg-stone-100 hover:bg-stone-200 rounded-lg transition-colors whitespace-nowrap flex items-center justify-center gap-1.5"
              >
                <FileDown className="w-3.5 h-3.5" />
                <span>Student Record .HTML</span>
              </button>
              <button
                type="button"
                onClick={() => handleDownloadFile('html', 'register')}
                className="px-3 py-2 text-xs font-semibold text-stone-800 bg-stone-100 hover:bg-stone-200 rounded-lg transition-colors whitespace-nowrap flex items-center justify-center gap-1.5"
              >
                <FileDown className="w-3.5 h-3.5" />
                <span>Teacher Register .HTML</span>
              </button>
            </div>
          </section>

          {/* Panel 2: Register & Student Row Controls */}
          <section className="bg-white border border-stone-200 rounded-xl p-5 space-y-4">
            <div className="border-b border-stone-100 pb-3">
              <h2 className="text-sm font-semibold text-stone-900">
                02. Document View &amp; Smart Calculations
              </h2>
              <p className="text-xs text-stone-500 mt-0.5">
                Switch views, manage student rows, and compute grades
              </p>
            </div>

            {/* Main View Switcher */}
            <div className="grid grid-cols-3 gap-1 p-1 bg-stone-100 rounded-lg">
              <button
                type="button"
                onClick={() => setActiveView('student-roster')}
                className={`px-2 py-1.5 text-xs font-semibold rounded-md transition-colors whitespace-nowrap ${
                  activeView === 'student-roster'
                    ? 'bg-white text-stone-900 shadow-xs'
                    : 'text-stone-600 hover:text-stone-900'
                }`}
              >
                Roster (214)
              </button>
              <button
                type="button"
                onClick={() => setActiveView('cumulative-all')}
                className={`px-2 py-1.5 text-xs font-semibold rounded-md transition-colors whitespace-nowrap ${
                  activeView === 'cumulative-all'
                    ? 'bg-white text-stone-900 shadow-xs'
                    : 'text-stone-600 hover:text-stone-900'
                }`}
              >
                Student Form
              </button>
              <button
                type="button"
                onClick={() => setActiveView('teacher-register')}
                className={`px-2 py-1.5 text-xs font-semibold rounded-md transition-colors whitespace-nowrap ${
                  activeView === 'teacher-register'
                    ? 'bg-white text-stone-900 shadow-xs'
                    : 'text-stone-600 hover:text-stone-900'
                }`}
              >
                Register
              </button>
            </div>

            {/* Sample vs Blank Preset */}
            <div className="grid grid-cols-2 gap-1 p-1 bg-stone-100 rounded-lg">
              <button
                type="button"
                onClick={() => handleLoadPreset('sample')}
                className={`px-3 py-2 text-xs font-semibold rounded-md transition-colors whitespace-nowrap flex items-center justify-center gap-1.5 ${
                  dataMode === 'sample'
                    ? 'bg-white text-stone-900 shadow-xs'
                    : 'text-stone-600 hover:text-stone-900'
                }`}
              >
                <Sparkles className="w-3.5 h-3.5 text-[#1E3A8A]" />
                <span>Load Roster Data</span>
              </button>
              <button
                type="button"
                onClick={() => handleLoadPreset('blank')}
                className={`px-3 py-2 text-xs font-semibold rounded-md transition-colors whitespace-nowrap flex items-center justify-center gap-1.5 ${
                  dataMode === 'blank'
                    ? 'bg-white text-stone-900 shadow-xs'
                    : 'text-stone-600 hover:text-stone-900'
                }`}
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Blank Form</span>
              </button>
            </div>

            {/* Add / Remove Student Rows for Class Teacher Register */}
            {activeView === 'teacher-register' && (
              <div className="space-y-2 pt-1 border-t border-stone-100">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-medium text-stone-700">
                    Students in Register: <strong>{registerData.students.length}</strong>
                  </span>
                  <button
                    type="button"
                    onClick={handleComputeRegisterTotals}
                    className="text-xs font-semibold text-[#1E3A8A] hover:underline flex items-center gap-1 whitespace-nowrap"
                  >
                    <Calculator className="w-3 h-3" />
                    <span>Auto-Calc Total Row</span>
                  </button>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={handleAddStudentToRegister}
                    className="px-3 py-2 text-xs font-semibold text-stone-800 bg-stone-100 hover:bg-stone-200 rounded-lg transition-colors whitespace-nowrap flex items-center justify-center gap-1.5"
                  >
                    <UserPlus className="w-3.5 h-3.5 text-emerald-700" />
                    <span>Add Student Row</span>
                  </button>
                  <button
                    type="button"
                    onClick={handleRemoveLastStudentFromRegister}
                    className="px-3 py-2 text-xs font-semibold text-stone-800 bg-stone-100 hover:bg-stone-200 rounded-lg transition-colors whitespace-nowrap flex items-center justify-center gap-1.5"
                  >
                    <UserMinus className="w-3.5 h-3.5 text-rose-700" />
                    <span>Remove Last Row</span>
                  </button>
                </div>
              </div>
            )}

            {/* Quick Co-Scholastic Grade Fill */}
            <div className="space-y-1.5 pt-1 border-t border-stone-100">
              <label className="text-xs font-medium text-stone-700 block">
                Quick Co-Scholastic Grade Fill
              </label>
              <div className="grid grid-cols-3 gap-1.5">
                {(['A', 'B+', 'B'] as const).map((grade) => (
                  <button
                    key={grade}
                    type="button"
                    onClick={() => handleApplyCoScholasticGrade(grade)}
                    className="px-2.5 py-1.5 text-xs font-medium text-stone-800 bg-stone-100 hover:bg-stone-200 rounded-lg transition-colors whitespace-nowrap flex items-center justify-center gap-1"
                  >
                    <Award className="w-3 h-3 text-[#1E3A8A]" />
                    <span>Fill {grade}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Edit vs Preview Mode */}
            <div className="pt-2 border-t border-stone-100 flex items-center justify-between gap-2">
              {!isLandscapeRegisterActive ? (
                <button
                  type="button"
                  onClick={handleRecalculateAttendance}
                  className="px-3 py-1.5 text-xs font-medium text-stone-800 bg-stone-100 hover:bg-stone-200 rounded-lg transition-colors whitespace-nowrap flex items-center gap-1.5"
                >
                  <Calculator className="w-3.5 h-3.5 text-stone-700" />
                  <span>Calc Attendance %</span>
                </button>
              ) : (
                <span className="text-xs text-stone-500">
                  Click photo or type FA/SA marks
                </span>
              )}

              <div className="flex items-center gap-1 p-1 bg-stone-100 rounded-lg shrink-0">
                <button
                  type="button"
                  onClick={() => setIsEditable(true)}
                  className={`px-2.5 py-1 text-xs font-medium rounded transition-colors whitespace-nowrap flex items-center gap-1 ${
                    isEditable ? 'bg-white text-stone-900 shadow-xs' : 'text-stone-600'
                  }`}
                >
                  <Edit3 className="w-3 h-3" />
                  <span>Edit</span>
                </button>
                <button
                  type="button"
                  onClick={() => setIsEditable(false)}
                  className={`px-2.5 py-1 text-xs font-medium rounded transition-colors whitespace-nowrap flex items-center gap-1 ${
                    !isEditable ? 'bg-white text-stone-900 shadow-xs' : 'text-stone-600'
                  }`}
                >
                  <Eye className="w-3 h-3" />
                  <span>Preview</span>
                </button>
              </div>
            </div>
          </section>

          {/* Panel 3: Stylesheet Theme & Code Inspector */}
          <section className="bg-white border border-stone-200 rounded-xl p-5 space-y-4">
            <div className="flex items-center justify-between border-b border-stone-100 pb-3">
              <div>
                <h2 className="text-sm font-semibold text-stone-900">
                  03. CSS Stylesheet &amp; Theme
                </h2>
                <p className="text-xs text-stone-500 mt-0.5">
                  Copy or download the print stylesheet
                </p>
              </div>
              <button
                type="button"
                onClick={handleCopyStylesheet}
                className="px-2.5 py-1 text-xs font-semibold text-[#1E3A8A] bg-[#1E3A8A]/5 hover:bg-[#1E3A8A]/10 rounded-md transition-colors whitespace-nowrap flex items-center gap-1"
              >
                {copiedCss ? (
                  <>
                    <Check className="w-3 h-3 text-emerald-700" />
                    <span>Copied</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3 h-3" />
                    <span>Copy CSS</span>
                  </>
                )}
              </button>
            </div>

            {/* Print Palette */}
            <div className="grid grid-cols-3 gap-1.5">
              {[
                { id: 'archival-mono', label: 'Ink Black' },
                { id: 'tn-education-navy', label: 'Official Navy' },
                { id: 'warm-parchment', label: 'Archival Warm' },
              ].map((item) => (
                <button
                  key={item.id}
                  type="button"
                  onClick={() =>
                    setStyleConfig((prev) => ({
                      ...prev,
                      themeId: item.id as StyleConfig['themeId'],
                    }))
                  }
                  className={`px-2.5 py-2 text-xs font-medium rounded-lg border transition-colors whitespace-nowrap ${
                    styleConfig.themeId === item.id
                      ? 'border-[#1E3A8A] bg-[#1E3A8A]/5 text-[#1E3A8A] font-semibold'
                      : 'border-stone-200 text-stone-700 hover:bg-stone-50'
                  }`}
                >
                  {item.label}
                </button>
              ))}
            </div>

            <div className="bg-[#0F172A] text-slate-200 rounded-lg p-3 max-h-40 overflow-y-auto border border-slate-800">
              <pre className="text-[11px] font-mono leading-relaxed">
                <code>{activeCss}</code>
              </pre>
            </div>
          </section>
        </aside>
      </main>
    </div>
  );
}
