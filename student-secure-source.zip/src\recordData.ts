import { RosterStudent } from './schoolStudentsRoster';

export function rosterStudentToCumulativeRecord(
  stu: RosterStudent,
  serialOverride?: string
): StudentRecordData {
  const genderDisplay =
    stu.gender.toLowerCase() === 'female'
      ? 'பெண் (Female)'
      : stu.gender.toLowerCase() === 'male'
      ? 'ஆண் (Male)'
      : stu.gender;

  const fullAddress = [stu.address, stu.pincode].filter(Boolean).join(' - ');

  return {
    ...JSON.parse(JSON.stringify(SAMPLE_RECORD_DATA)),
    serialNo: serialOverride || stu.slNo || '1',
    classAndSection: `${stu.studentClass} Std`,
    examNo: stu.photoNo ? `2026-${stu.photoNo}` : '',
    yearSuffix: '25 - 2026',
    photoNo: stu.photoNo,
    photoDataUrl: stu.photoDataUrl || null,
    nameTamil: stu.name,
    nameEnglish: stu.name,
    gender: genderDisplay,
    admissionNo: stu.admissionNo,
    religion: '',
    admissionDateAndClass: stu.studentClass,
    caste: '',
    subCaste: '',
    dob: stu.dob,
    fatherName: stu.fatherName,
    motherName: stu.motherName,
    guardianName: '—',
    occupation: '',
    annualIncome: '',
    address: fullAddress,
    phone: stu.phone,
    aadhaarDigits: Array(12).fill(''),
    emisNo: '',
    savingsNo: '',
    bloodGroup: stu.bloodGroup,
    healthStatus: 'நன்று (Good)',
    heightCm: '',
    weightKg: '',
    isDifferentlyAbled: 'இல்லை',
    disabilityNature: '—',
    finalResult: `தேர்ச்சி (${stu.studentClass} வகுப்பு)`,
  };
}

export interface TermScore {
  fa: string;
  sa: string;
  total: string;
}

export interface AcademicSubjectRow {
  subject: string;
  term1: TermScore;
  term2: TermScore;
  term3: TermScore;
  isStarred?: boolean;
}

export interface CoCurricularRow {
  activity: string;
  term1: string;
  term2: string;
  term3: string;
}

export interface DetailedCoScholasticItem {
  domainCode: string;
  domainTitleTamil: string;
  domainTitleEnglish: string;
  subSkillTamil: string;
  subSkillEnglish: string;
  descriptiveIndicator: string;
  term1: string;
  term2: string;
  term3: string;
  overall: string;
}

export interface ClassTeacherEvaluationRow {
  parameterTamil: string;
  parameterEnglish: string;
  term1: string;
  term2: string;
  term3: string;
  remarks: string;
}

export interface ClassTeacherTermObservation {
  termLabel: string;
  strengths: string;
  improvementAreas: string;
  teacherActionPlan: string;
  parentFeedback: string;
}

export interface FinalGradeRow {
  subject: string;
  grade: string;
}

export interface StudentRecordData {
  // Top Meta
  serialNo: string;
  classAndSection: string;
  examNo: string;
  yearSuffix: string;
  photoNo?: string;
  photoDataUrl: string | null;

  // Name
  nameTamil: string;
  nameEnglish: string;

  // Bio & Family
  gender: string;
  admissionNo: string;
  religion: string;
  admissionDateAndClass: string;
  caste: string;
  subCaste: string;
  dob: string;
  fatherName: string;
  motherName: string;
  guardianName: string;
  occupation: string;
  annualIncome: string;
  address: string;
  phone: string;
  aadhaarDigits: string[]; // 12 digits
  emisNo: string;
  savingsNo: string;
  bloodGroup: string;
  healthStatus: string;
  heightCm: string;
  weightKg: string;
  isDifferentlyAbled: string;
  disabilityNature: string;

  // Page 2 - Part 1
  academicRows: AcademicSubjectRow[];

  // Page 2 - Part 2 Summary
  coCurricularRows: CoCurricularRow[];
  specialTalent: string;

  // Page 2 - Final Grades
  finalAcademicGrades: FinalGradeRow[];
  finalCoCurricularGrades: FinalGradeRow[];

  // Attendance
  workingDays: [string, string, string];
  presentDays: [string, string, string];
  attendancePercent: [string, string, string];

  // Final Result
  finalResult: string;

  // Page 3 - Detailed Co-Scholastic Areas Record (இணைக் கல்விசார் பகுதிகள் பதிவேடு)
  detailedCoScholastic: DetailedCoScholasticItem[];

  // Page 3 - Class Teacher Assessment Record (வகுப்பாசிரியர் மதிப்பீட்டுப் பதிவேடு)
  classTeacherEvaluations: ClassTeacherEvaluationRow[];
  classTeacherObservations: ClassTeacherTermObservation[];
  classTeacherOverallRecommendation: string;
}

export interface StyleConfig {
  themeId: 'archival-mono' | 'tn-education-navy' | 'warm-parchment';
  fontFamily: 'sans' | 'serif';
  cellDensity: 'compact' | 'standard' | 'spacious';
  outerBorderPx: 1.5 | 2 | 3;
  shadeLabelCells: boolean;
}

export const BLANK_RECORD_DATA: StudentRecordData = {
  serialNo: '',
  classAndSection: '',
  examNo: '',
  yearSuffix: '',
  photoDataUrl: null,
  nameTamil: '',
  nameEnglish: '',
  gender: '',
  admissionNo: '',
  religion: '',
  admissionDateAndClass: '',
  caste: '',
  subCaste: '',
  dob: '',
  fatherName: '',
  motherName: '',
  guardianName: '',
  occupation: '',
  annualIncome: '',
  address: '',
  phone: '',
  aadhaarDigits: Array(12).fill(''),
  emisNo: '',
  savingsNo: '',
  bloodGroup: '',
  healthStatus: '',
  heightCm: '',
  weightKg: '',
  isDifferentlyAbled: '',
  disabilityNature: '',
  academicRows: [
    { subject: 'தமிழ்', term1: { fa: '', sa: '', total: '' }, term2: { fa: '', sa: '', total: '' }, term3: { fa: '', sa: '', total: '' } },
    { subject: 'ஆங்கிலம்', term1: { fa: '', sa: '', total: '' }, term2: { fa: '', sa: '', total: '' }, term3: { fa: '', sa: '', total: '' } },
    { subject: 'கணக்கு', term1: { fa: '', sa: '', total: '' }, term2: { fa: '', sa: '', total: '' }, term3: { fa: '', sa: '', total: '' } },
    { subject: 'அறிவியல் / சூழ்நிலையியல்', term1: { fa: '', sa: '', total: '' }, term2: { fa: '', sa: '', total: '' }, term3: { fa: '', sa: '', total: '' } },
    { subject: 'சமூக அறிவியல்', term1: { fa: '', sa: '', total: '' }, term2: { fa: '', sa: '', total: '' }, term3: { fa: '', sa: '', total: '' } },
    { subject: 'உடற்கல்வி', term1: { fa: '★★', sa: '★★', total: '' }, term2: { fa: '★★', sa: '★★', total: '' }, term3: { fa: '★★', sa: '★★', total: '' }, isStarred: true },
  ],
  coCurricularRows: [
    { activity: 'வாழ்க்கைத் திறன்கள் (Life Skills)', term1: '', term2: '', term3: '' },
    { activity: 'மனப்பான்மைகளும் மதிப்புகளும் (Attitudes & Values)', term1: '', term2: '', term3: '' },
    { activity: 'நன்னலம், யோகா, முழு உடற்பயிற்சி (Health & Yoga)', term1: '', term2: '', term3: '' },
    { activity: 'பாட இணைச்செயல்பாடுகள் (Co-Curricular Activities)', term1: '', term2: '', term3: '' },
  ],
  specialTalent: '',
  finalAcademicGrades: [
    { subject: 'தமிழ்', grade: '' },
    { subject: 'ஆங்கிலம்', grade: '' },
    { subject: 'கணக்கு', grade: '' },
    { subject: 'அறிவியல் / சூழ்நிலையியல்', grade: '' },
    { subject: 'சமூக அறிவியல்', grade: '' },
    { subject: 'உடற்கல்வி', grade: '' },
  ],
  finalCoCurricularGrades: [
    { subject: 'வாழ்க்கைத் திறன்கள்', grade: '' },
    { subject: 'மனப்பான்மைகளும் மதிப்புகளும்', grade: '' },
    { subject: 'நன்னலம், யோகா, முழு உடற்பயிற்சி', grade: '' },
    { subject: 'பாட இணைச்செயல்பாடுகள்', grade: '' },
    { subject: 'வாழ்க்கைக் கல்வி', grade: '' },
  ],
  workingDays: ['', '', ''],
  presentDays: ['', '', ''],
  attendancePercent: ['', '', ''],
  finalResult: '',
  detailedCoScholastic: [
    {
      domainCode: '2A',
      domainTitleTamil: 'வாழ்க்கைத் திறன்கள்',
      domainTitleEnglish: 'Life Skills',
      subSkillTamil: 'சிந்திக்கும் திறன் & சிக்கல் தீர்த்தல்',
      subSkillEnglish: 'Critical Thinking & Problem Solving',
      descriptiveIndicator: '',
      term1: '',
      term2: '',
      term3: '',
      overall: '',
    },
    {
      domainCode: '2A',
      domainTitleTamil: 'வாழ்க்கைத் திறன்கள்',
      domainTitleEnglish: 'Life Skills',
      subSkillTamil: 'சமூகத் திறன் & குழு ஒத்துழைப்பு',
      subSkillEnglish: 'Social Skills & Teamwork',
      descriptiveIndicator: '',
      term1: '',
      term2: '',
      term3: '',
      overall: '',
    },
    {
      domainCode: '2A',
      domainTitleTamil: 'வாழ்க்கைத் திறன்கள்',
      domainTitleEnglish: 'Life Skills',
      subSkillTamil: 'மனவெழுச்சித் திறன் & தன்னம்பிக்கை',
      subSkillEnglish: 'Emotional Balance & Self-Confidence',
      descriptiveIndicator: '',
      term1: '',
      term2: '',
      term3: '',
      overall: '',
    },
    {
      domainCode: '2B',
      domainTitleTamil: 'மனப்பான்மைகளும் மதிப்புகளும்',
      domainTitleEnglish: 'Attitudes & Values',
      subSkillTamil: 'ஆசிரியர்கள் மற்றும் பெரியோர்கள் மீது மரியாதை',
      subSkillEnglish: 'Respect Towards Teachers & Elders',
      descriptiveIndicator: '',
      term1: '',
      term2: '',
      term3: '',
      overall: '',
    },
    {
      domainCode: '2B',
      domainTitleTamil: 'மனப்பான்மைகளும் மதிப்புகளும்',
      domainTitleEnglish: 'Attitudes & Values',
      subSkillTamil: 'சக மாணவர்களுடன் நட்புறவு',
      subSkillEnglish: 'Harmony with Schoolmates',
      descriptiveIndicator: '',
      term1: '',
      term2: '',
      term3: '',
      overall: '',
    },
    {
      domainCode: '2B',
      domainTitleTamil: 'மனப்பான்மைகளும் மதிப்புகளும்',
      domainTitleEnglish: 'Attitudes & Values',
      subSkillTamil: 'பள்ளிச் சொத்து மற்றும் சுற்றுச்சூழல் பாதுகாப்பு',
      subSkillEnglish: 'Care for School Property & Environment',
      descriptiveIndicator: '',
      term1: '',
      term2: '',
      term3: '',
      overall: '',
    },
    {
      domainCode: '2C',
      domainTitleTamil: 'பாட இணைச் செயல்பாடுகள்',
      domainTitleEnglish: 'Co-Curricular Activities',
      subSkillTamil: 'இலக்கியம், வாசிப்பு மற்றும் பேச்சுத் திறன்',
      subSkillEnglish: 'Literary, Reading & Oratory Skills',
      descriptiveIndicator: '',
      term1: '',
      term2: '',
      term3: '',
      overall: '',
    },
    {
      domainCode: '2C',
      domainTitleTamil: 'பாட இணைச் செயல்பாடுகள்',
      domainTitleEnglish: 'Co-Curricular Activities',
      subSkillTamil: 'அறிவியல் / கணிதம் / சுற்றுச்சூழல் மன்றம்',
      subSkillEnglish: 'Science, Mathematics & Eco Club',
      descriptiveIndicator: '',
      term1: '',
      term2: '',
      term3: '',
      overall: '',
    },
    {
      domainCode: '2C',
      domainTitleTamil: 'பாட இணைச் செயல்பாடுகள்',
      domainTitleEnglish: 'Co-Curricular Activities',
      subSkillTamil: 'நுண்கலைகள், இசை மற்றும் கைவினைத் திறன்',
      subSkillEnglish: 'Fine Arts, Performing Arts & Craft',
      descriptiveIndicator: '',
      term1: '',
      term2: '',
      term3: '',
      overall: '',
    },
    {
      domainCode: '2D',
      domainTitleTamil: 'நன்னலம், யோகா & உடற்கல்வி',
      domainTitleEnglish: 'Health, Yoga & Physical Ed.',
      subSkillTamil: 'விளையாட்டு, தடகளம் மற்றும் யோகா',
      subSkillEnglish: 'Sports, Athletics & Yoga Practice',
      descriptiveIndicator: '',
      term1: '',
      term2: '',
      term3: '',
      overall: '',
    },
    {
      domainCode: '2D',
      domainTitleTamil: 'நன்னலம், யோகா & உடற்கல்வி',
      domainTitleEnglish: 'Health, Yoga & Physical Ed.',
      subSkillTamil: 'சாரணர் / இளஞ்செஞ்சிலுவை / பசுமைப்படை',
      subSkillEnglish: 'Scouts & Guides / JRC / NGC Service',
      descriptiveIndicator: '',
      term1: '',
      term2: '',
      term3: '',
      overall: '',
    },
  ],
  classTeacherEvaluations: [
    {
      parameterTamil: 'வகுப்பறை பங்கேற்பு மற்றும் கற்றல் ஆர்வம்',
      parameterEnglish: 'Classroom Participation & Learning Curiosity',
      term1: '',
      term2: '',
      term3: '',
      remarks: '',
    },
    {
      parameterTamil: 'ஒழுக்கம், நன்னடத்தை மற்றும் நேரந்தவறாமை',
      parameterEnglish: 'Discipline, Conduct & Punctuality',
      term1: '',
      term2: '',
      term3: '',
      remarks: '',
    },
    {
      parameterTamil: 'வீட்டுப்பாடம் மற்றும் படைப்புத் திட்டங்கள் முடித்தல்',
      parameterEnglish: 'Homework & Project Work Completion',
      term1: '',
      term2: '',
      term3: '',
      remarks: '',
    },
    {
      parameterTamil: 'தனிநபர் தூய்மை மற்றும் சுகாதாரப் பழக்கவழக்கம்',
      parameterEnglish: 'Personal Hygiene & Health Habits',
      term1: '',
      term2: '',
      term3: '',
      remarks: '',
    },
    {
      parameterTamil: 'தலைமைப் பண்பு மற்றும் பொறுப்புணர்வு',
      parameterEnglish: 'Leadership Qualities & Sense of Responsibility',
      term1: '',
      term2: '',
      term3: '',
      remarks: '',
    },
  ],
  classTeacherObservations: [
    {
      termLabel: 'பருவம் - 1 (Term I)',
      strengths: '',
      improvementAreas: '',
      teacherActionPlan: '',
      parentFeedback: '',
    },
    {
      termLabel: 'பருவம் - 2 (Term II)',
      strengths: '',
      improvementAreas: '',
      teacherActionPlan: '',
      parentFeedback: '',
    },
    {
      termLabel: 'பருவம் - 3 (Term III)',
      strengths: '',
      improvementAreas: '',
      teacherActionPlan: '',
      parentFeedback: '',
    },
  ],
  classTeacherOverallRecommendation: '',
};

export const SAMPLE_RECORD_DATA: StudentRecordData = {
  ...BLANK_RECORD_DATA,
  nameTamil: 'மாதிரி மாணவர்',
  nameEnglish: 'SAMPLE STUDENT',
  admissionNo: 'DEMO-001',
};

export function generateCleanStylesheet(config: StyleConfig): string {
  const palette =
    config.themeId === 'tn-education-navy'
      ? {
          border: '#1e3a8a',
          innerBorder: '#1e40af',
          tableBorder: '#334155',
          headerBg: '#eff6ff',
          subBg: '#f8fafc',
          text: '#0f172a',
          pageBg: '#ffffff',
        }
      : config.themeId === 'warm-parchment'
      ? {
          border: '#292524',
          innerBorder: '#44403c',
          tableBorder: '#57534e',
          headerBg: '#f5f2eb',
          subBg: '#faf8f5',
          text: '#1c1917',
          pageBg: '#fffdf9',
        }
      : {
          border: '#000000',
          innerBorder: '#111827',
          tableBorder: '#1f2937',
          headerBg: '#f3f4f6',
          subBg: '#f9fafb',
          text: '#000000',
          pageBg: '#ffffff',
        };

  const fontStack =
    config.fontFamily === 'serif'
      ? "'Noto Serif Tamil', 'Latha', 'FreeSerif', 'Arial Unicode MS', serif"
      : "'Noto Sans Tamil', 'Latha', 'Arial Unicode MS', 'FreeSerif', sans-serif";

  const cellPadding =
    config.cellDensity === 'compact'
      ? '3px 5px'
      : config.cellDensity === 'spacious'
      ? '5.5px 8px'
      : '4.5px 6px';

  return `/* ==========================================================================
   மாணவர் திரள் பதிவேடு — Student Cumulative Record (Pages 1–3)
   Includes:
   - Page 1: மாணவர் குறிப்பு (Student Profile)
   - Page 2: மாணவர் திரள் பதிவேடு (Scholastic & Attendance Record)
   - Page 3: இணைக் கல்விசார் பகுதிகள் & வகுப்பாசிரியர் மதிப்பீட்டுப் பதிவேடு
             (Detailed Co-Scholastic Areas & Class Teacher Assessment Record)
   Print-Ready A4 Portrait Stylesheet (ISO 216: 210mm × 297mm)
   ========================================================================== */

@import url('https://fonts.googleapis.com/css2?family=Noto+Sans+Tamil:wght@400;500;600;700&family=Noto+Serif+Tamil:wght@400;600;700&display=swap');

@page {
    size: A4 portrait;
    margin: 8mm;
}

:root {
    --doc-font: ${fontStack};
    --border-primary: ${palette.border};
    --border-inner: ${palette.innerBorder};
    --border-table: ${palette.tableBorder};
    --bg-header: ${palette.headerBg};
    --bg-subtle: ${palette.subBg};
    --text-primary: ${palette.text};
    --bg-page: ${palette.pageBg};
    --cell-padding: ${cellPadding};
}

* {
    box-sizing: border-box;
    -webkit-print-color-adjust: exact;
    print-color-adjust: exact;
}

body {
    font-family: var(--doc-font);
    font-size: 9.5pt;
    line-height: 1.32;
    color: var(--text-primary);
    background-color: #f1f5f9;
    margin: 0;
    padding: 20px 0;
    font-variant-numeric: tabular-nums;
}

/* A4 Page Container */
.page {
    width: 210mm;
    min-height: 297mm;
    margin: 0 auto 24px auto;
    padding: 8mm;
    background-color: var(--bg-page);
    border: ${config.outerBorderPx}px solid var(--border-primary);
    box-shadow: 0 4px 16px rgba(0, 0, 0, 0.08);
    page-break-after: always;
    break-after: page;
    display: flex;
    flex-direction: column;
}

.page:last-of-type {
    page-break-after: auto;
    break-after: auto;
}

.inner-border {
    border: 1px solid var(--border-inner);
    padding: 10px 12px;
    flex: 1;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
}

/* Clearfix & Layout Utilities */
.clearfix::after {
    content: "";
    clear: both;
    display: table;
}

/* Section Headers */
.header-box {
    border: 1.5px solid var(--border-primary);
    background-color: var(--bg-header);
    padding: 5px 10px;
    text-align: center;
    font-size: 13pt;
    font-weight: 700;
    margin-bottom: 7px;
    border-radius: 2px;
    letter-spacing: 0.01em;
}

.header-box.sub-section {
    font-size: 10.5pt;
    border-width: 1px;
    background-color: var(--bg-subtle);
    padding: 4px 8px;
    margin: 6px 0;
}

/* Data Tables */
table {
    width: 100%;
    border-collapse: collapse;
    margin-bottom: 6px;
    table-layout: fixed;
}

th,
td {
    border: 1px solid var(--border-table);
    padding: var(--cell-padding);
    text-align: left;
    vertical-align: middle;
    font-size: 9pt;
    word-wrap: break-word;
}

th {
    background-color: var(--bg-header);
    font-weight: 700;
}

${
  config.shadeLabelCells
    ? `/* Subtle shading for field label column */
td:first-child {
    background-color: var(--bg-subtle);
    font-weight: 500;
}`
    : ''
}

.center {
    text-align: center;
}

.bold {
    font-weight: 700;
}

.sub-en {
    display: block;
    font-size: 7.5pt;
    color: #475569;
    font-weight: 400;
}

/* Top Metadata & Student Photograph Box */
.top-meta-table {
    width: 60%;
    float: left;
    margin-bottom: 0;
}

.photo-box {
    width: 105px;
    height: 116px;
    border: 1px solid var(--border-primary);
    background-color: var(--bg-subtle);
    text-align: center;
    float: right;
    font-size: 8.5pt;
    display: flex;
    align-items: center;
    justify-content: center;
}

/* Aadhaar 12-Digit Boxes */
.digit-box {
    display: inline-block;
    width: 19px;
    height: 21px;
    border: 1px solid var(--border-primary);
    background-color: #ffffff;
    text-align: center;
    line-height: 21px;
    margin-right: 3px;
    font-weight: 600;
    vertical-align: middle;
}

.digit-box:nth-child(4),
.digit-box:nth-child(8) {
    margin-right: 9px;
}

/* Grading Scale Legend Strip */
.grade-scale-strip {
    border: 1px solid var(--border-table);
    background-color: var(--bg-subtle);
    padding: 4px 8px;
    font-size: 8pt;
    margin-bottom: 6px;
    display: flex;
    justify-content: space-between;
    flex-wrap: wrap;
    gap: 6px;
}

/* Official Signatures Block */
.signature-table {
    margin-top: 12px;
    margin-bottom: 0;
}

.signature-table td {
    border: none;
    background: transparent !important;
    padding-top: 24px;
    font-weight: 600;
}

/* Print Media Adjustments */
@media print {
    body {
        background: #ffffff;
        padding: 0;
        margin: 0;
    }

    .page {
        width: 100%;
        min-height: 281mm;
        max-height: 281mm;
        margin: 0;
        padding: 4px;
        box-shadow: none;
    }
}`;
}

export function generateFullHtmlDocument(data: StudentRecordData, config: StyleConfig): string {
  const css = generateCleanStylesheet(config);
  const aadhaarSpans = data.aadhaarDigits
    .map((d) => `<span class="digit-box">${d || ''}</span>`)
    .join('');

  const academicRowsHtml = data.academicRows
    .map(
      (r) =>
        `                    <tr><td>${r.subject}</td><td class="center">${r.term1.fa}</td><td class="center">${r.term1.sa}</td><td class="center bold">${r.term1.total}</td><td class="center">${r.term2.fa}</td><td class="center">${r.term2.sa}</td><td class="center bold">${r.term2.total}</td><td class="center">${r.term3.fa}</td><td class="center">${r.term3.sa}</td><td class="center bold">${r.term3.total}</td></tr>`
    )
    .join('\n');

  const coCurricularHtml = data.coCurricularRows
    .map(
      (r) =>
        `                    <tr><td>${r.activity}</td><td class="center">${r.term1}</td><td class="center">${r.term2}</td><td class="center">${r.term3}</td></tr>`
    )
    .join('\n');

  const finalAcadHtml = data.finalAcademicGrades
    .map((r) => `                        <tr><td>${r.subject}</td><td class="center bold">${r.grade}</td></tr>`)
    .join('\n');

  const finalCoCurrHtml = data.finalCoCurricularGrades
    .map((r) => `                        <tr><td>${r.subject}</td><td class="center bold">${r.grade}</td></tr>`)
    .join('\n');

  const detailedCoScholasticHtml = data.detailedCoScholastic
    .map(
      (item) =>
        `                    <tr>
                        <td class="center bold">${item.domainCode}</td>
                        <td>${item.subSkillTamil}<span class="sub-en">${item.subSkillEnglish}</span></td>
                        <td>${item.descriptiveIndicator}</td>
                        <td class="center">${item.term1}</td>
                        <td class="center">${item.term2}</td>
                        <td class="center">${item.term3}</td>
                        <td class="center bold">${item.overall}</td>
                    </tr>`
    )
    .join('\n');

  const teacherEvalHtml = data.classTeacherEvaluations
    .map(
      (item) =>
        `                    <tr>
                        <td>${item.parameterTamil}<span class="sub-en">${item.parameterEnglish}</span></td>
                        <td class="center bold">${item.term1}</td>
                        <td class="center bold">${item.term2}</td>
                        <td class="center bold">${item.term3}</td>
                        <td>${item.remarks}</td>
                    </tr>`
    )
    .join('\n');

  const teacherObsHtml = data.classTeacherObservations
    .map(
      (obs) =>
        `                    <tr>
                        <td class="bold">${obs.termLabel}</td>
                        <td>${obs.strengths}</td>
                        <td>${obs.improvementAreas}</td>
                        <td>${obs.teacherActionPlan}</td>
                        <td>${obs.parentFeedback}</td>
                    </tr>`
    )
    .join('\n');

  return `<!DOCTYPE html>
<html lang="ta">
<head>
    <meta charset="UTF-8">
    <title>மாணவர் திரள் பதிவேடு - Student Cumulative Record</title>
    <style>
${css}
    </style>
</head>
<body>

    <!-- PAGE 1: STUDENT PROFILE (மாணவர் குறிப்பு) -->
    <div class="page">
        <div class="inner-border">
            <div>
                <div class="clearfix" style="margin-bottom: 8px;">
                    <table class="top-meta-table">
                        <tr>
                            <td style="width: 50%;">வரிசை எண்</td>
                            <td>${data.serialNo}</td>
                        </tr>
                        <tr>
                            <td>வகுப்பும் பிரிவும்</td>
                            <td>${data.classAndSection}</td>
                        </tr>
                        <tr>
                            <td>தேர்வு எண்</td>
                            <td>${data.examNo}</td>
                        </tr>
                        <tr>
                            <td>ஆண்டு</td>
                            <td>20${data.yearSuffix}</td>
                        </tr>
                    </table>
                    <div class="photo-box">
                        புகைப்படம்
                    </div>
                </div>

                <div class="header-box">
                    மாணவர் குறிப்பு
                </div>

                <table>
                    <tr>
                        <td rowspan="2" style="width: 25%;" class="bold">மாணவர் பெயர்</td>
                        <td class="center bold" style="width: 37.5%;">தமிழில்</td>
                        <td class="center bold" style="width: 37.5%;">ஆங்கிலத்தில்</td>
                    </tr>
                    <tr>
                        <td class="center" style="height: 24px;">${data.nameTamil}</td>
                        <td class="center">${data.nameEnglish}</td>
                    </tr>
                </table>

                <table>
                    <tr>
                        <td style="width: 25%;">பாலினம்</td>
                        <td style="width: 25%;">${data.gender}</td>
                        <td style="width: 25%;">சேர்க்கை எண்</td>
                        <td style="width: 25%;">${data.admissionNo}</td>
                    </tr>
                    <tr>
                        <td>மதம்</td>
                        <td>${data.religion}</td>
                        <td>சேர்ந்த தேதியும் வகுப்பும்</td>
                        <td>${data.admissionDateAndClass}</td>
                    </tr>
                    <tr>
                        <td>சாதி</td>
                        <td>${data.caste}</td>
                        <td>உட்பிரிவு</td>
                        <td>${data.subCaste}</td>
                    </tr>
                    <tr>
                        <td>பிறந்த தேதி</td>
                        <td colspan="3">${data.dob}</td>
                    </tr>
                    <tr>
                        <td>தந்தையின் பெயர்</td>
                        <td colspan="3">${data.fatherName}</td>
                    </tr>
                    <tr>
                        <td>தாயின் பெயர்</td>
                        <td colspan="3">${data.motherName}</td>
                    </tr>
                    <tr>
                        <td>பாதுகாவலர் பெயர்</td>
                        <td colspan="3">${data.guardianName}</td>
                    </tr>
                    <tr>
                        <td>தொழில்</td>
                        <td>${data.occupation}</td>
                        <td>ஆண்டு வருமானம்</td>
                        <td>${data.annualIncome}</td>
                    </tr>
                    <tr>
                        <td>முகவரி</td>
                        <td colspan="3" style="height: 36px;">${data.address}</td>
                    </tr>
                    <tr>
                        <td>தொலைபேசி எண்</td>
                        <td colspan="3">${data.phone}</td>
                    </tr>
                    <tr>
                        <td>ஆதார் எண்</td>
                        <td colspan="3">
                            ${aadhaarSpans}
                        </td>
                    </tr>
                    <tr>
                        <td>EMIS எண்</td>
                        <td colspan="3">${data.emisNo}</td>
                    </tr>
                    <tr>
                        <td>சேமிப்பு எண்</td>
                        <td colspan="3">${data.savingsNo}</td>
                    </tr>
                    <tr>
                        <td>குருதி வகை</td>
                        <td colspan="3">${data.bloodGroup}</td>
                    </tr>
                    <tr>
                        <td>உடல் நல நிலை</td>
                        <td>${data.healthStatus}</td>
                        <td colspan="2">
                            உயரம்: ${data.heightCm || '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'} &nbsp;&nbsp;&nbsp;&nbsp; எடை: ${data.weightKg || ''}
                        </td>
                    </tr>
                    <tr>
                        <td>மாற்றுத்திறனாளியா?</td>
                        <td>${data.isDifferentlyAbled}</td>
                        <td>அதன் தன்மை</td>
                        <td>${data.disabilityNature}</td>
                    </tr>
                </table>
            </div>

            <table class="signature-table">
                <tr>
                    <td class="center" style="width: 50%;">பெற்றோர் கையொப்பம்</td>
                    <td class="center" style="width: 50%;">வகுப்பாசிரியர் கையொப்பம்</td>
                </tr>
                <tr style="height: 30px;"><td colspan="2"></td></tr>
                <tr>
                    <td class="center">பள்ளி முத்திரை</td>
                    <td class="center">தலைமை ஆசிரியர் கையொப்பம்</td>
                </tr>
            </table>
        </div>
    </div>

    <!-- PAGE 2: CUMULATIVE RECORD (மாணவர் திரள் பதிவேடு) -->
    <div class="page">
        <div class="inner-border">
            <div>
                <div class="header-box">
                    மாணவர் திரள் பதிவேடு
                </div>

                <div class="header-box sub-section">
                    பகுதி - 1 கற்றல் வெளிப்பாடு - கல்விச்சார் பகுதிகள்
                </div>

                <table>
                    <thead>
                        <tr>
                            <th rowspan="2" class="center" style="width: 28%;">பாடம்</th>
                            <th colspan="3" class="center">பருவம் - 1 தரநிலை</th>
                            <th colspan="3" class="center">பருவம் - 2 தரநிலை</th>
                            <th colspan="3" class="center">பருவம் - 3 தரநிலை</th>
                        </tr>
                        <tr>
                            <th class="center" style="width: 8%;">FA</th>
                            <th class="center" style="width: 8%;">SA</th>
                            <th class="center" style="width: 8%;">Total</th>
                            <th class="center" style="width: 8%;">FA</th>
                            <th class="center" style="width: 8%;">SA</th>
                            <th class="center" style="width: 8%;">Total</th>
                            <th class="center" style="width: 8%;">FA</th>
                            <th class="center" style="width: 8%;">SA</th>
                            <th class="center" style="width: 8%;">Total</th>
                        </tr>
                    </thead>
                    <tbody>
${academicRowsHtml}
                    </tbody>
                </table>

                <div class="header-box sub-section">
                    பகுதி - 2 கல்வி இணைச் செயல்பாடுகள் (சுருக்கம்)
                </div>

                <table>
                    <thead>
                        <tr>
                            <th class="center" style="width: 40%;">செயல்பாடுகள்</th>
                            <th class="center" style="width: 20%;">பருவம் - 1</th>
                            <th class="center" style="width: 20%;">பருவம் - 2</th>
                            <th class="center" style="width: 20%;">பருவம் - 3</th>
                        </tr>
                    </thead>
                    <tbody>
${coCurricularHtml}
                    </tbody>
                </table>

                <table>
                    <tr>
                        <th class="center">மாணவர் வெளிப்படுத்திய செயல்திறன் / ஆற்றல் / தனித்திறன் ஏதேனும் ஒன்று</th>
                    </tr>
                    <tr>
                        <td style="height: 36px;">${data.specialTalent}</td>
                    </tr>
                </table>

                <div class="header-box sub-section">
                    ஆண்டு இறுதி தரநிலை
                </div>

                <div class="clearfix">
                    <table style="width: 49%; float: left;">
                        <thead>
                            <tr>
                                <th class="center">பாடம்</th>
                                <th class="center" style="width: 38%;">ஒட்டு மொத்த தரநிலை</th>
                            </tr>
                        </thead>
                        <tbody>
${finalAcadHtml}
                            <tr class="bold">
                                <th colspan="2" class="center">கல்வி இணைச் செயல்பாடுகள்</th>
                            </tr>
${finalCoCurrHtml}
                        </tbody>
                    </table>

                    <table style="width: 49%; float: right;">
                        <thead>
                            <tr>
                                <th style="width: 46%;">வருகை விவரம்</th>
                                <th class="center">பருவம்-1</th>
                                <th class="center">பருவம்-2</th>
                                <th class="center">பருவம்-3</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr><td>வேலை நாட்களின் எண்ணிக்கை</td><td class="center">${data.workingDays[0]}</td><td class="center">${data.workingDays[1]}</td><td class="center">${data.workingDays[2]}</td></tr>
                            <tr><td>மாணவர் வருகை நாட்கள்</td><td class="center">${data.presentDays[0]}</td><td class="center">${data.presentDays[1]}</td><td class="center">${data.presentDays[2]}</td></tr>
                            <tr><td>வருகை சதவீதம்</td><td class="center">${data.attendancePercent[0]}</td><td class="center">${data.attendancePercent[1]}</td><td class="center">${data.attendancePercent[2]}</td></tr>
                            <tr style="height: 28px;"><td>வகுப்பாசிரியர் கையொப்பம்</td><td></td><td></td><td></td></tr>
                            <tr style="height: 28px;"><td>தலைமையாசிரியர் கையொப்பம்</td><td></td><td></td><td></td></tr>
                            <tr style="height: 28px;"><td>பெற்றோர் கையொப்பம்</td><td></td><td></td><td></td></tr>
                        </tbody>
                    </table>
                </div>
            </div>

            <table style="margin-top: 4px; margin-bottom: 0;">
                <tr>
                    <th class="center" style="width: 30%;">தேர்வு முடிவு</th>
                    <td style="height: 24px;">${data.finalResult}</td>
                </tr>
            </table>
        </div>
    </div>

    <!-- PAGE 3: CO-SCHOLASTIC AREAS & CLASS TEACHER ASSESSMENT RECORD -->
    <div class="page">
        <div class="inner-border">
            <div>
                <div class="header-box">
                    இணைக் கல்விசார் பகுதிகள் &amp; வகுப்பாசிரியர் மதிப்பீட்டுப் பதிவேடு
                </div>

                <div class="grade-scale-strip">
                    <span><strong>இணைக் கல்வி தர அளவுகோல் (Co-Scholastic 3/5-Point Scale):</strong></span>
                    <span><strong>A</strong> - மிகச் சிறப்பு (Outstanding)</span>
                    <span><strong>B+ / B</strong> - நன்று (Very Good / Good)</span>
                    <span><strong>C</strong> - முன்னேற்றம் தேவை (Needs Improvement)</span>
                </div>

                <div class="header-box sub-section">
                    பகுதி - 2 (விரிவான பதிவேடு): இணைக் கல்விசார் பகுதிகள் (Co-Scholastic Areas Record)
                </div>

                <table>
                    <thead>
                        <tr>
                            <th class="center" style="width: 6%;">பிரிவு</th>
                            <th class="center" style="width: 31%;">இணைக் கல்விசார் திறன் பகுதி (Co-Scholastic Area)</th>
                            <th class="center" style="width: 35%;">விவரிப்புக் குறியீடுகள் (Descriptive Indicators)</th>
                            <th class="center" style="width: 7%;">ப-1</th>
                            <th class="center" style="width: 7%;">ப-2</th>
                            <th class="center" style="width: 7%;">ப-3</th>
                            <th class="center" style="width: 7%;">மொத்தம்</th>
                        </tr>
                    </thead>
                    <tbody>
${detailedCoScholasticHtml}
                    </tbody>
                </table>

                <div class="header-box sub-section">
                    பகுதி - 3: வகுப்பாசிரியர் மதிப்பீட்டுப் பதிவேடு (Class Teacher Assessment Record)
                </div>

                <table>
                    <thead>
                        <tr>
                            <th class="center" style="width: 36%;">மதிப்பீட்டுக் கூறுகள் (Assessment Parameters)</th>
                            <th class="center" style="width: 8%;">பருவம்-1</th>
                            <th class="center" style="width: 8%;">பருவம்-2</th>
                            <th class="center" style="width: 8%;">பருவம்-3</th>
                            <th class="center" style="width: 40%;">வகுப்பாசிரியர் சிறப்புக் குறிப்புகள் (Teacher Remarks)</th>
                        </tr>
                    </thead>
                    <tbody>
${teacherEvalHtml}
                    </tbody>
                </table>

                <div class="header-box sub-section">
                    பருவ வாரியான வகுப்பாசிரியர் உற்றுநோக்கல் &amp; தொடர் நடவடிக்கை (Term-wise Observations)
                </div>

                <table>
                    <thead>
                        <tr>
                            <th class="center" style="width: 14%;">பருவம்</th>
                            <th class="center" style="width: 24%;">மாணவரின் பலம் (Strengths)</th>
                            <th class="center" style="width: 22%;">மேம்படுத்த வேண்டியவை (Needs Focus)</th>
                            <th class="center" style="width: 22%;">ஆசிரியர் வழிகாட்டல் (Action Taken)</th>
                            <th class="center" style="width: 18%;">பெற்றோர் கருத்து (Parent Note)</th>
                        </tr>
                    </thead>
                    <tbody>
${teacherObsHtml}
                    </tbody>
                </table>

                <table>
                    <tr>
                        <th style="width: 28%;" class="center">வகுப்பாசிரியர் ஆண்டு இறுதிப் பரிந்துரை (Overall Recommendation)</th>
                        <td>${data.classTeacherOverallRecommendation}</td>
                    </tr>
                </table>
            </div>

            <table class="signature-table" style="margin-top: 6px;">
                <tr>
                    <td class="center" style="width: 33%;">வகுப்பாசிரியர் கையொப்பம்<br><span class="sub-en">(Class Teacher Signature)</span></td>
                    <td class="center" style="width: 34%;">பெற்றோர் / பாதுகாவலர் கையொப்பம்<br><span class="sub-en">(Parent / Guardian Signature)</span></td>
                    <td class="center" style="width: 33%;">தலைமை ஆசிரியர் கையொப்பம்<br><span class="sub-en">(Headmaster Signature &amp; Seal)</span></td>
                </tr>
            </table>
        </div>
    </div>

</body>
</html>`;
}
