import { StudentRecordData, SAMPLE_RECORD_DATA, BLANK_RECORD_DATA } from './recordData';
import {
  ClassTeacherRegisterData,
  RegisterStudentEntry,
  createBlankStudentEntry,
} from './teacherRegisterData';

export interface RosterStudent {
  id: string;
  slNo: string;
  name: string;
  studentClass: string;
  photoNo: string;
  phone: string;
  fatherName: string;
  motherName: string;
  dob: string;
  gender: string;
  address: string;
  pincode: string;
  bloodGroup: string;
  admissionNo: string;
  photoDataUrl?: string | null;
}

export function parseInitialRoster(): RosterStudent[] {
  return [];
}

export const INITIAL_SCHOOL_ROSTER: RosterStudent[] = parseInitialRoster();

export const CLASS_ORDER = ['ALL', 'LKG', 'UKG', 'I', 'II', 'III', 'IV', 'V'];

/**
 * Generates an official, print-ready SVG passport portrait (200x220) for any student
 * when a custom JPG/PNG photo has not yet been uploaded, showing a uniform silhouette,
 * student initials, class badge, and Photo No.
 */
export function generatePassportPortraitSvg(student: RosterStudent): string {
  const isFemale = student.gender.toLowerCase() === 'female';
  const bgTop = isFemale ? '#EFF6FF' : '#F0F9FF';
  const bgBottom = isFemale ? '#DBEAFE' : '#E0F2FE';
  const uniformColor = '#1E3A8A';
  const collarColor = '#FFFFFF';
  const skinTone = '#F3C6A5';
  const hairColor = '#1F2937';

  const cleanName = student.name.replace(/\s+/g, ' ').trim();
  const shortName = cleanName.length > 16 ? cleanName.slice(0, 15) + '.' : cleanName;
  const photoBadge = student.photoNo
    ? `PHOTO #${student.photoNo}`
    : student.admissionNo
    ? `ADM #${student.admissionNo}`
    : `CLASS ${student.studentClass}`;

  const hairPath = isFemale
    ? `<path d="M62 66 C62 38, 138 38, 138 66 C142 82, 144 98, 136 106 C132 82, 128 60, 100 58 C72 60, 68 82, 64 106 C56 98, 58 82, 62 66 Z" fill="${hairColor}"/>
       <circle cx="58" cy="96" r="8" fill="#DC2626"/>
       <circle cx="142" cy="96" r="8" fill="#DC2626"/>`
    : `<path d="M65 68 C65 40, 135 40, 135 68 C132 54, 118 48, 100 48 C82 48, 68 54, 65 68 Z" fill="${hairColor}"/>`;

  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 220" width="200" height="220">
    <defs>
      <linearGradient id="bg" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0%" stop-color="${bgTop}"/>
        <stop offset="100%" stop-color="${bgBottom}"/>
      </linearGradient>
    </defs>
    <rect width="200" height="220" fill="url(#bg)"/>
    <rect x="3" y="3" width="194" height="214" fill="none" stroke="#94A3B8" stroke-width="1.5"/>

    <!-- Top Class & Photo No Tag -->
    <rect x="10" y="9" width="54" height="18" rx="3" fill="#1E3A8A"/>
    <text x="37" y="21" font-family="Arial, sans-serif" font-size="10" font-weight="bold" fill="#FFFFFF" text-anchor="middle">${student.studentClass}</text>
    <text x="188" y="21" font-family="monospace" font-size="10" font-weight="bold" fill="#1E3A8A" text-anchor="end">${photoBadge}</text>

    <!-- Neck -->
    <rect x="88" y="102" width="24" height="24" rx="6" fill="${skinTone}"/>

    <!-- School Uniform Shoulders & Tie/Collar -->
    <path d="M34 176 C34 134, 64 120, 100 120 C136 120, 166 134, 166 176 Z" fill="${uniformColor}"/>
    <polygon points="78,120 100,148 122,120 110,118 100,136 90,118" fill="${collarColor}"/>
    <polygon points="96,136 104,136 106,172 100,176 94,172" fill="#991B1B"/>

    <!-- Head & Ears -->
    <circle cx="66" cy="78" r="6" fill="${skinTone}"/>
    <circle cx="134" cy="78" r="6" fill="${skinTone}"/>
    <ellipse cx="100" cy="76" rx="33" ry="36" fill="${skinTone}"/>

    <!-- Facial Features -->
    <circle cx="88" cy="74" r="3.2" fill="#1E293B"/>
    <circle cx="112" cy="74" r="3.2" fill="#1E293B"/>
    <path d="M83 66 Q88 63 93 66" stroke="#1E293B" stroke-width="2" fill="none" stroke-linecap="round"/>
    <path d="M107 66 Q112 63 117 66" stroke="#1E293B" stroke-width="2" fill="none" stroke-linecap="round"/>
    <path d="M98 76 L100 84 L103 84" stroke="#C28E6B" stroke-width="1.8" fill="none" stroke-linecap="round"/>
    <path d="M90 93 Q100 99 110 93" stroke="#9A3412" stroke-width="2.2" fill="none" stroke-linecap="round"/>
    ${isFemale ? '<circle cx="100" cy="65" r="2.2" fill="#DC2626"/>' : ''}

    <!-- Hair -->
    ${hairPath}

    <!-- Bottom Name Plate -->
    <rect x="4" y="176" width="192" height="40" fill="#0F172A"/>
    <text x="100" y="193" font-family="Arial, sans-serif" font-size="11" font-weight="bold" fill="#FFFFFF" text-anchor="middle">${shortName}</text>
    <text x="100" y="208" font-family="monospace" font-size="9.5" fill="#CBD5E1" text-anchor="middle">ADM: ${student.admissionNo || 'N/A'} | ${student.bloodGroup || 'BG'}</text>
  </svg>`;

  return `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`;
}

export function getEffectiveStudentPhoto(
  student: RosterStudent,
  useAutoPortraits = true
): string | null {
  if (student.photoDataUrl) return student.photoDataUrl;
  if (useAutoPortraits) return generatePassportPortraitSvg(student);
  return null;
}

export function mapRosterStudentToCumulativeRecord(
  student: RosterStudent,
  baseTemplate: StudentRecordData = BLANK_RECORD_DATA,
  useAutoPortraits = true
): StudentRecordData {
  const cloned: StudentRecordData = JSON.parse(JSON.stringify(baseTemplate));
  const fullAddress = [student.address, student.pincode].filter(Boolean).join(' - ');
  const genderDisplay =
    student.gender?.toLowerCase() === 'female'
      ? 'பெண் (Female)'
      : student.gender?.toLowerCase() === 'male'
      ? 'ஆண் (Male)'
      : student.gender || '—';

  return {
    ...cloned,
    serialNo: student.slNo || '1',
    classAndSection: student.studentClass || 'UKG',
    examNo: student.photoNo ? `PH-${student.photoNo}` : student.admissionNo || '',
    yearSuffix: '25 - 2026',
    photoNo: student.photoNo,
    photoDataUrl: getEffectiveStudentPhoto(student, useAutoPortraits),
    nameTamil: student.name,
    nameEnglish: student.name,
    gender: genderDisplay,
    admissionNo: student.admissionNo || '',
    dob: student.dob,
    fatherName: student.fatherName,
    motherName: student.motherName,
    guardianName: '—',
    occupation: '',
    annualIncome: '',
    address: fullAddress,
    phone: student.phone,
    aadhaarDigits: Array(12).fill(''),
    emisNo: '',
    savingsNo: '',
    bloodGroup: student.bloodGroup || '',
    healthStatus: 'நன்று (Good)',
    heightCm: '',
    weightKg: '',
    isDifferentlyAbled: 'இல்லை',
    disabilityNature: '—',
    finalResult: `தேர்ச்சி (${student.studentClass} வகுப்பு)`,
  };
}

export function mapRosterStudentsToTeacherRegister(
  classLabel: string,
  students: RosterStudent[],
  useAutoPortraits = true
): ClassTeacherRegisterData {
  const entries: RegisterStudentEntry[] = students.map((stu, idx) => {
    const base = createBlankStudentEntry(idx + 1);
    return {
      ...base,
      admNo: stu.admissionNo || (stu.photoNo ? `PH-${stu.photoNo}` : ''),
      studentName: stu.name,
      photoNo: stu.photoNo,
      photoDataUrl: getEffectiveStudentPhoto(stu, useAutoPortraits),
    };
  });

  return {
    schoolName: 'SAMPLE SCHOOL',
    academicYear: '2025 - 2026',
    classAndSection: classLabel,
    students: entries.length > 0 ? entries : [createBlankStudentEntry(1)],
  };
}
