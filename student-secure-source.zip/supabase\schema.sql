create table if not exists public.school_app_state (
  owner_id uuid primary key references auth.users (id) on delete cascade,
  state jsonb not null,
  updated_at timestamptz not null default now()
);

create table if not exists public.school_admin_allowlist (
  email text primary key
);

alter table public.school_admin_allowlist enable row level security;
revoke all on public.school_admin_allowlist from anon, authenticated;

create or replace function public.is_school_admin()
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1
    from public.school_admin_allowlist
    where email = lower(coalesce(auth.jwt() ->> 'email', ''))
  );
$$;

revoke all on function public.is_school_admin() from public;
grant execute on function public.is_school_admin() to authenticated;

alter table public.school_app_state enable row level security;
grant select, insert, update on public.school_app_state to authenticated;

drop policy if exists "School owners can access their own app state" on public.school_app_state;
create policy "School owners can access their own app state"
  on public.school_app_state
  for all
  to authenticated
  using (public.is_school_admin() and auth.uid() = owner_id)
  with check (public.is_school_admin() and auth.uid() = owner_id);

insert into storage.buckets (id, name, public)
values ('school-media', 'school-media', false)
on conflict (id) do update set public = false;

drop policy if exists "School owners can read their own media" on storage.objects;
create policy "School owners can read their own media"
  on storage.objects
  for select
  to authenticated
  using (
    public.is_school_admin()
    and bucket_id = 'school-media'
    and (storage.foldername(name))[1] = auth.uid()::text
  );

drop policy if exists "School owners can add their own media" on storage.objects;
create policy "School owners can add their own media"
  on storage.objects
  for insert
  to authenticated
  with check (
    public.is_school_admin()
    and bucket_id = 'school-media'
    and (storage.foldername(name))[1] = auth.uid()::text
  );

drop policy if exists "School owners can update their own media" on storage.objects;
create policy "School owners can update their own media"
  on storage.objects
  for update
  to authenticated
  using (
    public.is_school_admin()
    and bucket_id = 'school-media'
    and (storage.foldername(name))[1] = auth.uid()::text
  )
  with check (
    public.is_school_admin()
    and bucket_id = 'school-media'
    and (storage.foldername(name))[1] = auth.uid()::text
  );

drop policy if exists "School owners can delete their own media" on storage.objects;
create policy "School owners can delete their own media"
  on storage.objects
  for delete
  to authenticated
  using (
    public.is_school_admin()
    and bucket_id = 'school-media'
    and (storage.foldername(name))[1] = auth.uid()::text
  );
